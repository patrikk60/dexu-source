import { PublicKey, VersionedTransaction, TransactionMessage } from '@solana/web3.js';
import { Decimal } from 'decimal.js';

const JUPITER_API_BASE = 'https://quote-api.jup.ag/v6';
const PRICE_API_BASE = 'https://price.jup.ag/v4';

// Get token prices from Jupiter Price API V4
export async function getTokenPrices(tokenMints) {
  if (!tokenMints || tokenMints.length === 0) return {};
  
  try {
    const response = await fetch(`${PRICE_API_BASE}/price?ids=${tokenMints.join(',')}`);
    if (!response.ok) throw new Error('Failed to fetch prices');
    
    const { data } = await response.json();
    
    // Normalize price data
    const prices = {};
    for (const mint of tokenMints) {
      if (mint === 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v') {
        // USDC is always $1
        prices[mint] = { price: '1.00' };
      } else if (data[mint]) {
        prices[mint] = { price: data[mint].price };
      } else {
        prices[mint] = { price: '0' };
      }
    }
    
    return prices;
  } catch (error) {
    console.error('Error fetching token prices:', error);
    return {};
  }
}

// Get swap quote from Jupiter API
export async function getSwapQuote(inputMint, outputMint, amount, inputDecimals, slippageBps) {
  if (!inputMint || !outputMint || !amount) return null;
  
  try {
    console.log('Fetching quote with params:', {
      inputMint,
      outputMint,
      amount,
      slippageBps
    });

    // Convert amount to smallest units considering decimals
    const amountInSmallestUnits = new Decimal(amount)
      .mul(new Decimal(10).pow(inputDecimals))
      .toFixed(0);

    const params = new URLSearchParams({
      inputMint,
      outputMint,
      amount: amountInSmallestUnits,
      slippageBps: slippageBps.toString(),
      onlyDirectRoutes: 'false',
      asLegacyTransaction: false,
      platformFeeBps: '0'
    });
    
    const response = await fetch(`${JUPITER_API_BASE}/quote?${params}`);
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Failed to fetch quote: ${errorText}`);
    }
    
    const data = await response.json();
    console.log('Quote API Response:', data);
    return data;
  } catch (error) {
    console.error('Error fetching quote:', error);
    throw error;
  }
}

// Execute swap using Jupiter API
export async function executeSwap(quote, userPublicKey, connection, signTransaction) {
  if (!quote || !userPublicKey) {
    throw new Error('Missing quote or user public key');
  }

  try {
    console.log('Executing swap with params:', {
      userPublicKey,
      quoteAmount: quote.outAmount,
      quotePriceImpact: quote.priceImpactPct
    });

    // 1. Get swap transaction
    const swapRequestBody = {
      quoteResponse: quote,
      userPublicKey: userPublicKey,
      computeUnitPriceMicroLamports: null,
      asLegacyTransaction: false,
      useTokenLedger: false,
      wrapUnwrapSOL: true
    };

    console.log('Swap API Request:', swapRequestBody);

    const swapResponse = await fetch(`${JUPITER_API_BASE}/swap`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(swapRequestBody)
    });

    if (!swapResponse.ok) {
      const errorText = await swapResponse.text();
      throw new Error(`Failed to get swap transaction: ${errorText}`);
    }

    const { swapTransaction } = await swapResponse.json();
    
    if (!swapTransaction) {
      throw new Error('No swap transaction returned from API');
    }

    // 2. Decode the transaction
    const transactionBuf = Buffer.from(swapTransaction, 'base64');
    const transaction = VersionedTransaction.deserialize(transactionBuf);

    // 3. Sign the transaction
    console.log('Signing transaction...');
    const signedTransaction = await signTransaction(transaction);
    console.log('Transaction signed successfully');

    // 4. Send transaction
    console.log('Sending transaction...');
    const rawTransaction = signedTransaction.serialize();
    const txid = await connection.sendRawTransaction(rawTransaction, {
      skipPreflight: true,
      maxRetries: 3,
      preflightCommitment: 'confirmed'
    });
    console.log('Transaction sent:', txid);

    // 5. Confirm transaction with retry logic
    console.log('Waiting for confirmation...');
    let retries = 5;
    while (retries > 0) {
      try {
        const latestBlockhash = await connection.getLatestBlockhash('confirmed');
        const confirmation = await connection.confirmTransaction({
          signature: txid,
          blockhash: latestBlockhash.blockhash,
          lastValidBlockHeight: latestBlockhash.lastValidBlockHeight
        }, 'confirmed');

        if (confirmation.value.err) {
          throw new Error(`Transaction failed: ${JSON.stringify(confirmation.value.err)}`);
        }

        // Get transaction status to ensure it's actually confirmed
        const status = await connection.getSignatureStatus(txid);
        if (!status.value || status.value.err) {
          throw new Error('Transaction failed or status not available');
        }

        if (status.value.confirmationStatus === 'confirmed' || status.value.confirmationStatus === 'finalized') {
          return {
            txid,
            success: true
          };
        }

        throw new Error('Transaction not confirmed');
      } catch (error) {
        console.warn(`Confirmation attempt ${6 - retries} failed:`, error);
        retries--;
        if (retries === 0) {
          throw new Error('Transaction confirmation failed after multiple attempts');
        }
        // Wait for 2 seconds before retrying
        await new Promise(resolve => setTimeout(resolve, 2000));
      }
    }

    throw new Error('Transaction confirmation timed out');
  } catch (error) {
    console.error('Swap failed:', error);
    throw error;
  }
}

// Calculate USD value for a token amount
export function calculateUsdValue(amount, price) {
  if (!amount || !price) return '0.00';
  try {
    // Ensure we're working with strings to avoid precision issues
    const amountDecimal = new Decimal(amount.toString());
    if (amountDecimal.isZero() || amountDecimal.isNaN()) return '0.00';
    
    const priceDecimal = new Decimal(price.toString());
    if (priceDecimal.isZero() || priceDecimal.isNaN()) return '0.00';
    
    const value = amountDecimal.mul(priceDecimal);
    
    // Always show 2 decimal places for USD values
    return value.toFixed(2);
  } catch (error) {
    console.error('Error calculating USD value:', error);
    return '0.00';
  }
}

// Format token amount for display
export function formatBalance(value) {
  if (!value) return '0';
  try {
    const decimal = new Decimal(value.toString());
    if (decimal.isZero() || decimal.isNaN()) return '0';
    
    // For very small numbers (< 0.000001), show more decimals
    if (decimal.abs().lt(0.000001)) {
      const log10 = decimal.abs().log(10).floor().neg();
      const significantDecimals = log10.plus(4).toNumber();
      const formatted = decimal.toFixed(significantDecimals);
      const parts = formatted.split('.');
      parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
      return parts.join('.');
    }
    
    // For regular numbers, use dynamic decimal places
    let decimals = 6;
    if (decimal.abs().gte(1000000)) {
      decimals = 2;
    } else if (decimal.abs().gte(1)) {
      decimals = 4;
    }
    
    const formatted = decimal.toFixed(decimals).replace(/\.?0+$/, '');
    const parts = formatted.split('.');
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return parts.join('.');
  } catch {
    return '0';
  }
}