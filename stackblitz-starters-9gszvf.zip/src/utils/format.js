import { Decimal } from 'decimal.js';

export const formatBalance = (balance, decimals = 6) => {
  if (!balance) return '0';
  try {
    const decimal = new Decimal(balance);
    if (decimal.isZero()) return '0';
    
    const parts = decimal
      .toFixed(decimals)
      .replace(/\.?0+$/, '')
      .split('.');
    
    // Add commas to the integer part
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    
    return parts.length > 1 ? parts.join('.') : parts[0];
  } catch {
    return '0';
  }
};

export const formatUsdValue = (value) => {
  if (!value) return '0.00';
  try {
    const parts = new Decimal(value)
      .toFixed(2)
      .split('.');
    
    // Add commas to the integer part
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    
    return parts.join('.');
  } catch {
    return '0.00';
  }
};