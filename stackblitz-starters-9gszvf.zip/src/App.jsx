import React from 'react';
import { ConnectionProvider, WalletProvider } from '@solana/wallet-adapter-react';
import { WalletModalProvider } from '@solana/wallet-adapter-react-ui';
import { PhantomWalletAdapter } from '@solana/wallet-adapter-wallets';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import SwapInterface from './components/SwapInterface';
import Header from './components/Header';
import Footer from './components/Footer';
import Docs from './components/Docs';
import LimitPage from './pages/LimitPage';
import DCAPage from './pages/DCAPage';
import LiquidityPage from './pages/LiquidityPage';
import '@solana/wallet-adapter-react-ui/styles.css';

const App = () => {
  const endpoint = "https://rpc.hellomoon.io/c79ff6d1-a59d-4743-a71c-3085f463c8e9";
  const wallets = [new PhantomWalletAdapter()];

  return (
    <ConnectionProvider endpoint={endpoint}>
      <WalletProvider wallets={wallets} autoConnect>
        <WalletModalProvider>
          <Router>
            <div className="min-h-screen bg-gray-900 text-white flex flex-col">
              <Header />
              <Routes>
                <Route path="/" element={
                  <main className="container mx-auto px-4 py-24 flex-grow">
                    <SwapInterface />
                  </main>
                } />
                <Route path="/docs" element={<Docs />} />
                <Route path="/limit" element={<LimitPage />} />
                <Route path="/dca" element={<DCAPage />} />
                <Route path="/liquidity" element={<LiquidityPage />} />
              </Routes>
              <Footer />
            </div>
          </Router>
        </WalletModalProvider>
      </WalletProvider>
    </ConnectionProvider>
  );
};

export default App;