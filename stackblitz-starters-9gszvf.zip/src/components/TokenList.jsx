import React, { useState, useEffect } from 'react';
import { PublicKey } from '@solana/web3.js';
import TokenImage from './TokenImage';

// Preloaded popular tokens
const PRELOADED_TOKENS = [
  {
    symbol: 'SOL',
    name: 'Solana',
    address: 'So11111111111111111111111111111111111111112',
    decimals: 9,
    logoURI: 'https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/So11111111111111111111111111111111111111112/logo.png'
  },
  {
    symbol: 'USDC',
    name: 'USD Coin',
    address: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
    decimals: 6,
    logoURI: 'https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v/logo.png'
  },
  {
    symbol: 'BONK',
    name: 'Bonk',
    address: 'DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263',
    decimals: 5,
    logoURI: 'https://arweave.net/hQB7PMqn8BPc_HNB8CKgNvN8Ejo0ZC6DEGmS4Xv8-aM'
  },
  {
    symbol: 'RNDR',
    name: 'Render Token',
    address: 'RNDRJKZBcFPRrwkMJYrxSCGW1b6m4rSHrcwrVsYrWjy',
    decimals: 8,
    logoURI: 'https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/RNDRJKZBcFPRrwkMJYrxSCGW1b6m6rSHrcwrVsYrWjy/logo.png'
  },
  {
    symbol: 'JUP',
    name: 'Jupiter',
    address: 'JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN',
    decimals: 6,
    logoURI: 'https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN/logo.png'
  }
];

const DEFAULT_DECIMALS = 6;

const TokenList = ({ onSelect, selectedToken }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [tokens, setTokens] = useState(PRELOADED_TOKENS);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [allTokens, setAllTokens] = useState(PRELOADED_TOKENS);

  useEffect(() => {
    const fetchAllTokens = async () => {
      try {
        setLoading(true);
        const response = await fetch('https://token.jup.ag/strict');
        if (!response.ok) throw new Error('Failed to fetch token list');
        const data = await response.json();
        
        // Merge with preloaded tokens, ensuring no duplicates
        const mergedTokens = [...PRELOADED_TOKENS];
        data.forEach(token => {
          if (!mergedTokens.some(t => t.address === token.address)) {
            mergedTokens.push(token);
          }
        });
        
        setAllTokens(mergedTokens);
        setTokens(mergedTokens.slice(0, 50));
      } catch (err) {
        console.error('Error fetching tokens:', err);
        setError('Failed to load additional tokens');
      } finally {
        setLoading(false);
      }
    };
    fetchAllTokens();
  }, []);

  const getTokenInfo = async (address) => {
    // First check cached tokens
    const cachedToken = allTokens.find(t => t.address.toLowerCase() === address.toLowerCase());
    if (cachedToken) {
      return cachedToken;
    }

    // If not in cache, fetch from Jupiter
    try {
      const response = await fetch(`https://token.jup.ag/token/${address}`);
      if (response.ok) {
        const tokenData = await response.json();
        return {
          ...tokenData,
          decimals: tokenData.decimals || DEFAULT_DECIMALS
        };
      }
    } catch (err) {
      console.error('Error fetching token info:', err);
    }

    // Return unknown token with default decimals
    return {
      symbol: 'Unknown',
      name: `Token (${address.slice(0, 4)}...${address.slice(-4)})`,
      address: address,
      decimals: DEFAULT_DECIMALS,
      logoURI: null
    };
  };

  const searchTokens = async (query) => {
    setSearchTerm(query);
    setError('');
    
    if (!query) {
      setTokens(allTokens.slice(0, 50));
      return;
    }

    try {
      setLoading(true);

      // Check if input might be a Solana address
      if (query.length >= 32) {
        try {
          const pubkey = new PublicKey(query);
          const address = pubkey.toString();
          const tokenInfo = await getTokenInfo(address);
          setTokens([tokenInfo]);
        } catch (err) {
          // Continue with name search if not a valid address
          const searchLower = query.toLowerCase();
          const filteredTokens = allTokens.filter(token => 
            token.symbol.toLowerCase().includes(searchLower) ||
            token.name.toLowerCase().includes(searchLower) ||
            token.address.toLowerCase().includes(searchLower)
          );
          setTokens(filteredTokens);
        }
      } else {
        // Regular name/symbol search
        const searchLower = query.toLowerCase();
        const filteredTokens = allTokens.filter(token => 
          token.symbol.toLowerCase().includes(searchLower) ||
          token.name.toLowerCase().includes(searchLower) ||
          token.address.toLowerCase().includes(searchLower)
        );
        setTokens(filteredTokens);
      }
    } catch (err) {
      console.error('Token search error:', err);
      setError('Failed to search tokens');
      setTokens([]);
    } finally {
      setLoading(false);
    }
  };

  // Show selected token at the top if it exists and we're not searching
  const displayTokens = React.useMemo(() => {
    if (!searchTerm && selectedToken) {
      const otherTokens = tokens.filter(t => t.address !== selectedToken.address);
      return [selectedToken, ...otherTokens];
    }
    return tokens;
  }, [tokens, selectedToken, searchTerm]);

  return (
    <div className="space-y-4">
      <div className="relative">
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => searchTokens(e.target.value)}
          placeholder="Search name or paste address"
          className="w-full bg-gray-800/50 border border-gray-700 rounded-lg px-4 py-2 text-gray-200 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
          autoFocus
        />
      </div>

      {error && (
        <div className="text-red-400 text-sm p-2 bg-red-500/10 rounded-lg">
          {error}
        </div>
      )}

      <div className="space-y-1 max-h-[400px] overflow-y-auto custom-scrollbar pr-2">
        {displayTokens.map((token) => (
          <button
            key={token.address}
            className={`w-full flex items-center gap-3 p-3 hover:bg-gray-800 rounded-lg transition-colors ${
              selectedToken?.address === token.address ? 'bg-gray-800' : ''
            }`}
            onClick={() => onSelect(token)}
          >
            <TokenImage 
              src={token.logoURI}
              alt={token.symbol}
              className="w-8 h-8 rounded-full bg-gray-800 flex-shrink-0"
            />
            <div className="flex flex-col items-start min-w-0 flex-1">
              <div className="flex items-center gap-2 w-full">
                <span className="text-gray-200 font-medium">{token.symbol}</span>
                <span className="text-gray-400 text-sm truncate">{token.name}</span>
              </div>
              <span className="text-xs text-gray-400 font-mono">
                {token.address.slice(0, 4)}...{token.address.slice(-4)}
              </span>
            </div>
          </button>
        ))}

        {displayTokens.length === 0 && !loading && (
          <div className="text-sm text-gray-400 text-center py-2">
            No tokens found
          </div>
        )}
      </div>
    </div>
  );
};

export default TokenList;