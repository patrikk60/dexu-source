import React, { useState, useCallback } from 'react';
import { Notification } from './Notification';

const NotificationManager = () => {
  const [notification, setNotification] = useState(null);

  const showNotification = useCallback((message, type) => {
    setNotification({ message, type });
  }, []);

  const clearNotification = useCallback(() => {
    setNotification(null);
  }, []);

  return {
    showNotification,
    clearNotification,
    NotificationComponent: notification ? (
      <Notification
        message={notification.message}
        type={notification.type}
        onClose={clearNotification}
      />
    ) : null,
  };
};

export default NotificationManager;