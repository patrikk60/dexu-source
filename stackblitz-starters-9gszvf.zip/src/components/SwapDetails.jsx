import React, { useState, useEffect } from 'react';
import { Decimal } from 'decimal.js';
import LoadingNumber from './LoadingNumber';
import { getSwapQuote } from '../utils/jupiter';

const MAX_NETWORK_FEE = 0.00405;

const InfoIcon = () => (
  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="currentColor" strokeWidth="2"/>
    <path d="M12 16V12M12 8H12.01" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
  </svg>
);

const SwapDetails = ({ 
  quote, 
  inputToken, 
  outputToken, 
  inputAmount,
  priceImpact,
  isOpen,
  onToggle,
  loading 
}) => {
  const [currentRate, setCurrentRate] = useState(null);
  const [isLoadingRate, setIsLoadingRate] = useState(false);

  useEffect(() => {
    let mounted = true;
    let timeoutId;

    const fetchRate = async () => {
      if (!inputToken?.address || !outputToken?.address) return;
      
      try {
        setIsLoadingRate(true);
        // Always fetch rate for 1 unit of input token
        const oneUnit = new Decimal(10).pow(inputToken.decimals).toString();
        const quoteResponse = await getSwapQuote(
          inputToken.address,
          outputToken.address,
          '1',
          inputToken.decimals,
          1
        );
        
        if (mounted && quoteResponse) {
          const rate = new Decimal(quoteResponse.outAmount)
            .div(10 ** outputToken.decimals)
            .div(new Decimal(quoteResponse.inAmount).div(10 ** inputToken.decimals));
          setCurrentRate(rate);
        }
      } catch (err) {
        console.error('Error fetching rate:', err);
        if (mounted) {
          timeoutId = setTimeout(fetchRate, 2000);
        }
      } finally {
        if (mounted) setIsLoadingRate(false);
      }
    };

    fetchRate();

    return () => { 
      mounted = false;
      if (timeoutId) clearTimeout(timeoutId);
    };
  }, [inputToken?.address, outputToken?.address, inputToken?.decimals, outputToken?.decimals]);

  const priceImpactValue = Math.abs(priceImpact || 0) * 100;
  const showDropdown = !!inputAmount && inputAmount !== '0';

  return (
    <div className="mt-4 bg-gray-900/30 rounded-xl backdrop-blur-sm border border-gray-800">
      <div className="w-full px-4 py-3 flex items-center justify-between text-gray-400">
        <div className="flex items-center gap-1 text-sm">
          {isLoadingRate || loading ? (
            <LoadingNumber 
              value={currentRate ? `1 ${inputToken.symbol} = ${currentRate.toFixed(6)} ${outputToken.symbol}` : 'Loading rate...'}
              loading={true}
            />
          ) : currentRate ? (
            <span>1 {inputToken.symbol} = {currentRate.toFixed(6)} {outputToken.symbol}</span>
          ) : (
            <span>Failed to fetch rate</span>
          )}
        </div>
        {showDropdown && (
          <button
            onClick={onToggle}
            className="text-gray-400 hover:text-gray-200"
          >
            <svg 
              className={`w-5 h-5 transition-transform ${isOpen ? 'rotate-180' : ''}`} 
              fill="none" 
              viewBox="0 0 24 24" 
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
          </button>
        )}
      </div>

      {isOpen && showDropdown && (
        <div className="px-4 py-3 space-y-3 border-t border-gray-800">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-1">
              <span className="text-gray-400">Price Impact</span>
              <div className="group relative">
                <InfoIcon />
                <div className="absolute bottom-full mb-2 hidden group-hover:block right-0 w-48 p-2 bg-gray-800 rounded-lg text-xs text-gray-300">
                  The difference between the market price and estimated price due to trade size
                </div>
              </div>
            </div>
            <span className={`
              ${priceImpactValue < 1 ? 'text-green-400' : ''}
              ${priceImpactValue >= 1 && priceImpactValue < 3 ? 'text-yellow-400' : ''}
              ${priceImpactValue >= 3 ? 'text-red-400' : ''}
            `}>
              {priceImpactValue < 0.1 ? '< 0.1%' : `${priceImpactValue.toFixed(2)}%`}
            </span>
          </div>

          {quote && (
            <>
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-1">
                  <span className="text-gray-400">Minimum Received</span>
                  <div className="group relative">
                    <InfoIcon />
                    <div className="absolute bottom-full mb-2 hidden group-hover:block right-0 w-48 p-2 bg-gray-800 rounded-lg text-xs text-gray-300">
                      The minimum amount you will receive after slippage
                    </div>
                  </div>
                </div>
                <LoadingNumber
                  value={new Decimal(quote.otherAmountThreshold)
                    .div(10 ** outputToken.decimals)
                    .toFixed(outputToken.decimals)}
                  loading={loading}
                  suffix={` ${outputToken.symbol}`}
                />
              </div>

              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-1">
                  <span className="text-gray-400">Max Network Fee</span>
                  <div className="group relative">
                    <InfoIcon />
                    <div className="absolute bottom-full mb-2 hidden group-hover:block right-0 w-48 p-2 bg-gray-800 rounded-lg text-xs text-gray-300">
                      Maximum transaction fee including priority fees
                    </div>
                  </div>
                </div>
                <span className="text-gray-200">
                  {MAX_NETWORK_FEE.toFixed(5)} SOL
                </span>
              </div>

              {quote.accountCreationFeeLamports > 0 && (
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-1">
                    <span className="text-gray-400">Deposit</span>
                    <div className="group relative">
                      <InfoIcon />
                      <div className="absolute bottom-full mb-2 hidden group-hover:block right-0 w-48 p-2 bg-gray-800 rounded-lg text-xs text-gray-300">
                        One-time fee for creating token accounts
                      </div>
                    </div>
                  </div>
                  <span className="text-gray-200">
                    {new Decimal(quote.accountCreationFeeLamports).div(1e9).toFixed(8)} SOL for {quote.newAccounts?.length || 1} ATA account
                  </span>
                </div>
              )}

              {quote.routePlan && quote.routePlan.length > 0 && (
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-1">
                    <span className="text-gray-400">Route</span>
                    <div className="group relative">
                      <InfoIcon />
                      <div className="absolute bottom-full mb-2 hidden group-hover:block right-0 w-48 p-2 bg-gray-800 rounded-lg text-xs text-gray-300">
                        The path your swap will take through various liquidity pools
                      </div>
                    </div>
                  </div>
                  <span className="text-gray-200">
                    {quote.routePlan.length} hop{quote.routePlan.length > 1 ? 's' : ''}
                  </span>
                </div>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
};

export default SwapDetails;