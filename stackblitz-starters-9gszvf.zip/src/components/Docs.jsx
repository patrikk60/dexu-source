import React from 'react';

const Docs = () => {
  return (
    <div className="container mx-auto px-4 py-24">
      <div className="max-w-4xl mx-auto prose prose-invert">
        <h1>Nebula Exchange API Documentation</h1>
        
        <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg mb-8">
          <h3 className="text-blue-400 mt-0">Risk Disclaimer</h3>
          <p className="mb-0">
            Please use Nebula Exchange's APIs at your own risk. Our Frontend UI contains multiple safeguards 
            and warnings when quoting. Nebula Exchange is not liable for losses incurred by users on other platforms.
          </p>
        </div>

        <h2>Swap API</h2>
        <p>
          Nebula Exchange APIs is the easiest way for developers to access liquidity on Solana. Simply pass in 
          the desired pairs, amount, and slippage, and the API will return the serialized transactions needed 
          to execute the swap.
        </p>

        <h3>1. Installation</h3>
        <p>Install the required dependencies:</p>
        <pre><code>{`npm i @solana/web3.js@1
npm i cross-fetch
npm i @project-serum/anchor
npm i bs58`}</code></pre>

        <h3>2. Setup Connection</h3>
        <pre><code>{`import { Connection, Keypair, VersionedTransaction } from '@solana/web3.js';
import fetch from 'cross-fetch';
import { Wallet } from '@project-serum/anchor';
import bs58 from 'bs58';

// Use your own RPC endpoint in production
const connection = new Connection('https://rpc.nebex.io/v1/mainnet');`}</code></pre>

        <h3>3. Setup Wallet</h3>
        <pre><code>{`const wallet = new Wallet(
  Keypair.fromSecretKey(bs58.decode(process.env.PRIVATE_KEY || ''))
);`}</code></pre>

        <h3>4. Get Quote</h3>
        <pre><code>{`// Example: Swapping SOL to USDC with input 0.1 SOL and 0.5% slippage
const quoteResponse = await (
  await fetch('https://api.nebex.io/v6/quote?\\
inputMint=So11111111111111111111111111111111111111112\\
&outputMint=EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\\
&amount=100000000\\
&slippageBps=50'
  )
).json();`}</code></pre>

        <h3>5. Execute Swap</h3>
        <pre><code>{`const { swapTransaction } = await (
  await fetch('https://api.nebex.io/v6/swap', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      quoteResponse,
      userPublicKey: wallet.publicKey.toString(),
      wrapAndUnwrapSol: true
    })
  })
).json();

const swapTransactionBuf = Buffer.from(swapTransaction, 'base64');
const transaction = VersionedTransaction.deserialize(swapTransactionBuf);
transaction.sign([wallet.payer]);

const latestBlockHash = await connection.getLatestBlockhash();
const rawTransaction = transaction.serialize()
const txid = await connection.sendRawTransaction(rawTransaction, {
  skipPreflight: true,
  maxRetries: 2
});

await connection.confirmTransaction({
  blockhash: latestBlockHash.blockhash,
  lastValidBlockHeight: latestBlockHash.lastValidBlockHeight,
  signature: txid
});`}</code></pre>

        <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg my-8">
          <h4 className="text-blue-400 mt-0">Network Congestion</h4>
          <p className="mb-0">
            Due to network congestion on Solana, the sendRawTransaction method may not be able to help you 
            land your transaction. Consider implementing retry logic with increasing compute budgets.
          </p>
        </div>

        <h2>Price API V2</h2>
        <p>
          Price API V2 enhances accuracy by incorporating both buy and sell-side liquidity to derive the 
          average price. This provides more reliable real-time data for SPL tokens.
        </p>

        <h3>Basic Usage</h3>
        <p>
          The Price API returns the unit buy price for specified tokens based on the best pricing data 
          available across all DEXes:
        </p>

        <pre><code>{`# Get unit price of tokens based on USDC
GET https://api.nebex.io/v2/price?ids=So11111111111111111111111111111111111111112

{
    "data": {
        "So11111111111111111111111111111111111111112": {
            "id": "So11111111111111111111111111111111111111112",
            "type": "derivedPrice",
            "price": "133.890945000"
        }
    }
}`}</code></pre>

        <h3>Detailed Information</h3>
        <p>
          Include <code>showExtraInfo=true</code> for more detailed pricing information:
        </p>

        <pre><code>{`GET https://api.nebex.io/v2/price?ids=So11111111111111111111111111111111111111112&showExtraInfo=true

{
    "data": {
        "So11111111111111111111111111111111111111112": {
            "id": "So11111111111111111111111111111111111111112",
            "type": "derivedPrice",
            "price": "132.176540000",
            "extraInfo": {
                "lastSwappedPrice": {
                    "lastNebexSellAt": 1726232167,
                    "lastNebexSellPrice": "132.1815918927837",
                    "lastNebexBuyAt": 1726232168,
                    "lastNebexBuyPrice": "132.3113422757551"
                },
                "quotedPrice": {
                    "buyPrice": "132.183970000",
                    "buyAt": 1726232166,
                    "sellPrice": "132.169110000",
                    "sellAt": 1726232168
                },
                "confidenceLevel": "high",
                "depth": {
                    "buyPriceImpactRatio": {
                        "depth": {
                            "10": 0.011976036126034885,
                            "100": 0.05308426581530216,
                            "1000": 0.1168049189323158
                        }
                    }
                }
            }
        }
    }
}`}</code></pre>

        <h3>Alternative Base Token</h3>
        <p>
          Use <code>vsToken</code> parameter to get prices in terms of a different token:
        </p>

        <pre><code>{`# Price in terms of BONK
GET https://api.nebex.io/v2/price?ids=So11111111111111111111111111111111111111112&vsToken=DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263

{
    "data": {
        "So11111111111111111111111111111111111111112": {
            "id": "So11111111111111111111111111111111111111112",
            "type": "derivedPrice",
            "price": "40560.32136735473"
        }
    }
}`}</code></pre>

        <h3>Rate Limits</h3>
        <table>
          <thead>
            <tr>
              <th>API</th>
              <th>Rate Limit</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Price API</td>
              <td>600 requests per minute</td>
            </tr>
            <tr>
              <td>Quote API</td>
              <td>50 requests per minute</td>
            </tr>
            <tr>
              <td>Swap API</td>
              <td>20 requests per minute</td>
            </tr>
          </tbody>
        </table>

        <h3>Response Fields</h3>
        <table>
          <thead>
            <tr>
              <th>Field</th>
              <th>Description</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td><code>type</code></td>
              <td>derivedPrice is the midpoint between buyPrice and sellPrice</td>
            </tr>
            <tr>
              <td><code>price</code></td>
              <td>The current price based on the type</td>
            </tr>
            <tr>
              <td><code>extraInfo</code></td>
              <td>Additional pricing details when requested</td>
            </tr>
            <tr>
              <td><code>confidenceLevel</code></td>
              <td>Indicates price reliability (high, medium, or low)</td>
            </tr>
          </tbody>
        </table>

        <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg mt-8">
          <h4 className="text-blue-400 mt-0">Support</h4>
          <p className="mb-0">
            If you have a use case that is not supported yet, let us know in our{' '}
            <a href="https://t.me/nebex_io" target="_blank" rel="noopener noreferrer">
              Telegram
            </a>{' '}
            or{' '}
            <a href="https://x.com/nebex_io" target="_blank" rel="noopener noreferrer">
              Twitter
            </a>.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Docs;