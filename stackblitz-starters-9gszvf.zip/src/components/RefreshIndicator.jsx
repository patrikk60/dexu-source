import React, { useEffect, useState } from 'react';

const RefreshIndicator = ({ interval, refreshKey, isRefreshing }) => {
  const [progress, setProgress] = useState(100);

  useEffect(() => {
    setProgress(100);
    
    const startTime = Date.now();
    let frameId;

    const updateProgress = () => {
      const elapsed = Date.now() - startTime;
      const newProgress = Math.max(100 - (elapsed / interval) * 100, 0);
      setProgress(newProgress);
      
      if (newProgress > 0) {
        frameId = requestAnimationFrame(updateProgress);
      }
    };

    frameId = requestAnimationFrame(updateProgress);
    
    return () => {
      if (frameId) {
        cancelAnimationFrame(frameId);
      }
    };
  }, [refreshKey, interval]);

  const size = 16;
  const strokeWidth = 2;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const dashOffset = circumference - (progress / 100) * circumference;

  return (
    <div className="relative w-4 h-4">
      <svg className="w-4 h-4 transform -rotate-90" viewBox={`0 0 ${size} ${size}`}>
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="currentColor"
          strokeWidth={strokeWidth}
          fill="none"
          className="opacity-20"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="currentColor"
          strokeWidth={strokeWidth}
          fill="none"
          strokeDasharray={circumference}
          strokeDashoffset={dashOffset}
          style={{ transition: 'stroke-dashoffset 100ms linear' }}
        />
      </svg>
      {isRefreshing && (
        <div className="absolute inset-0 animate-spin">
          <div className="w-1 h-1 bg-current rounded-full absolute top-0 left-1/2 transform -translate-x-1/2" />
        </div>
      )}
    </div>
  );
};

export default RefreshIndicator;