import React from 'react';
import LoadingNumber from './LoadingNumber';
import TokenImage from './TokenImage';

const TokenChart = ({ token, price, loading }) => {
  // Format price to always show 2 decimal places
  const formattedPrice = price ? Number(price).toFixed(2) : '0.00';

  return (
    <div className="bg-gray-900/30 rounded-xl p-4 backdrop-blur-sm border border-gray-800">
      <div className="flex items-center gap-3">
        <TokenImage 
          src={token.logoURI} 
          alt={token.symbol} 
          className="w-8 h-8 rounded-full"
        />
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <span className="text-gray-200 font-medium">{token.symbol}</span>
            <a 
              href={`https://solscan.io/token/${token.address}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs text-gray-400 hover:text-gray-200 transition-colors"
            >
              {token.address.slice(0, 4)}...{token.address.slice(-4)}
            </a>
          </div>
          <div className="text-lg font-medium mt-1">
            $<LoadingNumber 
              value={formattedPrice} 
              loading={loading}
              placeholder="0.00"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default TokenChart;