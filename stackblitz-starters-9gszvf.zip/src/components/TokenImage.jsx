import React, { useState, useEffect, useCallback } from 'react';

const DEFAULT_TOKEN_ICON =
  'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMTIgMjRDMTguNjI3NCAyNCAyNCAxOC42Mjc0IDI0IDEyQzI0IDUuMzcyNTggMTguNjI3NCAwIDEyIDBDNS4zNzI1OCAwIDAgNS4zNzI1OCAwIDEyQzAgMTguNjI3NCA1LjM3MjU4IDI0IDEyIDI0WiIgZmlsbD0iIzI1MjUyNSIvPjxwYXRoIGQ9Ik0xMiA2VjE4IiBzdHJva2U9IiM4ODgiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIi8+PHBhdGggZD0iTTE4IDEySDYiIHN0cm9rZT0iIzg4OCIgc3Ryb2tlLXdpZHRoPSIyIiBzdHJva2UtbGluZWNhcD0icm91bmQiLz48L3N2Zz4=';

// Cache for successful image loads
const imageCache = new Map();

const TokenImage = ({
  src,
  alt,
  className = 'w-8 h-8 rounded-full bg-gray-800',
}) => {
  const [imgSrc, setImgSrc] = useState(src);

  useEffect(() => {
    // Update image source when src prop changes
    if (imageCache.has(src)) {
      setImgSrc(imageCache.get(src));
    } else {
      setImgSrc(src);
    }
  }, [src]);

  const handleError = useCallback(() => {
    setImgSrc(DEFAULT_TOKEN_ICON);
    // Cache the fallback for this URL
    imageCache.set(src, DEFAULT_TOKEN_ICON);
  }, [src]);

  const handleLoad = useCallback(() => {
    // Cache successful loads
    if (imgSrc !== DEFAULT_TOKEN_ICON) {
      imageCache.set(src, src);
    }
  }, [src, imgSrc]);

  return (
    <img
      src={imgSrc}
      alt={alt}
      className={className}
      onError={handleError}
      onLoad={handleLoad}
      loading="lazy"
    />
  );
};

export default TokenImage;
