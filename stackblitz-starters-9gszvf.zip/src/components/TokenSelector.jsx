import React, { useState, useEffect } from 'react';
import { Dialog } from '@headlessui/react';
import TokenList from './TokenList';
import { formatBalance } from '../utils/jupiter';
import TokenImage from './TokenImage';
import LoadingNumber from './LoadingNumber';

const WalletIcon = () => (
  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M19 7h-1V6a3 3 0 00-3-3H5a3 3 0 00-3 3v12a3 3 0 003 3h14a3 3 0 003-3v-8a3 3 0 00-3-3zM4 18V6c0-.6.4-1 1-1h10c.6 0 1 .4 1 1v1H8a3 3 0 00-3 3v8c0 .6-.4 1-1 1s-1-.4-1-1zm16 0c0 .6-.4 1-1 1H8c-.6 0-1-.4-1-1v-8c0-.6.4-1 1-1h11c.6 0 1 .4 1 1v8z" fill="currentColor"/>
    <path d="M16 14a1 1 0 100-2 1 1 0 000 2z" fill="currentColor"/>
  </svg>
);

const TokenSelector = ({
  label,
  token,
  onSelect,
  amount,
  onAmountChange,
  readonly,
  balance,
  onMax,
  onHalf,
  usdValue,
  loading,
  walletConnected,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [localAmount, setLocalAmount] = useState('');

  useEffect(() => {
    setLocalAmount(amount || '');
  }, [amount]);

  const handleAmountChange = (value) => {
    setLocalAmount(value);
    onAmountChange?.(value);
  };

  return (
    <div className="bg-gray-900/50 p-4 rounded-xl backdrop-blur-sm border border-gray-800">
      <div className="flex justify-between items-center mb-3">
        <label className="text-sm text-gray-400">{label}</label>
        {walletConnected && (
          <div className="flex items-center gap-2 text-sm text-gray-400">
            <WalletIcon />
            <LoadingNumber value={formatBalance(balance)} loading={loading} />
            {!readonly && token && onMax && onHalf && (
              <>
                <button
                  onClick={onHalf}
                  className="text-blue-400 hover:text-blue-300 bg-blue-500/10 px-2 py-0.5 rounded"
                >
                  Half
                </button>
                <button
                  onClick={onMax}
                  className="text-blue-400 hover:text-blue-300 bg-blue-500/10 px-2 py-0.5 rounded"
                >
                  Max
                </button>
              </>
            )}
          </div>
        )}
      </div>

      <div className="flex items-center gap-4">
        <button
          className="flex items-center gap-2 bg-gray-800/80 px-4 py-2 rounded-lg hover:bg-gray-700/80 transition-colors"
          onClick={() => setIsOpen(true)}
        >
          {token ? (
            <>
              <TokenImage
                src={token.logoURI}
                alt={token.symbol}
                className="w-6 h-6 rounded-full"
              />
              <span className="text-gray-200">{token.symbol}</span>
            </>
          ) : (
            <span className="text-gray-400">Select Token</span>
          )}
        </button>

        <div className="flex-1">
          <div className="flex items-center justify-end">
            <LoadingNumber
              value={localAmount}
              loading={loading && readonly}
              placeholder="0.0"
              readOnly={readonly}
              className="w-full bg-transparent outline-none text-right text-xl text-gray-200 placeholder-gray-600"
              inputMode="decimal"
              pattern="[0-9]*[.,]?[0-9]*"
              isInput={!readonly}
              onChange={handleAmountChange}
            />
          </div>
          <div className="text-right text-sm text-gray-400 mt-1">
            ≈ $<LoadingNumber 
              value={usdValue} 
              loading={loading}
              className="inline-block"
            />
          </div>
        </div>
      </div>

      <Dialog
        open={isOpen}
        onClose={() => setIsOpen(false)}
        className="relative z-50"
      >
        <div
          className="fixed inset-0 bg-black/60 backdrop-blur-sm"
          aria-hidden="true"
        />

        <div className="fixed inset-0 flex items-center justify-center p-4">
          <Dialog.Panel className="bg-gray-900 rounded-xl p-6 max-w-md w-full border border-gray-800">
            <Dialog.Title className="text-lg font-medium mb-4 text-gray-200 flex justify-between items-center">
              Select Token
              <button
                onClick={() => setIsOpen(false)}
                className="text-gray-400 hover:text-gray-200"
              >
                ✕
              </button>
            </Dialog.Title>

            <TokenList
              onSelect={(selectedToken) => {
                onSelect(selectedToken);
                setIsOpen(false);
              }}
              selectedToken={token}
            />
          </Dialog.Panel>
        </div>
      </Dialog>
    </div>
  );
};

export default TokenSelector;