import React from 'react';

const ComingSoon = ({ feature }) => {
  return (
    <div className="container mx-auto px-4 py-24 flex-grow flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-blue-400 to-blue-600 bg-clip-text text-transparent">
          {feature}
        </h1>
        <p className="text-xl text-gray-400 mb-8">Coming Soon</p>
        <div className="flex items-center justify-center gap-4">
          <a
            href="https://t.me/nebex_io"
            target="_blank"
            rel="noopener noreferrer"
            className="text-blue-400 hover:text-blue-300 transition-colors"
          >
            Join our Telegram
          </a>
          <span className="text-gray-600">•</span>
          <a
            href="https://x.com/nebex_io"
            target="_blank"
            rel="noopener noreferrer"
            className="text-blue-400 hover:text-blue-300 transition-colors"
          >
            Follow on Twitter
          </a>
        </div>
      </div>
    </div>
  );
};

export default ComingSoon;