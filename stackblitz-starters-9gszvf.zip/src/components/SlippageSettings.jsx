import React, { useState } from 'react';

const SlippageSettings = ({ slippage, onSlippageChange }) => {
  const [isManual, setIsManual] = useState(false);
  const presets = [0.1, 0.5, 1, 2];

  return (
    <div className="bg-gray-900/50 p-4 rounded-xl backdrop-blur-sm border border-gray-800">
      <div className="flex justify-between items-center mb-3">
        <label className="text-sm text-gray-400">Slippage Tolerance</label>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsManual(false)}
            className={`text-xs px-2 py-1 rounded-md transition-colors ${
              !isManual
                ? 'bg-blue-500/20 text-blue-400'
                : 'text-gray-400 hover:bg-gray-800'
            }`}
          >
            Auto
          </button>
          <button
            onClick={() => setIsManual(true)}
            className={`text-xs px-2 py-1 rounded-md transition-colors ${
              isManual
                ? 'bg-blue-500/20 text-blue-400'
                : 'text-gray-400 hover:bg-gray-800'
            }`}
          >
            Manual
          </button>
        </div>
      </div>

      {isManual ? (
        <div className="flex gap-2">
          {presets.map((preset) => (
            <button
              key={preset}
              className={`px-3 py-1 rounded-lg transition-colors ${
                slippage === preset
                  ? 'bg-blue-500/20 text-blue-400'
                  : 'bg-gray-800 hover:bg-gray-700 text-gray-400'
              }`}
              onClick={() => onSlippageChange(preset)}
            >
              {preset}%
            </button>
          ))}

          <div className="relative flex-1">
            <input
              type="number"
              value={slippage}
              onChange={(e) =>
                onSlippageChange(parseFloat(e.target.value) || 0)
              }
              className="w-full bg-gray-800 px-3 py-1 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/50 text-gray-200"
              min="0.01"
              max="100"
              step="0.1"
            />
            <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">
              %
            </span>
          </div>
        </div>
      ) : (
        <div className="text-sm text-gray-400">
          Automatically adjusts to market conditions
        </div>
      )}
    </div>
  );
};

export default SlippageSettings;
