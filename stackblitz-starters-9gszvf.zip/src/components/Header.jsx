import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';

const Header = () => {
  const location = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const isActive = (path) => {
    return location.pathname === path ? 'text-blue-400' : 'text-gray-400';
  };

  // Prevent background scrolling when menu is open
  React.useEffect(() => {
    if (isMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isMenuOpen]);

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-50 bg-gray-900/80 backdrop-blur-md border-b border-gray-800">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-8">
            <Link to="/" className="flex items-center gap-2">
              <img src="/logo.svg" alt="Logo" className="h-8 w-8" />
              <span className="text-xl font-bold bg-gradient-to-r from-blue-400 to-blue-600 bg-clip-text text-transparent">
                Nebula Exchange
              </span>
            </Link>
            <nav className="hidden sm:flex items-center gap-6">
              <Link to="/" className={`${isActive('/')} hover:text-gray-200 transition-colors`}>
                Swap
              </Link>
              <Link to="/limit" className={`${isActive('/limit')} hover:text-gray-200 transition-colors`}>
                Limit
              </Link>
              <Link to="/dca" className={`${isActive('/dca')} hover:text-gray-200 transition-colors`}>
                DCA
              </Link>
              <Link to="/liquidity" className={`${isActive('/liquidity')} hover:text-gray-200 transition-colors`}>
                Liquidity
              </Link>
            </nav>
          </div>

          <div className="flex items-center gap-4">
            <a
              href="https://x.com/nebex_io"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-400 hover:text-gray-200 transition-colors"
            >
              <svg
                className="w-5 h-5"
                fill="currentColor"
                viewBox="0 0 24 24"
                aria-hidden="true"
              >
                <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
              </svg>
            </a>
            <a
              href="https://t.me/nebex_io"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-400 hover:text-gray-200 transition-colors"
            >
              <svg
                className="w-5 h-5"
                fill="currentColor"
                viewBox="0 0 24 24"
                aria-hidden="true"
              >
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 00-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.74-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.36.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .24z" />
              </svg>
            </a>

            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="sm:hidden text-gray-400 hover:text-gray-200 p-2"
              aria-label="Toggle menu"
            >
              <svg
                className="w-5 h-5"
                fill="none"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                {isMenuOpen ? (
                  <path d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path d="M4 6h16M4 12h16m-7 6h7" />
                )}
              </svg>
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Menu Overlay */}
      <div
        className={`fixed inset-0 bg-gray-900/95 backdrop-blur-md transition-all duration-300 ease-in-out sm:hidden ${
          isMenuOpen ? 'opacity-100 z-40' : 'opacity-0 pointer-events-none -z-10'
        }`}
        style={{ top: '64px' }}
      >
        <nav className="flex flex-col items-center justify-center min-h-[calc(100vh-64px)] gap-8 text-lg">
          <Link
            to="/"
            className={`${isActive('/')} hover:text-gray-200 transition-colors`}
            onClick={() => setIsMenuOpen(false)}
          >
            Swap
          </Link>
          <Link
            to="/limit"
            className={`${isActive('/limit')} hover:text-gray-200 transition-colors`}
            onClick={() => setIsMenuOpen(false)}
          >
            Limit
          </Link>
          <Link
            to="/dca"
            className={`${isActive('/dca')} hover:text-gray-200 transition-colors`}
            onClick={() => setIsMenuOpen(false)}
          >
            DCA
          </Link>
          <Link
            to="/liquidity"
            className={`${isActive('/liquidity')} hover:text-gray-200 transition-colors`}
            onClick={() => setIsMenuOpen(false)}
          >
            Liquidity
          </Link>
        </nav>
      </div>
    </>
  );
};

export default Header;