import React from 'react';
import { Dialog } from '@headlessui/react';

const SlippageModal = ({
  isOpen,
  onClose,
  slippage,
  onSlippageChange,
  isAutoSlippage,
  onAutoSlippage,
}) => {
  const presets = [0.1, 0.5, 1, 2];

  const handleManualMode = () => {
    if (isAutoSlippage) {
      onAutoSlippage(false); // Turn off auto mode
      onSlippageChange(1); // Set default manual slippage
    }
  };

  return (
    <Dialog open={isOpen} onClose={onClose} className="relative z-50">
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-sm"
        aria-hidden="true"
      />

      <div className="fixed inset-0 flex items-center justify-center p-4">
        <Dialog.Panel className="bg-gray-900 rounded-xl p-6 max-w-sm w-full border border-gray-800">
          <Dialog.Title className="text-lg font-medium mb-4 text-gray-200 flex justify-between items-center">
            Slippage Settings
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-200"
            >
              ✕
            </button>
          </Dialog.Title>

          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-400">Slippage Tolerance</span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => onAutoSlippage(true)}
                  className={`text-xs px-2 py-1 rounded-md transition-colors ${
                    isAutoSlippage
                      ? 'bg-blue-500/20 text-blue-400'
                      : 'text-gray-400 hover:bg-gray-800'
                  }`}
                >
                  Auto
                </button>
                <button
                  onClick={handleManualMode}
                  className={`text-xs px-2 py-1 rounded-md transition-colors ${
                    !isAutoSlippage
                      ? 'bg-blue-500/20 text-blue-400'
                      : 'text-gray-400 hover:bg-gray-800'
                  }`}
                >
                  Manual
                </button>
              </div>
            </div>

            {!isAutoSlippage ? (
              <div className="flex gap-2 flex-wrap">
                {presets.map((preset) => (
                  <button
                    key={preset}
                    className={`px-3 py-1 rounded-lg transition-colors ${
                      slippage === preset
                        ? 'bg-blue-500/20 text-blue-400'
                        : 'bg-gray-800 hover:bg-gray-700 text-gray-400'
                    }`}
                    onClick={() => onSlippageChange(preset)}
                  >
                    {preset}%
                  </button>
                ))}

                <div className="relative flex-1 min-w-[100px]">
                  <input
                    type="number"
                    value={slippage}
                    onChange={(e) =>
                      onSlippageChange(parseFloat(e.target.value) || 0)
                    }
                    className="w-full bg-gray-800 px-3 py-1 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/50 text-gray-200"
                    min="0.01"
                    max="100"
                    step="0.1"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">
                    %
                  </span>
                </div>
              </div>
            ) : (
              <div className="text-sm text-gray-400 bg-gray-800/50 p-3 rounded-lg">
                Automatically adjusts to market conditions for optimal execution
              </div>
            )}
          </div>
        </Dialog.Panel>
      </div>
    </Dialog>
  );
};

export default SlippageModal;