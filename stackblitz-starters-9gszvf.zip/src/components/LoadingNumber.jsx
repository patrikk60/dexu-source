import React from 'react';

const LoadingNumber = ({ 
  value, 
  loading, 
  prefix = '', 
  suffix = '', 
  className = '',
  placeholder = '0.0',
  readOnly = false,
  inputMode = 'text',
  pattern = '',
  isInput = false,
  onChange = () => {}
}) => {
  const displayValue = `${prefix}${value || placeholder}${suffix}`;
  
  if (loading) {
    return (
      <span 
        className={`inline-block bg-gray-700/50 rounded animate-pulse ${className}`}
        style={{ 
          width: `${displayValue.length}ch`,
          minWidth: '3ch'
        }}
      >
        {displayValue}
      </span>
    );
  }

  if (isInput) {
    return (
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        readOnly={readOnly}
        className={className}
        inputMode={inputMode}
        pattern={pattern}
      />
    );
  }

  return (
    <span className={className}>
      {displayValue}
    </span>
  );
};

export default LoadingNumber;