import React, { useEffect } from 'react';

export const NotificationTypes = {
  SUCCESS: 'success',
  ERROR: 'error',
  INFO: 'info',
};

const getNotificationStyles = (type) => {
  switch (type) {
    case NotificationTypes.SUCCESS:
      return 'bg-green-600 border-green-500 text-white';
    case NotificationTypes.ERROR:
      return 'bg-red-600 border-red-500 text-white';
    case NotificationTypes.INFO:
    default:
      return 'bg-blue-600 border-blue-500 text-white';
  }
};

const Notification = ({ message, type = NotificationTypes.INFO, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 3000);

    return () => clearTimeout(timer);
  }, [onClose, message]);

  return (
    <div className="fixed inset-x-0 top-20 z-50 flex justify-center items-center px-4">
      <div className={`${getNotificationStyles(type)} p-4 rounded-lg border shadow-lg max-w-md w-full animate-fade-in`}>
        <div className="flex items-center justify-between gap-2">
          <span className="flex-1">{message}</span>
          <button
            onClick={onClose}
            className="text-white/80 hover:text-white transition-colors"
            aria-label="Close notification"
          >
            ×
          </button>
        </div>
      </div>
    </div>
  );
};

export { Notification };