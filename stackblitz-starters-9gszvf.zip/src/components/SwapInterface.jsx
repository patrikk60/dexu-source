import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useConnection, useWallet } from '@solana/wallet-adapter-react';
import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';
import { Decimal } from 'decimal.js';
import { PublicKey, LAMPORTS_PER_SOL } from '@solana/web3.js';
import { getAssociatedTokenAddress } from '@solana/spl-token';
import TokenSelector from './TokenSelector';
import TokenChart from './TokenChart';
import SwapDetails from './SwapDetails';
import SlippageModal from './SlippageModal';
import { NotificationTypes } from './Notification';
import NotificationManager from './NotificationManager';
import { getTokenPrices, getSwapQuote, executeSwap, calculateUsdValue } from '../utils/jupiter';

const REFRESH_INTERVAL = 15000; // 15 seconds

const DEFAULT_INPUT_TOKEN = {
  symbol: 'SOL',
  name: 'Solana',
  address: 'So11111111111111111111111111111111111111112',
  decimals: 9,
  logoURI: 'https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/So11111111111111111111111111111111111111112/logo.png'
};

const DEFAULT_OUTPUT_TOKEN = {
  symbol: 'USDC',
  name: 'USD Coin',
  address: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
  decimals: 6,
  logoURI: 'https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v/logo.png'
};

const SwapInterface = () => {
  const { connection } = useConnection();
  const wallet = useWallet();
  const { publicKey, signTransaction } = wallet;
  
  const { showNotification, clearNotification, NotificationComponent } = NotificationManager();

  const [inputToken, setInputToken] = useState(DEFAULT_INPUT_TOKEN);
  const [outputToken, setOutputToken] = useState(DEFAULT_OUTPUT_TOKEN);
  const [inputAmount, setInputAmount] = useState('');
  const [slippage, setSlippage] = useState(1);
  const [isAutoSlippage, setIsAutoSlippage] = useState(true);
  const [priceImpact, setPriceImpact] = useState(null);
  const [quote, setQuote] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [balances, setBalances] = useState({});
  const [tokenPrices, setTokenPrices] = useState({});
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [isSlippageModalOpen, setIsSlippageModalOpen] = useState(false);

  const lastQuoteRequest = useRef(null);
  const lastValidQuote = useRef(null);
  const refreshTimeout = useRef(null);
  const quoteTimeout = useRef(null);

  const fetchBalances = async () => {
    if (!publicKey || !inputToken || !outputToken) return;

    try {
      const balancePromises = [inputToken, outputToken].map(async (token) => {
        if (token.address === DEFAULT_INPUT_TOKEN.address) {
          const balance = await connection.getBalance(publicKey);
          return [token.address, new Decimal(balance).div(LAMPORTS_PER_SOL).toString()];
        } else {
          const tokenAccount = await getAssociatedTokenAddress(
            new PublicKey(token.address),
            publicKey
          );
          try {
            const accountInfo = await connection.getTokenAccountBalance(tokenAccount);
            return [token.address, new Decimal(accountInfo.value.amount)
              .div(10 ** token.decimals).toString()];
          } catch (e) {
            return [token.address, '0'];
          }
        }
      });

      const newBalances = Object.fromEntries(await Promise.all(balancePromises));
      setBalances(newBalances);
    } catch (err) {
      console.error('Error fetching balances:', err);
    }
  };

  const fetchTokenPrices = useCallback(async () => {
    if (!inputToken || !outputToken) return;

    try {
      const tokenMints = [inputToken.address];
      if (outputToken.address !== DEFAULT_OUTPUT_TOKEN.address) {
        tokenMints.push(outputToken.address);
      }

      const prices = await getTokenPrices(tokenMints);
      setTokenPrices(prevPrices => ({
        ...prevPrices,
        [inputToken.address]: prices[inputToken.address]?.price || '0',
        [outputToken.address]: outputToken.address === DEFAULT_OUTPUT_TOKEN.address 
          ? '1' 
          : prices[outputToken.address]?.price || '0'
      }));
    } catch (err) {
      console.error('Error fetching token prices:', err);
    }
  }, [inputToken?.address, outputToken?.address]);

  const handleInputChange = (value) => {
    const cleanValue = value.replace(/[^\d.,]/g, '');
    const normalizedValue = cleanValue.replace(/,/g, '.');
    const parts = normalizedValue.split('.');
    if (parts.length > 2) return;
    
    if (parts[1] && parts[1].length > (inputToken?.decimals || 9)) {
      return;
    }

    try {
      if (normalizedValue === '' || normalizedValue === '.') {
        setInputAmount('');
        return;
      }

      const decimal = new Decimal(normalizedValue);
      if (decimal.isNaN() || !decimal.isFinite()) {
        return;
      }

      setInputAmount(normalizedValue);
    } catch (e) {
      console.error('Invalid number input:', e);
    }
  };

  const handleMax = () => {
    if (!inputToken || !balances[inputToken.address]) return;
    const balance = new Decimal(balances[inputToken.address]);
    
    if (inputToken.address === DEFAULT_INPUT_TOKEN.address) {
      const maxAmount = balance.sub(0.01);
      if (maxAmount.gt(0)) {
        setInputAmount(maxAmount.toString());
      } else {
        setInputAmount('0');
      }
    } else {
      setInputAmount(balance.toString());
    }
  };

  const handleHalf = () => {
    if (!inputToken || !balances[inputToken.address]) return;
    const balance = new Decimal(balances[inputToken.address]);
    
    if (inputToken.address === DEFAULT_INPUT_TOKEN.address) {
      const maxAmount = balance.sub(0.01);
      if (maxAmount.gt(0)) {
        setInputAmount(maxAmount.mul(0.5).toString());
      } else {
        setInputAmount('0');
      }
    } else {
      setInputAmount(balance.mul(0.5).toString());
    }
  };

  const fetchQuote = async () => {
    if (!inputToken || !outputToken || !inputAmount || new Decimal(inputAmount).isZero()) {
      setQuote(null);
      setPriceImpact(null);
      return;
    }

    const requestId = Date.now();
    lastQuoteRequest.current = requestId;

    try {
      setLoading(true);
      setError('');

      const quoteResponse = await getSwapQuote(
        inputToken.address,
        outputToken.address,
        inputAmount,
        inputToken.decimals,
        Math.round(slippage * 100)
      );

      if (requestId === lastQuoteRequest.current) {
        setQuote(quoteResponse);
        lastValidQuote.current = quoteResponse;
        setPriceImpact(quoteResponse.priceImpactPct);
      }
    } catch (error) {
      console.error('Error fetching quote:', error);
      setError(error.message || 'Failed to get quote');
      setQuote(null);
      setPriceImpact(null);
    } finally {
      if (requestId === lastQuoteRequest.current) {
        setLoading(false);
      }
    }
  };

  const executeSwapTransaction = async () => {
    if (!quote || !publicKey || !signTransaction) return;

    try {
      setLoading(true);
      setError('');
      clearNotification();

      showNotification('Preparing transaction...', NotificationTypes.INFO);

      const result = await executeSwap(
        quote,
        publicKey.toString(),
        connection,
        signTransaction
      );

      if (result.success) {
        setInputAmount('');
        setQuote(null);
        setPriceImpact(null);

        // Refresh balances and prices immediately
        await Promise.all([
          fetchBalances(),
          fetchTokenPrices()
        ]);

        showNotification('Swap completed successfully!', NotificationTypes.SUCCESS);
        console.log(`Transaction successful: https://solscan.io/tx/${result.txid}`);
      }
    } catch (error) {
      console.error('Error executing swap:', error);
      setError(error.message || 'Swap failed');
      showNotification(
        error.message || 'Swap failed. Please try again.',
        NotificationTypes.ERROR
      );
    } finally {
      setLoading(false);
    }
  };

  const handleSwapTokens = () => {
    const tempToken = inputToken;
    const tempAmount = quote ? new Decimal(quote.outAmount)
      .div(10 ** outputToken.decimals).toString() : '';
    
    setInputToken(outputToken);
    setOutputToken(tempToken);
    setInputAmount(tempAmount);
    
    setQuote(null);
    setPriceImpact(null);
    lastValidQuote.current = null;
  };

  useEffect(() => {
    fetchTokenPrices();
  }, [fetchTokenPrices]);

  const refreshData = useCallback(async () => {
    if (refreshTimeout.current) {
      clearTimeout(refreshTimeout.current);
    }

    setIsRefreshing(true);
    try {
      await Promise.all([
        fetchBalances(),
        fetchTokenPrices()
      ]);

      if (inputAmount && !new Decimal(inputAmount).isZero()) {
        await fetchQuote();
      }
    } finally {
      setIsRefreshing(false);
      setRefreshKey(prev => prev + 1);
      
      refreshTimeout.current = setTimeout(refreshData, REFRESH_INTERVAL);
    }
  }, [inputAmount, inputToken?.address, outputToken?.address, publicKey]);

  useEffect(() => {
    refreshData();
    return () => {
      if (refreshTimeout.current) {
        clearTimeout(refreshTimeout.current);
      }
      if (quoteTimeout.current) {
        clearTimeout(quoteTimeout.current);
      }
    };
  }, [refreshData]);

  useEffect(() => {
    if (quoteTimeout.current) {
      clearTimeout(quoteTimeout.current);
    }

    if (inputAmount && !new Decimal(inputAmount).isZero()) {
      quoteTimeout.current = setTimeout(fetchQuote, 500);
    } else {
      setQuote(null);
      setPriceImpact(null);
      setIsDetailsOpen(false);
    }

    return () => {
      if (quoteTimeout.current) {
        clearTimeout(quoteTimeout.current);
      }
    };
  }, [inputAmount, inputToken?.address, outputToken?.address, slippage]);

  const getOutputAmount = () => {
    if (!quote || !outputToken) return '';
    try {
      return new Decimal(quote.outAmount)
        .div(10 ** outputToken.decimals)
        .toString();
    } catch {
      return '';
    }
  };

  return (
    <div className="max-w-lg mx-auto">
      <div className="bg-gray-900/30 p-2 rounded-xl backdrop-blur-sm border border-gray-800 mb-4">
        <div className="mb-6 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsSlippageModalOpen(true)}
              className="text-gray-400 hover:text-gray-200 text-sm bg-gray-800/80 px-3 py-1 rounded-lg hover:bg-gray-700/80 transition-colors"
            >
              {isAutoSlippage ? 'Auto' : `${slippage}%`}
            </button>
          </div>
          <WalletMultiButton className="!bg-blue-600 hover:!bg-blue-700 !rounded-lg" />
        </div>

        <div className="space-y-4">
          <TokenSelector
            label="From"
            token={inputToken}
            onSelect={setInputToken}
            amount={inputAmount}
            onAmountChange={handleInputChange}
            balance={balances[inputToken?.address]}
            onMax={handleMax}
            onHalf={handleHalf}
            usdValue={calculateUsdValue(inputAmount, tokenPrices[inputToken?.address])}
            loading={loading || isRefreshing}
            walletConnected={!!publicKey}
          />

          <button 
            className="w-full bg-gray-800/50 hover:bg-gray-700/50 p-2 rounded-lg transition-colors text-gray-400"
            onClick={handleSwapTokens}
          >
            ↓
          </button>

          <TokenSelector
            label="To"
            token={outputToken}
            onSelect={setOutputToken}
            amount={getOutputAmount()}
            readonly
            balance={balances[outputToken?.address]}
            usdValue={calculateUsdValue(getOutputAmount(), tokenPrices[outputToken?.address])}
            loading={loading || isRefreshing}
            walletConnected={!!publicKey}
          />

          {error && (
            <div className="text-red-400 text-sm p-2 bg-red-500/10 rounded-lg">
              {error}
            </div>
          )}

          <button
            className="w-full bg-blue-600 hover:bg-blue-700 p-3 rounded-lg font-bold disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            disabled={!quote || !publicKey || loading}
            onClick={executeSwapTransaction}
          >
            {loading ? 'Processing...' : 'Swap'}
          </button>

          <SwapDetails
            quote={quote}
            inputToken={inputToken}
            outputToken={outputToken}
            inputAmount={inputAmount}
            priceImpact={priceImpact}
            isOpen={isDetailsOpen}
            onToggle={() => setIsDetailsOpen(!isDetailsOpen)}
            loading={loading || isRefreshing}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <TokenChart 
          token={inputToken}
          price={tokenPrices[inputToken?.address]}
          loading={loading || isRefreshing}
        />
        <TokenChart 
          token={outputToken}
          price={tokenPrices[outputToken?.address]}
          loading={loading || isRefreshing}
        />
      </div>

      <SlippageModal
        isOpen={isSlippageModalOpen}
        onClose={() => setIsSlippageModalOpen(false)}
        slippage={slippage}
        onSlippageChange={setSlippage}
        isAutoSlippage={isAutoSlippage}
        onAutoSlippage={setIsAutoSlippage}
      />
      
      {NotificationComponent}
    </div>
  );
};

export default SwapInterface;