import React from 'react';
import { Link } from 'react-router-dom';

const LiquidityPage = () => {
  return (
    <main className="container mx-auto px-4 py-24 flex-grow">
      <div className="max-w-2xl mx-auto text-center">
        <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-blue-400 to-blue-600 bg-clip-text text-transparent">
          Liquidity Pools
        </h1>
        <p className="text-xl text-gray-400 mb-8">
          Provide liquidity to earn fees from trades and participate in the Nebula Exchange ecosystem.
        </p>
        <div className="flex flex-col items-center gap-6">
          <div className="flex items-center justify-center gap-4">
            <a
              href="https://t.me/nebex_io"
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-400 hover:text-blue-300 transition-colors"
            >
              Join our Telegram
            </a>
            <span className="text-gray-600">•</span>
            <a
              href="https://x.com/nebex_io"
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-400 hover:text-blue-300 transition-colors"
            >
              Follow on Twitter
            </a>
          </div>
          <Link
            to="/"
            className="px-6 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors"
          >
            Back to Swap
          </Link>
        </div>
      </div>
    </main>
  );
};

export default LiquidityPage;