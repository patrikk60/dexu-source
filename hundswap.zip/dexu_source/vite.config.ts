import { defineConfig, loadEnv } from 'vite';
import tsconfigPaths from 'vite-tsconfig-paths';
import vue from '@vitejs/plugin-vue';
import vuetify from 'vite-plugin-vuetify';
import { nodePolyfills } from 'vite-plugin-node-polyfills';

export default defineConfig(({ command, mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  return {
    define: {
      'process.env': env, // Exposes all env variables (not recommended)
    },
    plugins: [
      vue(),
      tsconfigPaths({ loose: true }),
      vuetify({ autoImport: true }), // Enabled by default
      nodePolyfills({
        include: ['path', 'stream', 'util'],
        exclude: ['http'],
        globals: {
          Buffer: true,
          global: true,
          process: true,
        },
        overrides: {
          fs: 'memfs',
        },
        protocolImports: true,
      }),
    ],
    // ... other vite configuration
  };
});
