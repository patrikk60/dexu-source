vite.config.ts dev wont work with crypto enabled but build wont build without it
