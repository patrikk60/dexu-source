const express = require("express");
const app = express();
const cors = require("cors");
const fetch = require("node-fetch");
const dotenv = require("dotenv");
const path = require("path");
dotenv.config();

// app.use(cors());
app.use(express.json());

app.use(express.static(path.join(__dirname, "Dexu")));

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "Dexu", "index.html"));
});

app.get("/index.html", (req, res) => {
  res.sendFile(path.join(__dirname, "Dexu", "index.html"));
});

// Get the currency list
app.get("/api", async (req, res) => {
  try {
    const response = await fetch("https://api.easybit.com/currencyList", {
      method: "GET",
      headers: {
        "api-key": process.env.API_KEY,
      },
    });

    const data = await response.json();
    res.send(data);
  } catch (error) {
    console.log("Error:", error);
    console.log("Error stack:", error.stack);
    res.status(500).send(`Something went wrong ${error}`);
  }
});

// Get exchange rate
app.get("/api/rate", async (req, res) => {
  try {
    const coinToSend = req.query.send;
    const coinToReceive = req.query.receive;
    const networkToSend = req.query.sendNetwork;
    const networkToReceive = req.query.receiveNetwork;
    const amount = req.query.amount;
    const setAmountToReceive = req.query.amountType;

    // Check if required query parameters are present
    if (coinToSend && coinToReceive && networkToSend && networkToReceive) {
      let url = `https://api.easybit.com/rate?send=${coinToSend}&receive=${coinToReceive}&sendNetwork=${networkToSend}&receiveNetwork=${networkToReceive}&amount=1`;

      if (amount && !setAmountToReceive) {
        url = `https://api.easybit.com/rate?send=${coinToSend}&receive=${coinToReceive}&sendNetwork=${networkToSend}&receiveNetwork=${networkToReceive}&amount=${amount}`;
      } else if (amount && setAmountToReceive) {
        url = `https://api.easybit.com/rate?send=${coinToSend}&receive=${coinToReceive}&sendNetwork=${networkToSend}&receiveNetwork=${networkToReceive}&amount=${amount}&amountType=receive`;
      }

      const response = await fetch(url, {
        headers: {
          "api-key": process.env.API_KEY,
        },
      });

      if (!response.ok) {
        console.log(
          `Error fetching data from external API: ${response.status}`
        );
      }

      const data = await response.json();
      res.send(data);
    } else {
      res.status(400).json({ message: "Missing required query parameters" });
    }
  } catch (error) {
    console.log("Error fetching Rate from external API:", error);
    res.status(500).json({ message: "Error fetching Rate from external API" });
  }
});

app.get("/api/validateAddress", async (req, res) => {
  try {
    const currency = req.query.currency;
    const address = req.query.address;
    const network = req.query.network;
    const tag = req.query.tag;

    let url = `https://api.easybit.com/validateAddress?currency=${currency}&address=${address}&network=${network}`;

    if (tag) {
      url = `https://api.easybit.com/validateAddress?currency=${currency}&address=${address}&network=${network}&tag=${tag}`;
    }

    const response = await fetch(url, {
      headers: {
        "api-key": process.env.API_KEY,
      },
    });

    if (!response.ok) {
      console.log(`Error fetching data from external API: ${response.status}`);
    }

    const data = await response.json();
    res.send(data);
  } catch (error) {
    console.log("Error fetching ValidateAddress from external API:", error);
    res
      .status(400)
      .json({ message: "Error fetching ValidateAdress from external API" });
  }
});

app.post("/api/placeOrder", async (req, res) => {
  const send = req.body.send;
  const receive = req.body.receive;
  const amount = req.body.amount;
  const receiveAddress = req.body.receiveAddress;
  const sendNetwork = req.body.sendNetwork;
  const receiveNetwork = req.body.receiveNetwork;
  const receiveTag = req.body.receiveTag;
  const userDeviceId = req.body.userDeviceId;

  const url = "https://api.easybit.com/order";

  let requestBody;

  if (receiveTag == undefined) {
    requestBody = {
      send: `${send}`,
      receive: `${receive}`,
      amount: `${amount}`,
      receiveAddress: `${receiveAddress}`,
      sendNetwork: `${sendNetwork}`,
      receiveNetwork: `${receiveNetwork}`,
      userDeviceId: `${userDeviceId}`,
    };
  } else if (receiveTag) {
    requestBody = {
      send: `${send}`,
      receive: `${receive}`,
      amount: `${amount}`,
      receiveAddress: `${receiveAddress}`,
      sendNetwork: `${sendNetwork}`,
      receiveNetwork: `${receiveNetwork}`,
      receiveTag: `${receiveTag}`,
      userDeviceId: `${userDeviceId}`,
    };
  }

  console.log(requestBody);

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "API-KEY": process.env.API_KEY,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(requestBody),
    });

    const responseData = await response.json();
    res.json(responseData);
  } catch (error) {
    console.error("Error:", error);
    res
      .status(500)
      .json({ error: "An error occurred while fetching data from the API." });
  }
});

app.get("/api/getOrderStatus", async (req, res) => {
  const orderId = req.query.id;

  let url = `https://api.easybit.com/orderStatus?id=${orderId}`;

  try {
    const response = await fetch(url, {
      headers: {
        "api-key": process.env.API_KEY,
      },
    });

    if (!response.ok) {
      console.log(`Error fetching data from external API: ${response.status}`);
      res
        .status(400)
        .json({ message: "Error fetching getOrderStatus from external API" });
    }

    const data = await response.json();
    res.send(data);
    console.log(data);
  } catch (error) {
    console.log(`Error fetching getOrderStatus from external API: ${error}`);
    res
      .status(400)
      .json({ message: "Error fetching getOrderStatus from external API" });
  }
});

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
