/**
 * main.ts
 *
 * Bootstraps Vuetify and other plugins then mounts the App`
 */

// Plugins
import { registerPlugins } from '@/plugins'
import preventZoomMixin from '@/mixins/preventZoomMixin';

// Components
import App from './App.vue'

// Composables
import { createApp } from '@vue/runtime-dom'

const app = createApp(App)

app.mixin(preventZoomMixin);
registerPlugins(app)

app.mount('#app')
