import {
  CoinResponseItem,
  Coin
} from "@/interfaces";


const trending = [
  { coin: 'BTC', network: 'BTC' },
  { coin: 'ETH', network: 'ERC20' },
  { coin: 'XMR', network: 'MONERO' },
  { coin: 'BNB', network: 'BEP20' },
  { coin: 'USDC', network: 'ERC20' },
  { coin: 'USDT', network: 'ERC20' },
  { coin: 'USDT', network: 'TRC20' }
]

const getCryptoImage = (name: string, currency: string): string => {
  let coinName = name.toLowerCase().replace(/[ .]/g, "-");
  let coinTicker = currency.toLowerCase();
  let icon = ""

  icon = `https://cryptologos.cc/logos/${coinName}-${coinTicker}-logo.svg`;


  if (coinTicker == 'eth') {
    icon = '/public/images/coins/etherium.svg';
  } else if (coinTicker == 'xmr') {
    icon = '/public/images/coins/xmr.svg'
  }
  else if (coinTicker == 'bat') {
    icon = 'https://cryptologos.cc/logos/basic-attention-token-bat-logo.svg';
  } else if (coinTicker == 'ape') {
    icon = 'https://cryptologos.cc/logos/apecoin-ape-ape-logo.svg';
  } else if (coinTicker == 'busd') {
    icon = 'https://cryptologos.cc/logos/binance-usd-busd-logo.svg';
  } else if (coinTicker == 'bnb') {
    icon = 'https://cryptologos.cc/logos/bnb-bnb-logo.svg';
  } else if (coinTicker == 'dot') {
    icon = 'https://cryptologos.cc/logos/polkadot-new-dot-logo.svg';
  } else if (coinTicker == 'xlm') {
    icon = 'https://cryptologos.cc/logos/stellar-xlm-logo.svg';
  } else if (coinTicker == 'xrp') {
    icon = 'https://cryptologos.cc/logos/xrp-xrp-logo.svg';
  } else if (coinTicker == 'audio') {
    icon = 'https://marketcap.ru/static/img/coins/audius.svg';
  }

  return icon;
}

const usePrepareCoinsList = (coinsResp: CoinResponseItem[]) => {
  const t: Coin[] = []

  const coins: Coin[] = []
  coinsResp.forEach(el => {
    el.networkList.forEach(network => {
      const item = {
        key: el.currency.toLowerCase() + "-" + network.network.toLowerCase(),
        name: el.name,
        code: el.currency,
        network: network.name,
        networkCode: network.network,
        isTrending: trending.some(obj => obj.coin === el.currency && obj.network === network.network),
        receiveDecimals: network.receiveDecimals,
        sendStatus: network.sendStatus,
        receiveStatus: network.receiveStatus,
        iconURL: getCryptoImage(el.name, el.currency),
      }

      if ((item.code === "BTC" && item.networkCode === "BTC") || (item.code === "ETH" && item.networkCode === "ETH")) {
        t.push(item)
      } else {
        coins.push(item)
      }
    })
  })

  t.sort((a, b) => a.code.localeCompare(b.name))

  return [...t, ...coins]
}

export default usePrepareCoinsList;