const useDebounce = (): ((func: () => void, delayMs?: number) => void) => {
  let timeout: ReturnType<typeof setTimeout> | null = null;

  return function (func: () => void, delayMs: number = 500) {
    clearTimeout(timeout!);
    timeout = setTimeout(() => {
      func();
    }, delayMs);
  };
};

export default useDebounce