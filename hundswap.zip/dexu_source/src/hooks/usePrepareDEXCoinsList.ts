import { CoinResponseItem, Coin } from "@/interfaces";
import { DEXNetwork } from "@/plugins/dex";
import { TokenInfo } from "@solana/spl-token-registry";

const trending = ["HUND", "SOL", "USDC", "USDT", "WIF"];

const usePrepareDEXCoinsList = (tknInfo: TokenInfo[]) => {
  // console.log({ tknInfo }, "preparedex");
  // const t: Coin[] = [];

  const coins: Coin[] = [];
  tknInfo.forEach((tkn: TokenInfo) => {
    const item = {
      key: tkn.symbol + "-" + tkn.address,
      name: tkn.name,
      code: tkn.symbol,
      network: DEXNetwork,
      networkCode: tkn.address,
      isTrending: trending.some(
        (name) => name === tkn.symbol || name === tkn.name
      ),
      receiveDecimals: tkn.decimals,
      sendStatus: true,
      receiveStatus: true,
      iconURL: tkn.logoURI || "",
    };
    coins.push(item);
  });
  return coins;
};

export default usePrepareDEXCoinsList;
