export enum Size {
  Normal = "sz-normal",
  Small = "sz-small",
}

export enum FlexDirection {
  Column = "flex-column",
  Row = "flex-row",
}

export enum SwapType {
  Send = "send",
  Receive = "receive",
}

export enum ToastMessageKind {
  Error = "error",
  Positive = "positive",
  Wait = "wait",
}

export enum OrderStatusKind {
  AwaitingDeposit = "Awaiting Deposit",
  ConfirmingDeposit = "Confirming Deposit",
  Exchanging = "Exchanging",
  Sending = "Sending",
  Complete = "Complete",
  Refund = "Refund",
  Failed = "Failed",
  VolatilityProtection = "Volatility Protection",
  ActionRequest = "Action Request",
  RequestOverdue = "Request Overdue",
}

export interface ToastMessage {
  message: string;
  kind: ToastMessageKind;
}

export interface Coin {
  key: string; // name-networkCode
  name: string;
  code: string;
  network: string;
  networkCode: string;
  isTrending: boolean;
  receiveDecimals: number;
  sendStatus: boolean;
  receiveStatus: boolean;
  iconURL: string;
}

export interface Network {
  network: string;
  name: string;
  isDefault: boolean;
  sendStatus: boolean;
  receiveStatus: boolean;
  receiveDecimals: number;
}

export interface CoinResponseItem {
  name: string;
  currency: string;
  sendStatusAll: boolean;
  receiveStatusAll: boolean;
  networkList: Network[];
}

export interface FetchCoinsResponse {
  success: number | boolean;
  data: CoinResponseItem[];
}

export interface ValidateAddressRequest {
  currency: string;
  address: string;
  network: string;
}

export interface PlaceCEXOrderRequest {
  amount: number;
  receive: string;
  receiveAddress: string;
  receiveNetwork: string;
  send: string;
  sendNetwork: string;
  userDeviceId: string;
}

export interface PlaceCEXOrderResponse {
  id: string;
  send: string;
  receive: string;
  sendNetwork: string;
  receiveNetwork: string;
  sendAmount: string;
  receiveAmount: string;
  sendAddress: string;
  sendTag: string;
  receiveAddress: string;
  receiveTag: string;
  refundAddress: string;
  refundTag: string;
  vpm: string;
  createdAt: number;
}

export interface OrderStatusResponse {
  id: string;
  status: OrderStatusKind;
  receiveAmount: string;
  hashIn?: string;
  hashOut?: string;
  createdAt: number;
  updatedAt?: number;
}

export interface FetchRateRequest {
  send: string;
  receive: string;
  sendNetwork: string;
  receiveNetwork: string;
  amount?: number;
  amountType?: string;
}

export interface FetchRateResponse {
  rate: number;
  sendAmount: number;
  receiveAmount: number;
  minimumAmount: number;
  maximumAmount: number;
}

export interface APIResponse {
  success: number | boolean;
  errorCode?: number;
  errorMessage?: string;
  data: any;
}

export interface PriceTick {
  address: string;
  unixTime: number;
  value: number;
}
