export const SOLANA_RPC =
  process.env.VITE_SOLANA_RPC || "https://api.devnet.solana.com";
// console.log({ SOLANA_RPC });
