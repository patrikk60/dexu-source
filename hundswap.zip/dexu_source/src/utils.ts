import { QuoteResponse } from "@jup-ag/api";

export function truncateMiddle(str: string, maxLength: number = 12) {
  if (str.length <= maxLength) {
    return str;
  }

  var start = Math.ceil(maxLength / 2);
  var end = Math.floor(maxLength / 2);
  return str.slice(0, start) + " ... " + str.slice(-end);
}
export const parseQuote = (quote: QuoteResponse) => {
  return Object.entries(quote).reduce(
    (acc, [key, value]) => {
      //@ts-ignore
      acc[key as keyof QuoteResponse] = !Number.isNaN(Number(value))
        ? Number(value)
        : value;
      return acc;
    },
    {} as QuoteResponse & {
      inAmount: number;
      outAmount: number;
      slippageBps: number;
      otherAmountThreshold: number;
    }
  );
};

export const formatAmount = (amount: number) =>
  new Intl.NumberFormat("en-US", {}).format(amount);
