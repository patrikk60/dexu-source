import { RouteRecordRaw, createRouter, createWebHistory } from "vue-router";
import HomePage from "@/views/Home.vue";
import OrderPage from "@/views/Order.vue";
import HelpPage from "@/views/Help.vue";
import ComingSoonPage from "@/views/ComingSoon.vue";
import { ToastMessageKind } from "@/interfaces";

import useStore from "@/store";

const routes: Array<RouteRecordRaw> = [
  {
    path: "/",
    component: HomePage,
  },
  {
    path: "/order",
    component: OrderPage,
    beforeEnter(to, from, next) {
      const store = useStore();

      if (!store.getOrder) {
        store.setToastMessage(
          "You don't have any existing orders",
          ToastMessageKind.Error
        );
        next("/");
      } else {
        next();
      }
    },
  },
  {
    path: "/nft",
    component: ComingSoonPage,
  },
  {
    path: "/shop",
    component: ComingSoonPage,
  },
  {
    path: "/help",
    component: HelpPage,
  },
];

const router = createRouter({
  history: createWebHistory(process.env.VITE_BASE_URL),
  scrollBehavior(to, from, savedPosition) {
    // always scroll to top
    return { top: 0 };
  },
  routes,
});

export default router;
