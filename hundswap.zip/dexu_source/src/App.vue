<template>
  <v-app>
    <transition name="slide">
      <Toast />
    </transition>
    <NavBar />
    <NavigationDrawer />
    <v-main style="display: flex;flex-direction: column;">
      <container class="main-container">
        <router-view />
      </container>
      <Footer />
    </v-main>
  </v-app>
</template>

<script
  setup
  lang="ts"
>
import NavBar from '@/components/layout/NavBar.vue'
import Footer from '@/components/layout/Footer.vue'
import Container from '@/components/Container.vue'
import Toast from '@/components/Toast.vue'
import NavigationDrawer from '@/components/layout/NavigationDrawer.vue'
</script>
<style>
* {
  touch-action: manipulation;
}
</style>
