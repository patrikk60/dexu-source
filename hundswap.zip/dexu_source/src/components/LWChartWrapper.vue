<script setup lang="ts">
import {
  ref,
  onMounted,
  onUnmounted,
  watch,
  defineExpose,
  defineProps,
  computed,
  reactive,
} from "vue";
import { IChartApi, createChart, ISeriesApi } from 'lightweight-charts';
import { nextTick } from "vue";

const props = defineProps({
  type: {
    type: String,
    default: "line",
  },
  data: {
    type: Array,
    required: true,
  },
  autosize: {
    default: true,
    type: Boolean,
  },
  chartOptions: {
    type: Object,
  },
  seriesOptions: {
    type: Object,
  },
  timeScaleOptions: {
    type: Object,
  },
  priceScaleOptions: {
    type: Object,
  },
  areaOptions: {
    type: Object,
  },
});

// Function to get the correct series constructor name for current series type.
function getChartSeriesConstructorName(type) {
  return `add${type.charAt(0).toUpperCase() + type.slice(1)}Series`;
}

// Lightweight Charts™ instances are stored as normal JS variables
// If you need to use a ref then it is recommended that you use `shallowRef` instead

//@ts-ignore
let series:ISeriesApi;
let chart: IChartApi;
const chartContainer = ref();

const crossHairPrice = ref<number | undefined>(undefined);
const crossHairTime = ref<number | undefined>(undefined);

const fitContent = () => {
  if (!chart) return;
  chart.timeScale().fitContent();
};

const getChart = () => {
  return chart;
};

defineExpose({ fitContent, getChart });

// Auto resizes the chart when the browser window is resized.
const resizeHandler = () => {
  // console.log("resizeHandler");
  if (!chart || !chartContainer.value) return;
  const dimensions = chartContainer.value.getBoundingClientRect();
  // console.log(dimensions);
  const hasPadding = false;
  chart.resize(dimensions.width - (hasPadding ? 56 : 0), 100);
};
nextTick(resizeHandler);

// Creates the chart series and sets the data.
const addSeriesAndData = (props) => {
  const seriesConstructor = getChartSeriesConstructorName(props.type);
  // @ts-ignore
  series = chart[seriesConstructor](props.seriesOptions);
  series.setData(props.data);
  series.applyOptions(props.seriesOptions);

};

onMounted(() => {
  // Create the Lightweight Charts Instance using the container ref.
  chart = createChart(chartContainer.value, props.chartOptions);
  addSeriesAndData(props);
  if (props.priceScaleOptions) {
    chart.priceScale().applyOptions(props.priceScaleOptions);
  }

  if (props.areaOptions) {
  }

  if (props.timeScaleOptions) {
    chart.timeScale().applyOptions(props.timeScaleOptions);
  }
  chart.timeScale().fitContent();
  chart.subscribeClick((param) => {
    const seriesConstructor = getChartSeriesConstructorName(props.type);
    //@ts-ignore
    series = chart[seriesConstructor](props.seriesOptions);
    const data = param.seriesData.values().next().value;
    chart.setCrosshairPosition(data.value, data.time, series);
    nextTick(
      () => {
        crossHairPrice.value = data.value;
        crossHairTime.value = data.time;
      }
    )
  });
  chart.subscribeCrosshairMove((param) => {
    const newCrossHairPrice = param.seriesData.values().next().value;
    nextTick(() => {
      crossHairPrice.value = newCrossHairPrice?.value;
      crossHairTime.value = newCrossHairPrice?.time;
    });
  });

  // if (props.autosize) {
  window.addEventListener("resize", resizeHandler);
  // }
});
onUnmounted(() => {
  if (chart) {
    chart.remove();
    chart = null;
  }
  if (series) {
    series = null;
  }
  window.removeEventListener("resize", resizeHandler);
});

/*
 * Watch for changes to any of the component properties.

 * If an options property is changed then we will apply those options
 * on top of any existing options previously set (since we are using the
 * `applyOptions` method).
 *
 * If there is a change to the chart type, then the existing series is removed
 * and the new series is created, and assigned the data.
 *
 */
watch(
  () => props.autosize,
  (enabled) => {
    if (!enabled) {
      window.removeEventListener("resize", resizeHandler);
      return;
    }
    window.addEventListener("resize", resizeHandler);
  }
);

watch(
  () => props.type,
  (newType) => {
    if (series && chart) {
      chart.removeSeries(series);
    }
    addSeriesAndData(props);
  }
);

watch(
  () => props.data,
  (newData) => {
    // console.log(newData);
    if (!series) return;
    series.setData(newData);
    let lastDataPoint;
    for (const entry of series.data().entries()) {
      const  p = entry.pop()
      if(p)
      lastDataPoint = p
    }
    // Set the crosshair position to the last data point
    chart.setCrosshairPosition(lastDataPoint.value , lastDataPoint.time, series);

  }
);

watch(
  () => props.chartOptions,
  (newOptions) => {
    if (!chart) return;
    chart.applyOptions(newOptions);
  }
);

watch(
  () => props.seriesOptions,
  (newOptions) => {
    if (!series) return;
    series.applyOptions(newOptions);
  }
);

watch(
  () => props.priceScaleOptions,
  (newOptions) => {
    if (!chart) return;
    chart.priceScale().applyOptions(newOptions);
  }
);

watch(
  () => props.timeScaleOptions,
  (newOptions) => {
    if (!chart) return;
    chart.timeScale().applyOptions(newOptions);
  }
);
const formatDate = (time) => {
  return new Date(time * 1000).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "numeric",
    hour12: true,
  });
};
const formattedCrossHairTime = computed(() => {
  return formatDate(crossHairTime.value);
});
watch(crossHairPrice, (newPrice) => {
  // console.log("Crosshair Price:", newPrice);
});
watch(formattedCrossHairTime, (newTime) => {
  // console.log("Crosshair Time:", newTime);
  // console.log("Formatted Time:", formatDate(newTime));
});
</script>

<template>
  <div class="lw-chart" ref="chartContainer">
    <div class="crosshair-container">
      <div class="crosshair-price" v-if="crossHairPrice && crossHairTime">
        {{ formattedCrossHairTime }} - ${{
          crossHairPrice > 1
            ? crossHairPrice?.toFixed(2)
            : crossHairPrice?.toFixed(6)
        }}
      </div>
    </div>
  </div>
</template>

<style scoped>
.lw-chart {
  height: 100%;
  position: relative;
  /* padding-bottom: 28px */
}
.lw-chart::after {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: inherit;
  z-index: 1;
  pointer-events: none;
  filter: blur(10px);
  margin: -30px;
  padding: 30px;
}
.crosshair-container {
  height: 30px; /* Adjust this to match the height of your crosshair-price element */
}
.crosshair-price {
  position: sticky;
  width: 182px;
  margin-left: auto;
  margin-right: 60px;
  z-index: 100;
  display: flex;
}

@media screen and (min-width: 485px) {
  /* .crosshair-price {
    top: 50%;
    right: -4px;
    flex-direction: row;
  } */
}
</style>
