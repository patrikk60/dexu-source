<template>
  <section class="site-info">
    <!-- <h1 class="section-heading">Swap</h1> -->
    <div class="exchange-type-links">
      <span>{{ store.selectedExchangeType=="CEX"?"CROSS-CHAIN":"SOLANA" }}</span>
      <span style="padding: 0 1rem 0 1rem">|</span>
      <v-btn @click="toggleExchangeType">Change</v-btn>
    </div>
    <br />
    <!-- <p>
      Swap your coins with the best liquidity and the lowest slippage thanks to
      our AI powered cross-chain platform.
    </p> -->
  </section>
</template>

<script setup lang="ts">
import { watch } from 'vue';
import useStore from '@/store';

const store = useStore();

const toggleExchangeType = () => {
  const newExchangeType = store.selectedExchangeType === 'CEX' ? 'DEX' : 'CEX';
  store.setExchangeType(newExchangeType);
  window.scrollTo({ top: 0, behavior: 'smooth' });
};
// Watch for changes in selectedExchangeType and log the value
watch(
  () => store.selectedExchangeType,
  (newValue, oldValue) => {
    // console.log('selectedExchangeType changed:', newValue);
  }
);
</script>

<style lang="scss" scoped>
.exchange-type-links {
  display: flex;
  justify-content: center;
  align-items: center;
}
.site-info {
  text-align: center;
  margin-bottom: 2rem;
  padding: 0 10px;

  h1 {
    text-transform: uppercase;
    font-size: 2rem;
    font-weight: 400;
    margin-bottom: 1rem;
  }
}
</style>
