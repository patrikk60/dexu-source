<template>
  <div

    style="
      width: 100%;
      margin-top: 56px;
      align-items: center;
      display: flex;
      flex-direction: row;
    "
    class="coin-chart-container"
  >
    <div class="coin-logo chart-coin-logo-l mr-6">
      <img :src="coin.iconURL" @error="handleCoinSourceError" />
    </div>
    <div class="flex chart-coin-info relative flex-col">
      <div class="coin-logo chart-coin-logo-s mr-6">
        <img :src="coin.iconURL" @error="handleCoinSourceError" />
      </div>
      <span
        :class="{
          'swap-network': true,
          'sn-bordered': true,
          pos: pctChange >= 0,
          neg: pctChange < 0,
        }"
      >
        {{ pctChange.toFixed(1) }}%
      </span>
      <h1 class="swap-coin">{{ coin.code }}</h1>
      <span class="swap-network code sn-bordered" v-on:click="openExplorer">{{
        networkDisplay

      }}  <i class="fas fa-external-link-alt ml-2"></i>
</span>
    </div>
    <LWChart
      :type="chartType"
      :data="data"
      :autosize="true"
      :chart-options="chartOptions"
      :series-options="seriesOptions"
      ref="lwChart"
    />
  </div>
</template>

<style scoped>
.swap-network i{
  color:rgb(var(--v-theme-primary));
}
.swap-network.code{
  min-width: 145px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
@media screen and (max-width:356px) {
  .swap-network {
    font-size: small
  }
}
.coin-logo {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 4.5rem;
  img {
    width: 80px;
    height: 80px;
    border-radius: 100%;
    object-fit: cover;
    border: 2px solid white;
  }
}
.chart-container {
  display: block; /* Not 'none' */
  visibility: visible; /* Not 'hidden' */
  opacity: 1; /* Fully visible */
  z-index: 10;
  width: 100%;
  height: 100%;
}
.lw-chart {
  flex-grow: 1;
  margin-left: 20px;
  margin-top: -40px;
  /* width: 40vw; */
  /* max-width: 300px */
}
/* .chart-container{
  width: 100%;
  margin-top: 32px;
  align-items: center;
  display: flex;
  flex-direction: row;
} */
/* .coin-info{
  text-align: start;
} */
.chart-coin-logo-s {
  display: none;
}
.chart-coin-info {
  min-width: 145px;
}
@media screen and (max-width: 776px) {
  .chart-container {
    /* flex-wrap: wrap; */
  }
  .lw-chart {
    width: 30vw;
    /* max-width: 49%; */
    overflow: hidden;
  }
  .lw-chart table{
    /* overflow: hidden; */
  }
  .chart-coin-logo-s {
    display: block;
  }
  .chart-coin-logo-l {
    display: none;
  }
  .chart-coin-info {
    margin-top: auto;
    text-align: left;
    position: relative;
  }
  .chart-coin-logo-s,
  .chart-coin-logo-s img {
    /* position: absolute;
        height: 30px !important;
        width: 30px !important;
        top: 2.5px;
        left: 0px; */
    position: absolute;
    height: 66px !important;
    width: 66px !important;
    top: -6px;
    right: -12px;
  }
  .chart-coin-info .swap-coin {
    font-size: x-large;
  }
}
@media screen and (min-width: 776px) {
  .lw-chart {
    margin-left: 30px;
  }
}
@media screen and (min-width: 776px) and (max-width: 1280px) {
  .lw-chart {
    width: 240px;
  }
}
@media screen and (max-width: 420px) {
  .chart-container {
    /* flex-wrap: wrap; */
  }
  .lw-chart {
    width: 35vw;
  }
  }
</style>

<script setup lang="ts">
import { ref, onMounted, computed, watch, toRef } from "vue";
import { ColorType } from "lightweight-charts";
import LWChart from "./LWChartWrapper.vue";
import { truncateMiddle } from "@/utils";
import useStore from "@/store";
import { Coin } from "@/interfaces";
import { PriceTick } from "../interfaces/index";
import "chartjs-adapter-date-fns";
// import actions from "../store/actions";
// import { aliases } from 'vuetify/iconsets/fa';

const props = defineProps<{
  coin: Coin;
}>();
const coin = toRef(props, 'coin');

const handleCoinSourceError = () => {
  coin.value.iconURL = "/public/images/coins/unknownCoin.svg";
};
const openExplorer = () => {
  window.open("https://solscan.io/account/" + coin.value.networkCode, "_blank");
};
const store = useStore();
const ticks = ref<PriceTick[]>([]);
const pctChange = computed(() => {
  if (ticks.value.length < 2) return 0;
  const first = ticks.value[0].value;
  const last = ticks.value[ticks.value.length - 1].value;
  return ((last - first) / first) * 100;
});
watch(ticks, (newTicks) => {
  // console.log("Ticks updated:", newTicks.values);
});

const fetchCoinHistory = async () => {
  try {
    const fetchedTicks = await store.fetchDEXCoinHistory(coin.value.networkCode);
    if (fetchedTicks && Array.isArray(fetchedTicks)) {
      ticks.value = fetchedTicks.sort((a, b) => a.unixTime - b.unixTime);
    } else {
      ticks.value = []; // Set default empty array on error

      console.error("Invalid data format received:", fetchedTicks);
    }
  } catch (error) {
    ticks.value = []; // Set default empty array on error

    console.error("Failed to fetch coin history:", error);
  }
}
watch(()=>props.coin, fetchCoinHistory, { immediate: true });

onMounted(fetchCoinHistory);

const networkDisplay = computed(() => {
  return coin.value.network != "SOL"
    ? coin.value.network
    : coin.value.networkCode.toUpperCase().startsWith("SO111111111111")
    ? truncateMiddle(coin.value.networkCode, 24)
    : truncateMiddle(coin.value.networkCode, 10);
});
const data = computed(() =>
  ticks.value.map((tick) => ({ time: tick.unixTime, value: tick.value }))
);
const chartOptions = ref({
  layout: {

    background: { type: ColorType.Solid, color: "rgb(18,18,18)" },
    color: { type: ColorType.Solid, color: "rgb(18,18,18)" },
    padding: {
      right: 0,
    },
  },
  priceScaleOptions: {
    scaleType: 'IndexedTo100',
  },
  priceScale: {
    borderVisible: false,
  },
  timeScale: {
    borderVisible: false,
    visible: false,

  },
  crosshair: {
    mode: 3,
    horzLine: {
      // labelBackgroundColor: "rgb(18,18,18)",
      // labelVisible: true,
      visible: false,
    },
    vertLine: {
      visible: true,
      // labelVisible: true
    },
  },
  grid: {
    vertLines: {
      visible: false,
    },
    horzLines: {
      visible: false,
    },
  },
  rightPriceScale: {
    visible: false,
    drawTicks: false,
    scaleLabelVisible: false,
    textColor: "rgb(18,18,18)",
    // maximumWidth:30,
    borderVisible: false,
    // scaleMargins: {
    //   top: 0.1,
    //   bottom: 0.1,
    // },
  },
  leftPriceScale: {
    visible: false,
  },
  handleScale: {
    axisPressedMouseMove: false,
    mouseWheel: false,
    pinch: false,
  },
  handleScroll: {
    vertTouchDrag: false,
    horzTouchDrag: false,
    mouseWheel: false,
    pressedMouseMove: false,
  },
});
const seriesOptions = ref({
  priceLineVisible: false,
  lastValueVisible: false,
  topColor: "rgba(255, 168, 106, 0.16)",
  bottomColor:"rgba(255, 168, 106, 0.02)",
  lineColor: "rgba(255, 168, 106, 0.9)",
  });
const chartType = ref("area");
const lwChart = ref();

</script>
