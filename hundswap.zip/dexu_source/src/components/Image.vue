<template>
  <img
    :src="src"
    :height="height"
    :width="width"
  />
</template>
<script
  setup
  lang="ts"
>
interface Props {
  src: string
  height?: string
  width?: string
}

defineProps<Props>()
</script>