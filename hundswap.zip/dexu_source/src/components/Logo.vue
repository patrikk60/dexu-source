<template>
  <img
    src="/images/logo.png"
    :alt="appName"
    :class="size"
  />
</template>
<script
  setup
  lang="ts"
>
import { Size } from '../interfaces';
const appName = import.meta.env.VITE_APP_NAME

interface Props {
  size?: Size
}

const props = defineProps<Props>()
const size: string = (props.size) ? props.size : Size.Normal
</script>
<style
  scoped
  lang="scss"
>
img {
  &.sz-normal {
    width: 150px;
  }

  &.sz-small {
    width: 130px;
  }
}
</style>