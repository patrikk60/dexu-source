<template>
  <v-btn
    :class="classList"
    :style="style"
  >
    <slot></slot>
  </v-btn>
</template>
<script
  setup
  lang="ts"
>
interface Prop {
  type?: string
  height?: string
}

const props = defineProps<Prop>();
let classList = "";
if (props.type === "bland") {
  classList = "bland"
} else {
  classList = "primary"
}

let style = "";
if (props.height) {
  style = "height: " + props.height + "!important"
}
</script>
<style
  lang="scss"
  scoped
>
.v-btn {
  font-size: 16px;
  font-stretch: normal;
  padding: 0.5rem 2rem;
  line-height: 24px;

  &.primary {
    background-color: rgb(var(--v-theme-primary));
    color: rgb(var(--v-theme-darkTextColor));
    border-radius: 7px;
    border: 2px solid rgb(var(--v-theme-primary));
    height: 44px !important;
  }

  &.bland {
    background: transparent;
    color: white;
    border: 2px solid rgb(var(--v-theme-lightTextColor));
    border-bottom-width: 5px;
    border-radius: 0.4rem;
    width: 180px;
    height: 47px !important;
  }
}
</style>