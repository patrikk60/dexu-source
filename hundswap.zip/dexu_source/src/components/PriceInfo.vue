<template>
  <div v-if="priceImpactRating" class="price-info-table">
    <div class="collapse-toggle" @click="collapsed = !collapsed">
      <span v-if="collapsed">Show Price Info</span>
      <span v-else>Hide Price Info</span>
      <i :class="['fas', collapsed ? 'fa-chevron-down' : 'fa-chevron-up']"></i>
    </div>
    <div v-if="!collapsed">
      <div v-if="isLoading" class="price-info-body loading">
        <div class="blur animate" style="width:140px">
          Loading...
        </div>
        <div class="row pt-6">
          <div class="key">Price Impact:</div>
          <div class="value">
            <span class="blur animate">Loading...</span>
          </div>
        </div>
        <div class="row">
          <div class="key">Min. Received:</div>
          <div class="value">
            <span class="blur animate">Loading...</span>
          </div>
        </div>
        <div class="row">
          <div class="key">Max Transaction Fee:</div>
          <div class="value">
            <span class="blur animate">Loading...</span>
          </div>
        </div>
        <div class="row" v-if="!hasReceiveAta">
          <div class="key">Deposit:</div>
          <div class="value">
            <span class="blur animate">Loading...</span>
          </div>
        </div>
      </div>
      <div v-else class="price-info-body">
        <!-- <div :class="{ [priceImpactRating.class]: true }">
          {{ priceImpactRating.description }}
        </div> -->
        <div class="row pt-2">
          <div class="key">Price Impact:</div>
          <div
            :class="{
              [priceImpactRating.class]: true,
              value: true,
            }"
          >
            {{ priceImpactRating.impactPct.toFixed(3) }}%
          </div>
        </div>
        <div class="row">
          <div class="key">Min. Received:</div>
          <div class="value">
            {{ minimumReceived  }} {{ selectedReceiveCoin.code }}
          </div>
        </div>
        <div class="row">
          <div class="key">Max Transaction Fee:</div>
          <div class="value">{{ transactionFee }} SOL</div>
        </div>
        <div class="row" >
          <div class="key">Deposit:</div>
          <div class="value">
            <span class="" v-if="!hasReceiveAta && ataRentSolCost">{{ ataRentSolCost.toFixed(6) }} SOL</span>
            <span class="" v-else >0.0 SOL</span>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div v-else class="" style="opacity: 0;margin-bottom: 0px;height:16px">
    filler
  </div>
</template>

<script setup lang="ts">
import { QuoteResponse } from "@jup-ag/api";
import { toRef, watch, ref, computed, watchEffect } from "vue";
import { Coin } from "@/interfaces";
import { parseQuote } from '../utils';
//@ts-ignore
import * as Token from '@solana/spl-token';
//@ts-ignore
const {  getAssociatedTokenAddressSync ,getMinBalanceRentForExemptAccount}  = Token
import { LAMPORTS_PER_SOL, PublicKey } from '@solana/web3.js';
import { useWallet } from 'solana-wallets-vue';
import useStore from '@/store';
import { AccountLayout } from "@solana/spl-token";

const props = defineProps<{
  quoteResp: QuoteResponse | undefined;
  selectedSendCoin: Coin;
  selectedReceiveCoin: Coin;
  isLoading: boolean;
}>();

const collapsed = ref(true);

const quote = toRef(props, "quoteResp");
const isLoading = toRef(props, "isLoading");
const selectedSendCoin = toRef(props, "selectedSendCoin");
const selectedReceiveCoin = toRef(props, "selectedReceiveCoin");

const transactionFee = 0.000305;
const {  publicKey } =
  useWallet();
  const store = useStore()
  let hasReceiveAta = ref(false);

watchEffect(async () => {
  console.log('computing')
  if(!publicKey.value) {
    hasReceiveAta.value = false;
    return;
  }
  const mint =  selectedReceiveCoin.value.networkCode;
  const ata = getAssociatedTokenAddressSync(
    new PublicKey(mint),
    publicKey.value
  )
  try{
    await store.solDexService.connection.getTokenAccountBalance(
      ata
    );
    hasReceiveAta.value = true;
  }catch(e){
    console.log("Token address for token: ", selectedReceiveCoin.value.code, "not found")
    hasReceiveAta.value = false;
  }
});
let ataRentSolCost = ref<number|null>(null);

watch(quote,async () => {

    const rent =  await store.solDexService.connection.getMinimumBalanceForRentExemption(AccountLayout.span)
   ataRentSolCost.value =rent / LAMPORTS_PER_SOL

});
watch(hasReceiveAta, (newVal) => {
  console.log("hasReceiveAta", newVal);
});
watch(ataRentSolCost, (newVal) => {
  console.log("ataRentSolCost", newVal);
});
const minimumReceived = computed(() => {
  if (!quote.value) return null;
  const parsed = parseQuote(quote.value);
  const outputMin = parsed.otherAmountThreshold/
          Math.pow(
            10,
              selectedReceiveCoin.value.receiveDecimals
          );
  return Number(outputMin > 1 ? outputMin.toFixed(2) : outputMin.toFixed(selectedReceiveCoin.value.receiveDecimals)).toLocaleString();
});

const priceImpactRating = computed(() => {
  if (!quote.value) return null;
  const impactPct = parseFloat(quote.value.priceImpactPct) * 100;

  if (impactPct < 1.3) {
    return {
      class: "pos",
      description: `Within ${impactPct.toFixed(1)}%`,
      impactPct,
    };
  } else if (impactPct < 2.7 && impactPct >= 1.3) {
    return {
      class: "med",
      description: `${impactPct.toFixed(1)}% more than Birdeye`,
      impactPct,
    };
  } else {
    return {
      class: "neg",
      description: `${impactPct.toFixed(1)}% more than Birdeye`,
      impactPct,
    };
  }
});

watch(quote, (newVal) => {
  console.log('q',newVal);
});

watch(isLoading, (newVal) => {
  console.log("load", newVal);
});

watch(priceImpactRating, (newVal) => {
  console.log("sss", newVal);
});
</script>

<style>
.price-info-table {
  padding: 10px;
  border-radius: 5px;
  width: 100%;
  color: #fff;
  max-width: 600px;
padding-top:36px!important;
}

.collapse-toggle {
  display: flex;
  align-items: center;
  cursor: pointer;
  margin-bottom: 10px;
  text-align: right;
    display: block;
}

.collapse-toggle i {
  margin-left: 5px;
  transition: transform 0.3s ease;
}

.collapse-toggle i.fa-chevron-up {
  transform: rotate(180deg);
}

.price-info-body{
  margin-top: -8px;
}
.row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 5px;
}

.key {
  font-weight: bold;
  margin-right: 10px;
}

.blur {
  filter: blur(20px);
  scale:0.8;
}

.animate {
  background: linear-gradient(to right, rgba(255, 168, 106, 0.9), rgba(255, 168, 106, 0.5), rgba(255, 168, 106, 0.4));
  background-size: 200% 200%;
  animation: gradient 1s ease infinite;
}

@keyframes gradient {
  0% {
    background-position: 0% 50%;
  }
  50% {
    background-position: 100% 50%;
  }
  100% {
    background-position: 0% 50%;
  }
}

@media screen and (max-width: 990px) {
  .price-info-table {
    max-width: 693.234px;
    padding: 0 60px;
  }
}

@media screen and (max-width: 678px) {
  .price-info-table {
    padding: 0 20px;
  }
}

@media screen and (max-width: 420px) {
  .price-info-table {
    font-size: smaller;
    padding: 0 8px;
  }
}

@media screen and (max-width: 350px) {
  .price-info-table {
    font-size: small;
    padding: 0 8px;
  }
}
</style>
