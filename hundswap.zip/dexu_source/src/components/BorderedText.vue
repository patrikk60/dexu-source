<template>
  <div
    class="bordered-text"
    v-text="text"
  ></div>
</template>
<script
  setup
  lang="ts"
>
interface Prop {
  text: string
}

defineProps<Prop>()
</script>
<style lang="scss">
.bordered-text {
  background: transparent;
  color: white;
  border: 2px solid rgb(var(--v-theme-lightTextColor));
  border-bottom-width: 5px;
  border-radius: 0.4rem;
  padding: 1rem;
  min-height: 47px !important;
  letter-spacing: 2px;
  font-size: 16px;
  text-align: center;
  width: 100%;
}
</style>