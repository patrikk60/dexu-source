<template>
  <div class="icon-container swap-btn-container" @click="handleSwapClick">
    <img src="/images/swap.png" width="48px" height="48px" />
  </div>
</template>
<script lang="ts" setup>
interface Props {
  handleSwapClick: () => void;
}
defineProps<Props>();
</script>
<style>
.swap-btn-container{
  height:80px;
  width:80px;
  display:flex;
  justify-content: center;
  align-items:center;
  z-index: 100;
}
@media screen and (min-width:775px) and (max-width:1280px) {
  .swap-btn-container{
    height:30px;
    width:30px;
  }
  .swap-btn-container img{
    height:35px;
    width:35px;
  }
}
@media screen and (max-width:775px) {
  .swap-btn-container img{
    transform: rotate(90deg);
  }
}
</style>
