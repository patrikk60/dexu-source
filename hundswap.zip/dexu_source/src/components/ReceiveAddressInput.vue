<template>
  <div class="receive-address-container">
    <label
      for="receive-address-input"
      id="receive-address-input-label"
    >Receiving Address</label>
    <div
      class="receive-address-input-container"
      :class="{ hasError: hasError }"
    >
      <input
        id="receive-address-input"
        name="receive-address-input"
        class="text-center"
        v-model="addressVal"
        @input="onAddressChange"
      />
      <v-progress-circular
        indeterminate
        :size="20"
        :width="2"
        v-if="isValidatingAddress"
      ></v-progress-circular>
    </div>
  </div>
</template>
<script
  setup
  lang="ts"
>
import { ref } from 'vue'

interface Props {
  receivingAddress: string
  isValidatingAddress: boolean
  hasError: boolean
}
const props = defineProps<Props>()

const emit = defineEmits()
const addressVal = ref(props.receivingAddress)

const onAddressChange = () => {
  emit('update:receivingAddress', addressVal.value)
  emit('removeHasError', false)
}
</script>
<style
  lang="scss"
  scoped
>
input {
  width: 100%;
  outline: none;
  border: none;
  padding: 0.5rem 2.2rem 0.5rem 2.2rem;
  text-overflow: ellipsis;
  cursor: text;
  pointer-events: all;


}

.receive-address-input-container {
  border: 2px solid white;
  border-bottom-width: 5px;
  padding: 12px;
  border-radius: 5px;
  transition: ease-in-out 0.4s;
  position: relative;

  &.hasError {
    border-color: rgb(255, 47, 47);
  }
}

.receive-address-container {
  #receive-address-input-label {
    text-transform: uppercase;
    color: rgb(var(--v-theme-lightTextColor));
    font-size: 15px;
    display: block;
    margin: 23px 0;
  }

  .v-progress-circular {
    position: absolute;
    right: 7px;
    margin: auto 0;
    top: 0;
    bottom: 0;
  }

}
</style>
