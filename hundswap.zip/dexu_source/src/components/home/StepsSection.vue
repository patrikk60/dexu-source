<template>
  <box class="steps-box d-flex flex-column justify-center align-center">
    <template
      v-for="(text, index) in steps"
      :key="index"
    >
      <bordered-text :text="text"></bordered-text>
      <v-icon
        icon="fa fa-chevron-down"
        v-if="index !== steps.length - 1"
      ></v-icon>
    </template>
  </box>
</template>
<script
  setup
  lang="ts"
>
import Box from '@/components/Box.vue'
import BorderedText from '@/components/BorderedText.vue';


const steps: string[] = [
  "[FIRST STEP] Select the coins to swap.",
  "[SECOND STEP] Deposit the coins to the address shown.",
  "[LAST STEP] Receive the swapped coins in your wallet."
];
</script>
<style
  lang="scss"
  scoped
>
.steps-box {
  gap: 2rem;

  .v-icon {
    font-size: 35px;
  }
}
</style>