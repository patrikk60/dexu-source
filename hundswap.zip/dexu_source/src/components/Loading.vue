<template>
  <v-dialog
    class="loading-dialog"
    opacity="0"
    :fullscreen="true"
    v-model="store.getShowLoading"
  >
    <v-progress-linear
      indeterminate
      color="primary"
      height="5"
    ></v-progress-linear>
  </v-dialog>
</template>
<script
  setup
  lang="ts"
>
import useStore from '@/store';

const store = useStore();
</script>
<style lang="scss">
.loading-dialog {
  .v-overlay__content {
    background: linear-gradient(to bottom, rgb(3 0 10 / 90%) 80%, rgb(44 44 44 / 80%));
    backdrop-filter: blur(14px);
    -webkit-backdrop-filter: blur(14px);
    border-radius: 0.25rem;
    transition: all 0.3s ease;
    max-height: 100% !important;
    height: 100%;
    width: 100%;
  }

}
</style>