<template>
  <div
    class="toast"
    :class="[className]"
  >{{ message }}</div>
</template>
<script
  setup
  lang="ts"
>
import useStore from '@/store';
import { watch, ref } from 'vue';

const store = useStore()
const className = ref("")
const message = ref("")

watch(() => store.getToastMessage, (newValue, oldValue) => {
  if (newValue) {
    className.value = `active ${newValue.kind}`
    message.value = newValue.message
  } else {
    className.value = ""
    message.value = ""
  }
})
</script>
<style
  lang="scss"
  scoped
>
.toast {
  position: fixed;
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 0px;
  top: -90px;
  left: 0;
  right: 0;
  margin: auto;
  transition: transform 0.5s ease-in-out;
  z-index: 25;
  text-align: center;
  text-shadow: 1px 1px 2px black, 1px 1px 4px black;
  max-width: 300px;
  padding: 8px 12px;
  font-size: 13.5px;
  border-radius: 5px;
  backdrop-filter: blur(4px);
  -webkit-backdrop-filter: blur(4px);

  &.active {
    transform: translateY(110px);
    text-align: center;

    &.positive {
      border: 1px solid rgba(84, 255, 141, 0.795);
      background: linear-gradient(to bottom right, rgba(84, 255, 141, 0.65) 55%, rgba(80, 255, 202, 0.75));
    }

    &.wait {
      border: 1px solid rgba(255, 255, 255, 0.8);
      background: linear-gradient(to bottom right, rgba(124, 124, 124, 0.65) 55%, rgba(211, 211, 211, 0.75));
    }

    &.error {
      border: 1px solid rgba(252, 70, 85, 0.8);
      background: linear-gradient(to bottom right, rgba(255, 105, 67, 0.65) 55%, rgba(252, 70, 85, 0.75));
    }
  }
}
</style>