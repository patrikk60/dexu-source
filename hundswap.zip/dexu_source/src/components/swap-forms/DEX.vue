<template>
  <box id="swap-box" class="swap-box padded-side" style="border:none">
    <div class="swap-box-wrapper">
      <select-coin-dialog
        :shouldOpenDialog="shouldOpenDialog"
        :closeDialog="closeDialog"
        :selectedSendCoin="selectedSendCoin"
        :selectedReceiveCoin="selectedReceiveCoin"
        :direction="dialogDirection"
        :onCoinSelected="onCoinSelected"
        v-model="shouldOpenDialog"
        pinned="HUND"
      />
      <v-dialog v-model="slippageDialog" max-width="290">
        <v-card>
          <v-card-title class="headline">SETTINGS</v-card-title>
          <v-card-text>
            <v-radio-group v-model="slippageType">
              <v-radio label="AUTO" :value="'Auto'"></v-radio>
              <v-radio label="CUSTOM" :value="'custom'"> </v-radio>
              <v-slider
                style="margin-top: 30px"
                :disabled="slippageType.valueOf() == 'custom' ? false : true"
                v-model="slippage"
                min="0"
                max="50"
                :thumb-label="
                  slippageType.valueOf() == 'custom' ? 'always' : false
                "
              >
                <template v-slot:thumb-label="{ modelValue }">
                  {{ modelValue.toFixed(1) }}%
                </template>
              </v-slider>
            </v-radio-group>
          </v-card-text>
          <!-- <v-card-actions> -->
          <v-spacer></v-spacer>
          <v-btn
            class="swap-btn"
            style="
              background-color: rgb(var(--v-theme-primary));
              color: black;
              width: 90%;
              margin: auto;
              margin-bottom: 10px;
            "
            @click="slippageDialog = false"
            >Done</v-btn
          >
          <!-- </v-card-actions> -->
        </v-card>
      </v-dialog>
      <div class="flex flex-row">
        <rate
          :sendCoin="selectedSendCoin"
          :receiveCoin="selectedReceiveCoin"
          :rate="rate"
        >
          <div class="slippage-container" @click="handleSlippage">
            <v-icon
              size="1rem"
              style="margin-bottom: 3px; margin-right: 4px"
              icon="fa fa-cog"
            ></v-icon>
            {{
              slippageType == "Auto" ? slippageType : `${slippage.toFixed(1)}%`
            }}
          </div>
        </rate>
      </div>
      <div class="swap-box-content d-flex flex-row" style="gap: 7px">
        <swap-btn :handle-swap-click="handleSwapClick" />
        <token-box
          class="token-container"
          :SwapType="SwapType.Send"
          :coin="selectedSendCoin"
          :min-amount="Number.NaN"
          :max-amount="Number.NaN"
          :on-input="() => onAmountInputChange(true)"
          :is-fetching-rate="isFetchingSendRate"
          :is-fetching-coins="isFetchingCoins"
          v-model:amount="sendAmount"
          :openDialog="openDialogFunc(SwapType.Send)"
          :current-amount="!publicKey ? undefined : sendCurrAmount"
          :dollar-amount="sendDollarAmount"
          :is-fetching-dollar-amount="isFetchingSendDollarAmount"
          :is-fetching-curr-amount="isFetchingSendCurrAmount"
          :on-half="(publicKey && onHalf) || undefined"
          :on-max="(publicKey && onMax) || undefined"
        ></token-box>
        <token-box
          class="token-container"
          :SwapType="SwapType.Receive"
          :coin="selectedReceiveCoin"
          :is-fetching-rate="isFetchingReceiveRate"
          :on-input="() => onAmountInputChange(false)"
          :min-amount="Number.NaN"
          :max-amount="Number.NaN"
          :is-fetching-coins="isFetchingCoins"
          v-model:amount="receiveAmount"
          :openDialog="openDialogFunc(SwapType.Receive)"
          disabled
          :current-amount="!publicKey ? undefined : receiveCurrAmount"
          :dollar-amount="receiveDollarAmount"
          :is-fetching-dollar-amount="isFetchingReceiveDollarAmount"
          :is-fetching-curr-amount="isFetchingReceiveCurrAmount"
        ></token-box>
      </div>
      <btn v-if="isSendingTxn" class="swap-btn" height="50px"
        >PROCESSING TRANSACTION</btn
      >
      <btn
        v-else-if="connected && canSend"
        class="swap-btn"
        height="50px"
        @click="handleSwap"
        >Swap</btn
      >
      <btn
        v-else-if="connected && !canSend"
        class="swap-btn disabled"
        height="50px"
        disabled
        >Not enough {{ selectedSendCoin.code }}</btn
      >
      <btn v-else-if="connecting" class="swap-btn" height="50px"
        >Connecting...</btn
      >
      <btn
        v-else
        class="swap-btn"
        height="50px"
        @click="walletModalProviderRef.openModal()"
        >Connect your wallet</btn
      >
    </div>
    <button
      v-if="connected"
      class="swap-btn"
      height="50px"
      @click="disconnect()"
    >
      DISCONNECT
    </button>
    <!-- <div v-else style="height: 50px"></div> -->
  </box>
  <PriceInfo
    :is-loading="isFetchingReceiveRate || isFetchingSendCurrAmount || isFetchingSendRate || isFetchingReceiveCurrAmount"
    :quoteResp="quoteResp"
    :selected-receive-coin="selectedReceiveCoin"
    :selected-send-coin="selectedSendCoin"
  />
  <box id="chart-box" class="swap-box w-full padded-side" style="border: none; margin-top: 16px;">
    <coin-chart
      v-if="selectedSendCoin.network == 'SOL'"
      :coin="selectedSendCoin"
    />
    <coin-chart
      v-if="selectedReceiveCoin.network == 'SOL'"
      :coin="selectedReceiveCoin"
    />
  </box>
  <WalletModalProvider dark ref="walletModalProviderRef"></WalletModalProvider>
</template>
<script lang="ts" setup>
import CoinChart from "../CoinChart.vue";
import "solana-wallets-vue/styles.css";
import { useWallet, WalletModalProvider } from "solana-wallets-vue";
import Btn from "@/components/Btn.vue";
import useStore from "@/store";
import useDebounce from "@/hooks/useDebounce";
import {
  Ref,
  onBeforeMount,
  ref,
  watch,
  onMounted,
  onBeforeUnmount,
} from "vue";
import Rate from "../Rate.vue";
import { ToastMessageKind, SwapType, Coin } from "@/interfaces";
import { QuoteGetRequest, QuoteResponse } from "@jup-ag/api";
import SelectCoinDialog from "@/components/coins-dialog/Dialog.vue";
import Box from "@/components/Box.vue";
import TokenBox from "@/components/TokenBox.vue";
import SwapBtn from "../SwapBtn.vue";
import {
  VersionedTransaction,
  PublicKey,
  LAMPORTS_PER_SOL,
} from "@solana/web3.js";
const initialCoins = [
  //WSOL
  {
    networkCode: "So11111111111111111111111111111111111111112",
  },
  //HUND
  {
    networkCode: "2XPqoKfJitk8YcMDGBKy7CMzRRyF2X9PniZeCykDUZev",
  },
];
const debounce = useDebounce();
const store = useStore();

const coins = store.getCoins;
const shouldOpenDialog = ref(false);
const dialogDirection = ref(SwapType.Send);
const selectedSendCoin = ref<Coin>(
  store.coins.find((c: Coin) => c.networkCode == initialCoins[0].networkCode) ||
    store.coins[0]
);
const selectedReceiveCoin = ref<Coin>(
  store.coins.find((c: Coin) => c.networkCode == initialCoins[1].networkCode) ||
    store.coins[1]
);
const sendAmount = ref<number | undefined>(undefined);
const receiveAmount = ref<number | undefined>(undefined);
const isFetchingSendRate = ref(false);
const isFetchingReceiveRate = ref(false);
const isFetchingCoins = ref(coins.length <= 2);
let slippageType: Ref<"custom" | "Auto"> = ref("Auto");
let slippage = ref(5);
const handleSlippage = () => {
  slippageDialog.value = true;
};
const slippageDialog = ref(false);
watch(slippageType, () => {
  onAmountInputChange(true, true);
});
watch(slippage, () => {
  onAmountInputChange(true, true);
});
const isFetchingSendDollarAmount = ref(false);
const isFetchingReceiveDollarAmount = ref(false);
const isFetchingSendCurrAmount = ref(false);
const isFetchingReceiveCurrAmount = ref(false);
const sendCurrAmount = ref<number | undefined>();
const receiveCurrAmount = ref<number | undefined>();
const sendDollarAmount = ref<number>(0);
const receiveDollarAmount = ref<number>(0);

const isSendingTxn = ref(false);

// const rate = sendAmount.value&&receiveAmount.valuesendAmount.value/receiveAmount.value;

const rate = ref<number | undefined>();
const isFetchingRate = ref(false);

const onHalf = () => {
  // console.log("half");
  sendAmount.value = Number(((sendCurrAmount.value || 0) / 2).toFixed(4));
  onAmountInputChange(true);
};
const onMax = async () => {
  // console.log("max");
  if (selectedSendCoin.value.networkCode.toUpperCase().startsWith("SO111111")) {
    let solPerDollar: number;
    const solInDollars = await fetchAmountInDollars(
      selectedSendCoin.value.networkCode,
      1,
      selectedSendCoin.value.receiveDecimals
    );
    // console.log({solInDollars})
    solPerDollar = 1 / solInDollars;
    // if(solInDollars.data){
    //   solPerDollar = solInDollars.data.amount;
    // }else{
    // solPerDollar = 0;

    const minAmount = solPerDollar * 0.1;
    const currVal = sendCurrAmount.value || 0;
    const fixed = (currVal - minAmount).toFixed(4);
    // console.log(sendAmount.value,sendDollarAmount.value,{fixed, minAmount, currVal, solPerDollar})
    sendAmount.value = Number(fixed);
  } else {
    sendAmount.value = sendCurrAmount.value || 0;
  }
  onAmountInputChange(true);
};

const openDialogFunc = (swapType: SwapType) => {
  return () => {
    dialogDirection.value = swapType;
    shouldOpenDialog.value = true;
  };
};
// watch(selectedSendCoin, console.log);
// watch(selectedReceiveCoin, console.log);
const swapCoins = () => {
  const temp = selectedSendCoin.value;
  const amountTemp = sendAmount.value;
  // const dollarTemp = sendDollarAmount.value;
  const currAmountTemp = sendCurrAmount.value;
  selectedSendCoin.value = selectedReceiveCoin.value;
  sendAmount.value = receiveAmount.value;
  // sendDollarAmount.value = receiveDollarAmount.value;
  sendCurrAmount.value = receiveCurrAmount.value;
  selectedReceiveCoin.value = temp;
  receiveAmount.value = amountTemp;
  receiveCurrAmount.value = currAmountTemp;
  // receiveDollarAmount.value = dollarTemp;
  // updateAmounts(true);
  // fetchBaseRate();
  onAmountInputChange(true, true);
};

const closeDialog = () => {
  shouldOpenDialog.value = false;
};

const onCoinSelected = (coin: Coin) => {
  if (dialogDirection.value === SwapType.Send) {
    if (coin.key === selectedReceiveCoin.value.key) {
      swapCoins();
    } else {
      selectedSendCoin.value = coin;
    }
  } else if (dialogDirection.value === SwapType.Receive) {
    if (coin.key === selectedSendCoin.value.key) {
      swapCoins();
    } else {
      selectedReceiveCoin.value = coin;
    }
    // onAmountInputChange(false);
  }
  onAmountInputChange(true);
  closeDialog();
};

const validate = async (): Promise<boolean> => {
  if (!sendAmount.value || !receiveAmount.value) {
    store.setToastMessage(
      "Please enter the amounts you wish to swap",
      ToastMessageKind.Error
    );
    return false;
  }

  return true;
};

const placeOrder = async () => {
  if (!publicKey.value) {
    store.setToastMessage("Please connect your wallet", ToastMessageKind.Error);
    return;
  }
  // console.log("ggg", selectedSendCoin.value, sendCurrAmount.value);
  // store.setToastMessage("Placing order", ToastMessageKind.Wait);
  isSendingTxn.value = true;
  const quoteResponse = await fetchRate("send");
  if (quoteResponse) {
    const swapTxn = await store.getDEXInstructions(
      publicKey.value,
      quoteResponse
    );
    const swapTransactionBuf = Buffer.from(swapTxn.swapTransaction, "base64");
    const transaction = VersionedTransaction.deserialize(swapTransactionBuf);
    const signature = await sendTransaction(
      transaction,
      store.solDexService.connection
    ).catch((e) => {
      console.error(e);
      isSendingTxn.value = false;
      // store.setToastMessage("Transaction failed.", ToastMessageKind.Error);
    });
    if (!signature) {
      // store.setToastMessage("Transaction canceled.", ToastMessageKind.Wait);
      isSendingTxn.value = false;
      return;
    }
    store.setToastMessage(
      `Swapping ${selectedSendCoin.value.code} to ${selectedReceiveCoin.value.code}...`,
      ToastMessageKind.Wait
    );
    const connection = store.solDexService.connection;
    // const blockhash = await connection.getLatestBlockhash()
    const sigRes = await connection.confirmTransaction(signature);
    if (sigRes.value.err) {
      store.setToastMessage("Transaction failed.", ToastMessageKind.Error);
      isSendingTxn.value = false;
      return;
    }
    store.setToastMessage(
      `Swapped ${selectedSendCoin.value.code} to ${selectedReceiveCoin.value.code}.`,
      ToastMessageKind.Positive
    );
    isSendingTxn.value = false;
    await updateAmounts();
    // const req: Quote = {
    //     amount: sendAmount.value as number,
    //     receive: selectedReceiveCoin.value.code,
    //     receiveAddress: receivingAddress.value,
    //     receiveNetwork: selectedReceiveCoin.value.networkCode,
    //     send: selectedSendCoin.value.code,
    //     sendNetwork: selectedSendCoin.value.network,
    //     userDeviceId: localStorage.getItem("deviceID") as string,
    // };

    // store
    //     .pl(req)
    //     .then((res) => {
    //         store.setToastMessage(
    //             "Order Placed Successfuly!",
    //             ToastMessageKind.Positive,
    //         );
    //         router.push(`/order`);
    //     })
    //     .catch((err) => {
    //         store.setToastMessage(err, ToastMessageKind.Error);
    //     });
  }
};

const handleSwap = async () => {
  let isSwapValid = await validate();
  if (!isSwapValid) {
    return;
  }

  placeOrder();
};

const handleSwapClick = () => {
  swapCoins();
};

onBeforeMount(async () => {
  store
    .fetchDEXCoins()
    .then(() => {
      // console.log({ me: store.getCoins });
      selectedSendCoin.value = store.getCoins.find(
        (c: Coin) => c.networkCode == initialCoins[0].networkCode
      );
      selectedReceiveCoin.value = store.getCoins.find(
        (c: Coin) => c.networkCode == initialCoins[1].networkCode
      );
      // console.log(
      //   selectedSendCoin.value.receiveDecimals,
      //   selectedReceiveCoin.value.receiveDecimals
      // );
      // sendAmount.value = 1;
      onAmountInputChange(true);
    })
    .catch((err) => {
      store.setPermanentToastMessage(err, ToastMessageKind.Error);
    })
    .finally(() => {
      isFetchingCoins.value = false;
      store.showLoading = false;
    });
});

const fetchBaseRate = async () => {
  isFetchingRate.value = true;

  let req: QuoteGetRequest = {
    inputMint: selectedSendCoin.value?.networkCode,
    outputMint: selectedReceiveCoin.value?.networkCode,
    amount: Math.pow(10, selectedSendCoin.value.receiveDecimals) * 1,
  };
  await store
    .fetchDEXExchangeAmount(req)
    .then(async (resp: QuoteResponse) => {
      // console.log({ rateR, direction, req, resp });
      const parsed = parseQuote(resp);
      const outputUiVal =
        parsed.outAmount /
        Math.pow(10, selectedReceiveCoin.value.receiveDecimals);
      rate.value = outputUiVal;
    })
    .catch((err) => {
      // store.setToastMessage(err, ToastMessageKind.Error);
      // sendDollarAmount.value = 0;
      // receiveAmount.value = 0;
      rate.value = undefined;
    })
    .finally(() => {
      // isFetchingReceiveRate.value = false;
      isFetchingRate.value = false;
    });
};

// fetch dex quotes
const fetchRate = (direction: "send" | "receive" = "send") => {
  // if(!sendAmount.value || !receiveAmount.value)return new Promise<QuoteResponse|void>(r=>r(undefined))

  // if (
  //     selectedSendCoin.value?.networkCode &&
  //     selectedReceiveCoin.value?.networkCode
  // ) {
  const val = direction == "send" ? sendAmount.value : receiveAmount.value;
  if (!val) {
    // if (direction == "send") {
    //   if (receiveAmount.value != undefined) receiveAmount.value = 0;
    // } else if (sendAmount.value != undefined) sendAmount.value = 0;
    isFetchingReceiveRate.value = false;
    isFetchingSendRate.value = false;
    return new Promise<QuoteResponse | void>((r) => r(undefined));
  }
  let req: QuoteGetRequest =
    direction == "send"
      ? {
          inputMint: selectedSendCoin.value?.networkCode,
          outputMint: selectedReceiveCoin.value?.networkCode,
          amount: Math.floor(
            Math.pow(10, selectedSendCoin.value.receiveDecimals) *
              Number(val.toFixed(selectedSendCoin.value.receiveDecimals))
          ),
        }
      : {
          inputMint: selectedReceiveCoin.value?.networkCode,
          outputMint: selectedSendCoin.value?.networkCode,
          amount: Math.floor(
            Math.pow(10, selectedReceiveCoin.value.receiveDecimals) *
              Number(val.toFixed(selectedReceiveCoin.value.receiveDecimals))
          ),
        };
  // console.log('fetrec',req.amount, {val})
  if (slippageType.value == "Auto") {
    req.autoSlippage = true;
    req.computeAutoSlippage = true;
  } else {
    req.slippageBps = Number((slippage.value * 100).toFixed(0));
  }

  return store
    .fetchDEXExchangeAmount(req)
    .then(async (resp: QuoteResponse) => {
      // console.log({  direction, req, resp });

      return resp;
    })
    .catch((err) => {
      store.setToastMessage(err, ToastMessageKind.Error);
      sendDollarAmount.value = 0;
      receiveAmount.value = 0;
    })
    .finally(() => {
      isFetchingReceiveRate.value = false;
      isFetchingSendRate.value = false;
    });
  // }
};

//@ts-ignore
import { getAssociatedTokenAddressSync } from "@solana/spl-token";
import { parseQuote } from "@/utils";
import PriceInfo from "../PriceInfo.vue";
const fetchWalletCurrentBalance = async (
  mint: string
): Promise<number | undefined> => {
  // console.log("slo", { mint });
  if (!mint || !publicKey.value) return undefined;
  const ata = getAssociatedTokenAddressSync(
    new PublicKey(mint),
    publicKey.value
  );
  console.log({ ata });
  let solAmount = 0;
  if (mint.toUpperCase().startsWith("SO11111111")) {
    const solAmountLamports = await store.solDexService.connection.getBalance(
      publicKey.value
    );
    solAmount = solAmountLamports / LAMPORTS_PER_SOL;
    // console.log({ solAmount });
    // return amount
  }
  try {
    const res = await store.solDexService.connection.getTokenAccountBalance(
      ata
    );
    const amount = res.value.uiAmount || 0;
    if (mint.toUpperCase().startsWith("SO11111111")) {
      return amount + solAmount;
    } else return amount;
  } catch (e) {
    // console.error(e);
    if (mint.toUpperCase().startsWith("SO11111111")) {
      return solAmount;
    } else return 0;
  }
};



const USDC_mint = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v";
const fetchAmountInDollars = async (
  mint: string,
  amount: number,
  decimals: number
): Promise<number> => {
  const outputDecimals = 6;
  let req: QuoteGetRequest = {
    inputMint: mint,
    outputMint: USDC_mint, //USDC
    amount: Math.pow(10, decimals) * 1,
  };
  if (amount == 0) return 0;
  if (mint == USDC_mint) {
    return amount;
  }
  // console.log("fetchAmountInDollars", { req });
  const r = await store.fetchDEXExchangeAmount(req).catch((e) => {
    console.error(e);
    return;
  });
  if (!r) return 0;
  const parsed = parseQuote(r);
  const outputUiVal =
    (parsed.outAmount / Math.pow(10, outputDecimals)) * amount;
  return outputUiVal;
};

async function updateAmounts(skipCurrentBalanceCheck = false) {
  // console.log(selectedSendCoin.value.networkCode, sendAmount.value);
  // console.log(selectedReceiveCoin.value.networkCode, receiveAmount.value);
  if (sendAmount.value) {
    isFetchingSendDollarAmount.value = true;
  }
  if (receiveAmount.value || sendAmount.value) {
    isFetchingReceiveDollarAmount.value = true;
  }
  isFetchingSendCurrAmount.value = !skipCurrentBalanceCheck;
  isFetchingReceiveCurrAmount.value = !skipCurrentBalanceCheck;
  try {
    const [
      sendCurrAmountValue,
      sendDollarAmountValue,
      receiveCurrAmountValue,
      receiveDollarAmountValue,
    ] = await Promise.all([
      skipCurrentBalanceCheck
        ? Promise.resolve(null)
        : fetchWalletCurrentBalance(selectedSendCoin.value.networkCode),
      fetchAmountInDollars(
        selectedSendCoin.value.networkCode,
        sendAmount.value || 0,
        selectedSendCoin.value.receiveDecimals
      ),
      skipCurrentBalanceCheck
        ? Promise.resolve(null)
        : fetchWalletCurrentBalance(selectedReceiveCoin.value.networkCode),
      fetchAmountInDollars(
        selectedReceiveCoin.value.networkCode,
        receiveAmount.value || 0,
        selectedReceiveCoin.value.receiveDecimals
      ),
    ]);
    if (!skipCurrentBalanceCheck) {
      sendCurrAmount.value = sendCurrAmountValue || 0;
      receiveCurrAmount.value = receiveCurrAmountValue || 0;
    }
    sendDollarAmount.value = sendDollarAmountValue;
    receiveDollarAmount.value = receiveDollarAmountValue;
  } catch (e) {
    console.error(e);
  }
  isFetchingSendDollarAmount.value = false;
  isFetchingSendCurrAmount.value = false;
  isFetchingReceiveCurrAmount.value = false;
  isFetchingReceiveDollarAmount.value = false;
  // console.log("fss", sendAmount.value);
  checkCanSend();
  // receiveDollarAmount.value = await fetchAmountInDollars(selectedReceiveCoin.value.networkCode, receiveAmount.value, selectedReceiveCoin.value.receiveDecimals)
  // console.log('aaa',sendDollarAmount.value, receiveDollarAmount.value);
}
// watch(sendAmount, console.log)
const canSend = ref(false);
const checkCanSend = () => {
  if (!sendCurrAmount.value) {
    // console.log('aic', sendCurrAmount.value)
    canSend.value = false;
    return;
  }
  let current: number = sendCurrAmount.value || 0;
  // console.log(sendAmount.value, current)
  if ((sendAmount.value || 0) > current) {
    canSend.value = false;
  } else {
    canSend.value = true;
  }
};
const quoteResp: Ref<QuoteResponse | undefined> = ref();
const onAmountInputChange = (
  isSendInput: boolean,
  skipCurrentBalanceCheck = false
) => {
  if (isSendInput) {
    isFetchingSendCurrAmount.value = true;
  } else {
    isFetchingReceiveCurrAmount.value = true;
  }
  if (sendAmount.value) {
    console.log(2);
    isFetchingSendDollarAmount.value = true;
  }
  if (receiveAmount.value || sendAmount.value) {
    isFetchingReceiveDollarAmount.value = true;
  }
  debounce(async () => {
    //     const req: QuoteGetRequest = {
    //         inputMint: selectedSendCoin.value.networkCode,
    //         outputMint: selectedReceiveCoin.value.networkCode,
    //         amount: sendAmount.value ? sendAmount.value : 0,
    //     };
    fetchBaseRate();
    if (isSendInput) {
      isFetchingReceiveRate.value = true;
      if (!sendAmount.value || sendAmount.value < 0) {
        // sendAmount.value = 0;
      }
    } else {
      isFetchingSendRate.value = true;
      if (!receiveAmount.value || receiveAmount.value < 0) {
        // receiveAmount.value = 0;
      }
    }
    const direction = isSendInput ? "send" : "receive";
    //@ts-ignore
    const resp = await fetchRate(direction);
    if (resp) {
      // console.log({ parsed, req });
      if (resp) {
        const parsed = parseQuote(resp);
        // const inputUiVal =
        //   parsed.inAmount /
        //   Math.pow(
        //     10,
        //     isSendInput
        //       ? selectedSendCoin.value.receiveDecimals
        //       : selectedReceiveCoin.value.receiveDecimals
        //   );
        const outputUiVal =
          parsed.outAmount /
          Math.pow(
            10,
            isSendInput
              ? selectedReceiveCoin.value.receiveDecimals
              : selectedSendCoin.value.receiveDecimals
          );
        // console.log({ parsed, uiVal }
        if (isSendInput) {
          quoteResp.value = resp;
          receiveAmount.value = outputUiVal;
        } else {
          sendAmount.value = outputUiVal;
        }
      }
    }
    updateAmounts(skipCurrentBalanceCheck);
    lastChanged.value = Date.now();
  }, 2000);
};
const { disconnect, connecting, connected, publicKey, sendTransaction } =
  useWallet();
watch(publicKey, () => {
  updateAmounts();
});
let walletModalProviderRef = ref();

const intervalId = ref<ReturnType<typeof setInterval> | null>(null);
const lastChanged = ref<number | null>();
const REFRESH_INTERVAL = 15000;
onMounted(() => {
  intervalId.value = setInterval(() => {
    if (
      lastChanged.value &&
      Date.now() - lastChanged.value > REFRESH_INTERVAL - 5000
    )
      // refresh price while
      // skipping updating current balance
      onAmountInputChange(true, true);
  }, REFRESH_INTERVAL);
});

onBeforeUnmount(() => {
  if (intervalId.value) {
    clearInterval(intervalId.value);
  }
});
</script>
<style>
.slippage-container {
  text-align: center;
  /* margin-bottom: 0.75rem;
  margin-top: 0.5rem; */
  margin-right: 0;
  /* margin-left: auto; */
  cursor: pointer;
}
.connect-btn {
  opacity: 70%;
}

.connect-btn:hover {
  opacity: 100%;
}
@media screen and (min-width: 776px) and (max-width: 1280px) {
  #chart-box {
    /* flex-direction: column; */
    width: 693.234px;
  }
}
</style>
