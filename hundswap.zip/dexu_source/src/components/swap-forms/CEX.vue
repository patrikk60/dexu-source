<template>
  <box class="swap-box padded-side" style="border: none;">
    <div class="swap-box-wrapper">
      <select-coin-dialog
        :shouldOpenDialog="shouldOpenDialog"
        :closeDialog="closeDialog"
        :selectedSendCoin="selectedSendCoin"
        :selectedReceiveCoin="selectedReceiveCoin"
        :direction="dialogDirection"
        :onCoinSelected="onCoinSelected"
        v-model="shouldOpenDialog"
      />
      <rate
        :sendCoin="selectedSendCoin"
        :receiveCoin="selectedReceiveCoin"
        :rate="rate"
        :tooltipText="rateTooltipText"
      />
      <div class="swap-box-content d-flex flex-row" style="gap: 7px">
        <swap-btn :handle-swap-click="handleSwapClick"/>
        <token-box
          class="token-container"
          :SwapType="SwapType.Send"
          :coin="selectedSendCoin"
          :min-amount="minSendAmount || Number.NaN"
          :max-amount="maxSendAmount || Number.NaN"
          :on-input="() => onAmountInputChange(true)"
          :is-fetching-rate="isFetchingSendRate"
          :is-fetching-coins="isFetchingCoins"
          v-model:amount="sendAmount"
          :openDialog="openDialogFunc(SwapType.Send)"
        ></token-box>
        <token-box
          class="token-container"
          :SwapType="SwapType.Receive"
          :coin="selectedReceiveCoin"
          :is-fetching-rate="isFetchingReceiveRate"
          :on-input="() => onAmountInputChange(false)"
          :min-amount="minReceiveAmount"
          :max-amount="maxReceiveAmount"
          :is-fetching-coins="isFetchingCoins"
          v-model:amount="receiveAmount"
          :openDialog="openDialogFunc(SwapType.Receive)"
        ></token-box>
      </div>
      <receive-address-input
        v-model:receivingAddress="receivingAddress"
        :isValidatingAddress="isValidatingReceivingAddress"
        :hasError="receivingAddressHasError"
        @removeHasError="() => (receivingAddressHasError = false)"
      />
      <btn class="swap-btn" height="50px" @click="handleSwap">Swap</btn>
    </div>
  </box>
  <steps-section class="steps-box padded"style="border: none;"></steps-section>
</template>
<script setup lang="ts">
import SelectCoinDialog from "@/components/coins-dialog/Dialog.vue";
import StepsSection from "@/components/home/StepsSection.vue";
import Box from "@/components/Box.vue";
import Rate from "@/components/Rate.vue";
import TokenBox from "@/components/TokenBox.vue";
import ReceiveAddressInput from "@/components/ReceiveAddressInput.vue";
import Btn from "@/components/Btn.vue";
import useStore from "@/store";
import { ref, onBeforeMount } from "vue";
import { useRouter } from "vue-router";
import useDebounce from "@/hooks/useDebounce";
import {
  SwapType,
  Coin,
  ToastMessageKind,
  PlaceCEXOrderRequest,
  FetchRateRequest,
  FetchRateResponse,
} from "@/interfaces";
import SwapBtn from "../SwapBtn.vue";

const store = useStore();
const router = useRouter();
const debounce = useDebounce();

const coins = store.getCoins;
const shouldOpenDialog = ref(false);
const dialogDirection = ref(SwapType.Send);
const selectedSendCoin = ref(coins[0]);
const selectedReceiveCoin = ref(coins[1]);
const sendAmount = ref<number | null>(null);
const receiveAmount = ref<number | null>(null);
const minSendAmount = ref<number>(0);
const minReceiveAmount = ref<number>(0);
const maxSendAmount = ref<number>(0);
const maxReceiveAmount = ref<number>(0);
const receivingAddress = ref("");
const receivingAddressHasError = ref(false);
const isValidatingReceivingAddress = ref(false);
const isFetchingSendRate = ref(false);
const isFetchingReceiveRate = ref(false);
const isFetchingCoins = ref(coins.length <= 2);
const rate = ref(0);

const rateTooltipText=`live market EXCHANGE RATE displayed until you send funds for your exchange.
Once funds are deposited, the exchange rate becomes LOCKED-IN
`

onBeforeMount(async () => {
  store
    .fetchCEXCoins()
    .then(() => {
      selectedSendCoin.value = store.getCoins[0];
      selectedReceiveCoin.value = store.getCoins[1];
      sendAmount.value = 1;
      onAmountInputChange(true);
      fetchRate();
    })
    .catch((err) => {
      store.setPermanentToastMessage(err, ToastMessageKind.Error);
    })
    .finally(() => {
      isFetchingCoins.value = false;
      store.showLoading = false;
    });
});

const openDialogFunc = (swapType: SwapType) => {
  return () => {
    dialogDirection.value = swapType;
    shouldOpenDialog.value = true;
  };
};

const swapCoins = async () => {
  const temp = selectedSendCoin.value;
  //const amountTemp = sendAmount.value
  const minAmountTemp = minSendAmount.value;
  const maxAmountTemp = maxSendAmount.value;

  selectedSendCoin.value = selectedReceiveCoin.value;
  sendAmount.value = receiveAmount.value;
  selectedReceiveCoin.value = temp;
  receiveAmount.value = 0;
  minSendAmount.value = minReceiveAmount.value;
  minReceiveAmount.value = minAmountTemp;
  maxSendAmount.value = maxReceiveAmount.value;
  maxReceiveAmount.value = maxAmountTemp;
  await fetchRate();
};

const closeDialog = () => {
  shouldOpenDialog.value = false;
};

const onCoinSelected = async (coin: Coin) => {
  if (dialogDirection.value === SwapType.Send) {
    if (coin.key === selectedReceiveCoin.value.key) {
      await swapCoins();
    } else {
      selectedSendCoin.value = coin;
      await fetchRate();
    }
    onAmountInputChange(true);
  } else if (dialogDirection.value === SwapType.Receive) {
    if (coin.key === selectedSendCoin.value.key) {
      await swapCoins();
    } else {
      selectedReceiveCoin.value = coin;
      await fetchRate();
    }
    onAmountInputChange(false);
  }

  // fetchRate()
  closeDialog();
};

const validate = async (): Promise<boolean> => {
  if (
    minSendAmount.value > 0 ||
    maxSendAmount.value > 0 ||
    minReceiveAmount.value > 0 ||
    maxSendAmount.value > 0
  ) {
    store.setToastMessage(
      "Please ensure the amounts entered are valid",
      ToastMessageKind.Error
    );
    return false;
  }

  if (!sendAmount.value || !receiveAmount.value) {
    store.setToastMessage(
      "Please enter the amounts you wish to swap",
      ToastMessageKind.Error
    );
    return false;
  }

  if (!receivingAddress.value) {
    receivingAddressHasError.value = true;
    store.setToastMessage(
      "Please ensure you fill out the Receiving address correctly",
      ToastMessageKind.Error
    );
    return false;
  }

  let isAddressValid = await store.validateAddress({
    currency: selectedReceiveCoin.value.code,
    network: selectedReceiveCoin.value.networkCode,
    address: receivingAddress.value,
  });

  if (isAddressValid === -1) {
    store.setToastMessage(
      "Unable to validate receiving address. Please try again",
      ToastMessageKind.Error
    );
    return false;
  } else if (isAddressValid === 0) {
    receivingAddressHasError.value = true;
    store.setToastMessage(
      "Please ensure your address and network match",
      ToastMessageKind.Error
    );
    return false;
  }

  return true;
};

const placeOrder = async () => {
  store.setToastMessage("Placing order", ToastMessageKind.Wait);

  const req: PlaceCEXOrderRequest = {
    amount: sendAmount.value as number,
    receive: selectedReceiveCoin.value.code,
    receiveAddress: receivingAddress.value,
    receiveNetwork: selectedReceiveCoin.value.networkCode,
    send: selectedSendCoin.value.code,
    sendNetwork: selectedSendCoin.value.network,
    userDeviceId: localStorage.getItem("deviceID") as string,
  };

  store
    .placeCEXOrder(req)
    .then((res) => {
      store.setToastMessage(
        "Order Placed Successfuly!",
        ToastMessageKind.Positive
      );
      router.push(`/order`);
    })
    .catch((err) => {
      store.setToastMessage(err, ToastMessageKind.Error);
    });
};

const handleSwap = async () => {
  let isSwapValid = await validate();
  if (!isSwapValid) {
    return;
  }

  placeOrder();
};

const handleSwapClick = () => {
  swapCoins();
};

const fetchRate = () => {
  const req: FetchRateRequest = {
    send: selectedSendCoin.value.code,
    receive: selectedReceiveCoin.value.code,
    sendNetwork: selectedSendCoin.value.networkCode,
    receiveNetwork: selectedReceiveCoin.value.networkCode,
  };
  // console.log("fetchRate",{req})
  store
    .fetchCEXExchangeAmount(req)
    .then(async (resp: FetchRateResponse) => {
      // console.log("fetchRateResp", {resp})
      if (resp.rate) {
        rate.value = resp.rate;
      } else if (resp.minimumAmount) {
        req.amount = resp.minimumAmount;
        try {
          const rateResp = await store.fetchCEXExchangeAmount(req);
          rate.value = rateResp.rate;
        } catch (err: any) {
          store.setToastMessage(err, ToastMessageKind.Error);
        }
      }
    })
    .catch((err) => {
      store.setToastMessage(err, ToastMessageKind.Error);
    });
};

const onAmountInputChange = (isSendInput: boolean) => {
  debounce(() => {
    if (isSendInput) {
      if (!sendAmount.value || sendAmount.value < 0) {
        sendAmount.value = 0;
      }
    } else {
      if (!receiveAmount.value || receiveAmount.value < 0) {
        receiveAmount.value = 0;
      }
    }
    const req: FetchRateRequest = {
      send: selectedSendCoin.value.code,
      receive: selectedReceiveCoin.value.code,
      sendNetwork: selectedSendCoin.value.networkCode,
      receiveNetwork: selectedReceiveCoin.value.networkCode,
      amount: sendAmount.value ? sendAmount.value : 0,
    };

    if (isSendInput) {
      isFetchingReceiveRate.value = true;
    } else {
      isFetchingSendRate.value = true;
      req.amount = receiveAmount.value ? receiveAmount.value : 0;
      req.amountType = "receive";
    }
    store
      .fetchCEXExchangeAmount(req)
      .then((resp: FetchRateResponse) => {
        if (isSendInput) {
          if (!sendAmount.value || resp.sendAmount > sendAmount.value) {
            minSendAmount.value = resp.sendAmount;
            receiveAmount.value = 0;
          } else if (
            resp.maximumAmount &&
            sendAmount.value > resp.maximumAmount
          ) {
            maxSendAmount.value = resp.maximumAmount;
            receiveAmount.value = 0;
          } else if (
            resp.minimumAmount &&
            sendAmount.value < resp.minimumAmount
          ) {
            minSendAmount.value = resp.minimumAmount;
            receiveAmount.value = 0;
          } else if (resp.maximumAmount < sendAmount.value) {
            maxSendAmount.value = resp.maximumAmount;
            receiveAmount.value = 0;
          } else {
            minSendAmount.value = 0;
            maxSendAmount.value = 0;
            receiveAmount.value = Number(resp.receiveAmount);
          }
        } else {
          if (
            !receiveAmount.value ||
            resp.receiveAmount > receiveAmount.value
          ) {
            minReceiveAmount.value = Number(resp.receiveAmount);
            sendAmount.value = 0;
          } else if (
            resp.maximumAmount &&
            receiveAmount.value > resp.maximumAmount
          ) {
            maxReceiveAmount.value = Number(resp.maximumAmount);
            sendAmount.value = 0;
          } else if (
            resp.minimumAmount &&
            receiveAmount.value < resp.minimumAmount
          ) {
            minReceiveAmount.value = Number(resp.minimumAmount);
            sendAmount.value = 0;
          } else if (resp.maximumAmount < receiveAmount.value) {
            maxReceiveAmount.value = Number(resp.maximumAmount);
            sendAmount.value = 0;
          } else {
            minReceiveAmount.value = 0;
            maxReceiveAmount.value = 0;
            sendAmount.value = Number(resp.sendAmount);
          }
        }
      })
      .catch((err) => {
        store.setToastMessage(err, ToastMessageKind.Error);
      })
      .finally(() => {
        if (isSendInput) {
          isFetchingReceiveRate.value = false;
        } else {
          isFetchingSendRate.value = false;
        }
      });
  });
};
</script>
<style>
.token-container {
  width: 50%;
}

.swap-box-content {
  position: relative;
}

.swap-btn-container {
  border: 2px solid #fff;
  border-radius: 100%;
  padding: 10px;
  height: fit-content;
  width: fit-content;
  margin: auto;
  position: absolute;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  cursor: pointer;
  margin: auto;
  background-color: rgb(var(--v-theme-background));

  .v-icon {
    font-size: 40px;
  }
}

.swap-btn {
  width: 100%;
  margin-top: 20px;
  height: 50px !important;
}

.swap-box-wrapper {
  padding: 0 2rem;
}

.steps-box {
  margin-top: 1rem;
}
</style>
