<template>
  <li
    class="coin-item d-flex flex-row justify-space-between align-center"
    :class="{ selected: isSelectedCoin(), suspended: isSuspended() }"
    @click.stop="onClick()"
  >
    <div
      class="suspended-text"
      v-if="isSuspended()"
    >Currently Suspended</div>
    <div class="coin-info d-flex flex-row">
      <div class="d-flex flex-row justify-space-between align-center">
        <img
          :src="coin.iconURL"
          @error="handleCoinSourceError"
          width="40px"
          height="40px"
          style="border-radius: 100%;"
        />
      </div>
      <div style="text-align: left;">
        <span class="coin-name">{{ coin.name }}</span>
        <p class="coin-network">{{ coin.network!="SOL"?coin.network:truncateMiddle(coin.networkCode) }}</p>
      </div>
    </div>
    <Image
      src="/images/selectedCoin.svg"
      class="selected"
      v-if="isSelectedCoin()"
    />
    <Image
      src="/images/trending.svg"
      class="trending"
      v-if="!isSelectedCoin() && coin.isTrending"
    />
  </li>
</template>
<script
  setup
  lang="ts"
>
import { Coin, SwapType } from '@/interfaces'
import Image from '@/components/Image.vue'
import { truncateMiddle } from '@/utils';

interface Props {
  coin: Coin
  swapType: SwapType
  selectedSendCoin: Coin
  selectedReceiveCoin: Coin
  onSelect: (coin: Coin) => void
}
const props = defineProps<Props>();

// console.log('coinitem',props.coin.iconURL)
const handleCoinSourceError = () => {
  props.coin.iconURL = '/public/images/coins/unknownCoin.svg'
}

const isSelectedCoin = (): boolean => {
  let selectedCoin;
  if (props.swapType == SwapType.Receive) {
    selectedCoin = props.selectedReceiveCoin
  } else if (props.swapType == SwapType.Send) {
    selectedCoin = props.selectedSendCoin
  }

  if (!selectedCoin) {
    return false
  }

  return props.coin.key === selectedCoin.key
}

const isSuspended = (): boolean => {
  if (props.swapType === SwapType.Receive && !props.coin.receiveStatus) {
    return true
  } else if (props.swapType === SwapType.Send && !props.coin.sendStatus) {
    return true
  }

  return false
}
const onClick = () => {
  if (!isSuspended()) {
    props.onSelect(props.coin)
  }
}
</script>
<style
  lang="scss"
  scoped
>
li.coin-item {
  padding: 8px;
  border-radius: 4px;
  margin: 3px 0;
  position: relative;

  &:not(.suspended) {
    cursor: pointer;
  }

  &.suspended {
    background: #383b40;
  }

  .suspended-text {
    position: absolute;
    top: 0;
    right: 0;
    font-size: 11px;
    background: rgba(255, 90, 68, 0.2);
    padding: 5px 12px;
    border-top-right-radius: 4px;
  }

  img {
    vertical-align: middle;
  }

  &.selected,
  &:hover {
    background: #383b40;
    transition: ease-in-out 0.45s;
  }
}

.coin-info {
  gap: 15px;
}

.trending {
  width: 32px;
  height: 32px;
}

img.selected {
  width: 40px;
  height: 40px;
}

p.coin-network {
  font-size: 0.7rem;
  color: rgb(var(--v-theme-primary));
  margin-bottom: 1rem;
  text-align: left;
}

.coin-name {
  font-size: 1.15rem;
  text-align: left;

}
</style>
