<template>
  <v-dialog
    class="select-coin-dialog"
    max-width="500"
    height="100%"
    opacity="0"
    v-model="shouldOpenDialogValue"
    :fullscreen="isMobile"
  >
    <dialog-header :swapType="direction" :on-close-button-click="closeDialog" />
    <search-bar :on-search-input="onSearchInput" />
    <ul class="coins-list">
      <template v-for="(coin, _) in coins" :key="coin.key">
        <coin-item
          :coin="coin"
          :swapType="direction"
          :selectedSendCoin="selectedSendCoin"
          :selectedReceiveCoin="selectedReceiveCoin"
          :on-select="onSelect"
        />
      </template>
    </ul>
  </v-dialog>
</template>
<script setup lang="ts">
import DialogHeader from "./Header.vue";
import SearchBar from "./SearchBar.vue";
import CoinItem from "./CoinItem.vue";

import { Coin, SwapType } from "@/interfaces";
import { ref, computed, onMounted, onBeforeUnmount } from "vue";
import useStore from "@/store";

interface Props {
  shouldOpenDialog: boolean;
  direction: SwapType;
  selectedSendCoin: Coin;
  selectedReceiveCoin: Coin;
  onCoinSelected: (coin: Coin) => void;
  closeDialog: () => void;
  pinned?: string;
}

const props = defineProps<Props>();
const store = useStore();
// const shouldOpenDialogValue = ref(props.shouldOpenDialog)
const shouldOpenDialogValue = false;
const searchTerm = ref("");
const isMobile = ref(false);

const updateIsMobile = () => {
  isMobile.value = window.innerWidth < 500;
};

onMounted(() => {
  updateIsMobile();
  window.addEventListener("resize", updateIsMobile);
});

onBeforeUnmount(() => {
  window.removeEventListener("resize", updateIsMobile);
});

const onSearchInput = (value: string) => {
  searchTerm.value = value;
};
const maxDisplayedCoins = 100;

const coins = computed(() => {
  const pinned = store.getCoins.find((c: Coin) => {
    // console.log(c.name)
    return c.name.toLowerCase() === props?.pinned?.toLowerCase();
  });
  const getList = () => {
    if (!searchTerm.value || searchTerm.value.trim() === "") {

      const ret =  store.getCoins.slice(0, maxDisplayedCoins);
      if(pinned){
        pinned.isTrending=true;
        ret.unshift(pinned);
      }
      return ret
    }

    const localCoins: Coin[] = store.getCoins;
    const coins: Coin[] = localCoins.filter((item) => {
      const code = item.code.toLowerCase();
      //const network = item.network.toLowerCase()
      const name = item.name.toLowerCase();
      //const networkCode = item.networkCode.toLowerCase()
      const networkCode = item.networkCode.toLowerCase();
      const term = searchTerm.value.toLowerCase();
      /**if (code.includes(term) || network.includes(term) || name.includes(term) || networkCode.includes(term)) {
     return true
     }**/
      // if (props.pinned) {
      //   const pn = props.pinned.toLowerCase()
      //   if (code.includes(pn) || name.includes(pn)) {
      //     return false;
      //   }
      // }
      if (name.includes(term) || code.includes(term) || networkCode.includes(term)) {
        return true;
      }

      return false;
    });

    const searched = coins.slice(0, maxDisplayedCoins);
    return searched;
  };
  const list = getList();
  return list;
});

const closeDialog = () => {
  props.closeDialog();
  searchTerm.value = "";
};

const onSelect = (coin: Coin) => {
  searchTerm.value = "";
  props.onCoinSelected(coin);
};
</script>
<style lang="scss">
.select-coin-dialog {
  .v-overlay__content {
    padding: 28px 24px;
    background: linear-gradient(
      to bottom,
      rgb(3 0 10 / 90%) 80%,
      rgb(44 44 44 / 50%)
    );
    backdrop-filter: blur(4px);
    -webkit-backdrop-filter: blur(4px);
    border: 1px solid white;
    border-radius: 0.25rem;
    transition: all 0.3s ease;
    max-height: 100% !important;
    height: 100%;
  }

  .coins-list {
    overflow-x: hidden;
    overflow-y: auto;
    margin-top: 2rem;
    height: 95%;
    padding: 0 3px;
  }
}
</style>
