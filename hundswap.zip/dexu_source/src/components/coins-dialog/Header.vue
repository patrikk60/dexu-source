<template>
  <header class="d-flex flex-row justify-space-between">
    <h2>You {{ (swapType === SwapType.Send) ? "Send" : "Receive" }}</h2>
    <button @click.stop="closeModal">
      <v-icon icon="fa fa-close"></v-icon>
    </button>
  </header>
</template>
<script
  setup
  lang="ts"
>
import { SwapType } from '@/interfaces';

interface Props {
  swapType: string
  onCloseButtonClick: () => void
}

const props = defineProps<Props>()

const closeModal = () => {
  props.onCloseButtonClick()
}
</script>
<style
  lang="scss"
  scoped
>
header {
  h2 {
    color: rgb(179, 187, 202);
    font-size: 1.5rem;
    text-transform: uppercase;
    letter-spacing: 1px;
    font-weight: 500;
  }

  .v-icon {}
}
</style>