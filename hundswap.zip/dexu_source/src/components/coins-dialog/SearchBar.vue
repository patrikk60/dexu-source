<template>
  <div class="search-bar d-flex flex-row align-center">
    <div class="search-icon">
      <v-icon icon="fa fa-search"></v-icon>
    </div>
    <input
      type="text"
      placeholder="Search"
      autocomplete="off"
      @input="onInput"
    />
  </div>
</template>
<script
  setup
  lang="ts"
>
import useDebounce from '@/hooks/useDebounce';
interface Props {
  onSearchInput: Function
}

const props = defineProps<Props>()
const debounce = useDebounce()
const onInput = (event: Event) => {
  debounce(() => {
    const target = event.target as HTMLInputElement;
    props.onSearchInput(target.value)
  })
}
</script>
<style
  lang="scss"
  scoped
>
.search-bar {
  height: 70px;
  margin-top: 30px;
  border: 1px solid white;
  border-bottom-width: 4px;
  border-radius: 0.3rem;

  .search-icon {
    padding: 0 15px;
  }

  input {
    height: 100%;
    flex-grow: 1;
    outline: 0;
    border: 0;

    &:focused {
      outline: 0;
      border: 0;
    }
  }
}
</style>
