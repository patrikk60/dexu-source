<template>
  <v-container  style="display: flex; flex-direction: column; justify-content: center; align-items: center;">
    <slot></slot>
  </v-container>
</template>
