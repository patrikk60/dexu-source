<template>
  <div class="box">
    <slot></slot>
  </div>
</template>
<style
  lang="scss"
  scoped
>
.box {
  border: 2px solid #383b40;
  border-radius: 0.5rem;

  &.padded {
    padding: 2rem;
  }

  &.padded-side {
    padding: 0 2rem;
    padding-bottom: 2rem;
  }
}
</style>