<template>
  <div>
    <detail-text
      label="Deposit Hash"
      :text="orderStatus.hashIn"
      :copy="true"
      bold
    />
    <detail-text
      label="Withdrawal Hash"
      :text="orderStatus.hashOut"
      :copy="true"
      bold
    />
    <div class="extras d-flex flex-column justify-center align-center">
      <div class="check">
        <v-icon
          icon="fa fa-check"
          color="primary"
        ></v-icon>
      </div>
      <div class="sent-text">
        <p class="light-text">We Have Sent You</p>
        <p>{{ `${orderStatus.receiveAmount} ${order.receiveNetwork} (${order.receiveNetwork})` }}</p>
      </div>
      <div class="action">
        <btn @click="handleNewSwapClick">New Swap</btn>
      </div>
    </div>
    <detail-text
      :label="swapIDText"
      :copy="false"
      :copy-label="true"
      class="spaced-down"
    />
  </div>
</template>
<script
  setup
  lang="ts"
>

import DetailText from './components/DetailText.vue'
import { PlaceCEXOrderResponse, OrderStatusResponse } from '@/interfaces'
import Btn from '@/components/Btn.vue'
import { useRouter } from 'vue-router';

interface Props {
  order: PlaceCEXOrderResponse
  orderStatus: OrderStatusResponse
}
const props = defineProps<Props>()

const router = useRouter()
const swapIDText = `SWAP ID: ${props.order.id}`
const handleNewSwapClick = () => {
  router.push("/")
}
</script>
<style
  lang="scss"
  scoped
>
.v-icon {
  border: 10px solid rgb(var(--v-theme-primary));
  border-radius: 100%;
  width: 160px;
  height: 160px;
  font-size: 90px;
  font-weight: 600;
}

.sent-text {
  text-transform: uppercase;
  margin-top: 8px;
  text-align: center;

  p.light-text {
    color: rgb(var(--v-theme-lightTextColor))
  }
}

.action {
  margin: 4px 0;

  .v-btn {
    text-transform: uppercase;
    color: #3a3a3a;
  }
}
</style>
