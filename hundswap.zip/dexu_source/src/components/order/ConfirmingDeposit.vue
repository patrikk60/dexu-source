<template>
  <div>
    <detail-text
      label="Deposit Hash"
      :text="orderStatus.hashIn"
      :copy="true"
      bold
    />
    <div class="d-flex flex-row justify-center">
      <div class="extras">
        <v-progress-circular
          indeterminate
          :size="190"
          :width="15"
          color="primary"
        />
      </div>
    </div>
    <receive-details :order="order" />
  </div>
</template>
<script
  setup
  lang="ts"
>
import { OrderStatusResponse, PlaceCEXOrderResponse } from '@/interfaces'
import ReceiveDetails from './components/ReceiveDetails.vue'
interface Props {
  orderStatus: OrderStatusResponse
  order: PlaceCEXOrderResponse
}
defineProps<Props>()

</script>
