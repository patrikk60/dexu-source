<template>
  <div class="status-heading d-flex flex-row">
    <span id="status">{{ status }}</span>
    <v-progress-circular
      indeterminate
      :size="20"
      :width="2"
      v-if="status === OrderStatusKind.AwaitingDeposit
      || status === OrderStatusKind.ConfirmingDeposit
      || status === OrderStatusKind.Exchanging
      || status === OrderStatusKind.Sending"
    ></v-progress-circular>
    <v-icon
      icon="fa fa-check"
      color="primary"
      v-if="status == OrderStatusKind.Complete"
    ></v-icon>
  </div>
</template>
<script
  setup
  lang="ts"
>
import { OrderStatusKind } from '@/interfaces'

interface Props {
  status: OrderStatusKind
}
defineProps<Props>()
</script>
<style
  lang="scss"
  scoped
>
#status {
  text-transform: uppercase;
  margin-right: 8px;
}

.v-progress-circular {
  margin: auto 0;
  top: 0;
  bottom: 0;
}
</style>