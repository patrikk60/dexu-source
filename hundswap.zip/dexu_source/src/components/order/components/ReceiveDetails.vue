<template>
  <div class="receive-details">
    <detail-text
      label="You'll Receive"
      :text="receiveText"
      :copy="false"
      class="spaced-down"
    />

    <detail-text
      label="To The Address"
      :text="props.order.receiveAddress"
      :copy="false"
      class="spaced-down"
    />

    <detail-text
      :label="swapIDText"
      :copy="false"
      :copy-label="true"
      class="spaced-down"
    />
  </div>
</template>
<script
  setup
  lang="ts"
>
import { PlaceCEXOrderResponse } from '@/interfaces'
interface Props {
  order: PlaceCEXOrderResponse
}
const props = defineProps<Props>()
const receiveText = `${props.order.receiveAmount} ${props.order.receive} (${props.order.receiveNetwork})`
const swapIDText = `SWAP ID: ${props.order.id}`
</script>
<style
  scoped
  lang="scss"
>
.spaced-down {
  margin-bottom: 15px;
}
</style>
