<template>
  <div class="qrcode-wrapper d-flex flex-row justify-center">
    <div class="qrcode-content">
      <qrcode-vue
        :value="value"
        :level="level"
        :render-as="renderAs"
        :size="190"
      />
    </div>
  </div>
</template>
<script
  setup
  lang="ts"
>
import QrcodeVue, { Level, RenderAs } from 'qrcode.vue'
import { ref } from 'vue';

interface Props {
  data: any
}

const props = defineProps<Props>()
const value = ref(props.data)
const level = ref<Level>('L')
const renderAs = ref<RenderAs>('canvas')
</script>
<style
  lang="scss"
  scoped
>
.qrcode-content {
  padding: 10px;
  background-color: #fff;
  border-radius: 25px;
}
</style>