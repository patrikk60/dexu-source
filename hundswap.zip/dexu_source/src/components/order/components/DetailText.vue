<template>
  <div class="detail">
    <div class="detail-label d-flex flex-row g-2">
      <span id="label">{{ label }}</span>
      <div
        class="copy-button"
        id="label-copy-button"
        style="margin-left: 5px;"
        v-if="copyLabel"
        @click="handleCopy(label)"
      >
        <v-icon icon="fa-regular fa-copy"></v-icon>
      </div>
    </div>
    <div
      class="detail-text d-flex flex-row"
      :class="{ 'bolded': bold }"
      v-if="text"
    >
      <div class="main-text">
        <span>{{ text }}</span>
      </div>
      <div
        class="copy-button"
        id="text-copy-button"
        @click="handleCopy(text)"
        v-if="copy"
      >
        <v-icon icon="fa-regular fa-copy"></v-icon>
      </div>
      <div
        class="after-copy-button"
        v-if="afterCopyText"
      >
        <span>{{ afterCopyText }}</span>
      </div>
    </div>
  </div>
</template>
<script
  setup
  lang="ts"
>
import { useClipboard } from '@vueuse/core';
import useStore from '@/store';
import { ToastMessageKind } from '@/interfaces';

interface Props {
  label: string
  text?: string
  copy: boolean
  afterCopyText?: string
  bold?: boolean
  copyLabel?: boolean
}

defineProps<Props>()

const store = useStore()
const clipboard = useClipboard()
const handleCopy = (text: string) => {
  clipboard.copy(text)
  store.setToastMessage("Copied!", ToastMessageKind.Positive)
} 
</script>
<style
  lang="scss"
  scoped
>
.detail {
  font-size: 13px;
  letter-spacing: 1px;

  .detail-label {
    text-transform: uppercase;
    color: rgb(var(--v-theme-lightTextColor));
    margin-bottom: 0.1rem;
  }

  .detail-text {
    &.bolded {
      font-weight: bold;
    }

    >div {
      padding-right: 5px;
    }
  }

  .copy-button .v-icon {
    font-size: 13px;
  }

  .copy-button {
    cursor: pointer;
  }
}

.main-text {
  max-width: 94%;
  overflow: hidden;
  text-overflow: ellipsis;
}
</style>