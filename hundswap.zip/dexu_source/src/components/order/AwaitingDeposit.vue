<template>
  <div>
    <detail-text
      label="Send Exactly"
      :text="order.sendAmount"
      :copy="true"
      :after-copy-text="order.send"
      bold
    />
    <detail-text
      label="To The Address"
      :text="order.sendAddress"
      :copy="true"
      bold
    />
    <qrcode
      :data="order.sendAddress"
      class="qrcode extras"
    />
    <receive-details :order="order" />
  </div>
</template>
<script
  setup
  lang="ts"
>
import { PlaceCEXOrderResponse } from '@/interfaces'
import DetailText from './components/DetailText.vue'
import Qrcode from './components/Qrcode.vue'
import ReceiveDetails from './components/ReceiveDetails.vue'

interface Props {
  order: PlaceCEXOrderResponse
}
defineProps<Props>()

</script>
