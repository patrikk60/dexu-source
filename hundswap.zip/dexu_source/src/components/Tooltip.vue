<template>
  <v-tooltip
    :text="text"
    location="top"
    width="200px"
    v-model="show"
  >
    <template v-slot:activator="{ props }">
      <div
        v-bind="props"
        @click="onTriggerClick"
        v-click-outside="onClickOutside"
      >
        <slot></slot>
      </div>
    </template>
  </v-tooltip>
</template>
<script
  lang="ts"
  setup
>
import { ref, onMounted, onUnmounted } from 'vue'

interface Props {
  text: string
}
defineProps<Props>()

const show = ref(false)

const handleScroll = () => {
  show.value = false
};

// Add scroll event listener when component is mounted
onMounted(() => {
  window.addEventListener('scroll', handleScroll);
});

// Remove scroll event listener when component is unmounted
onUnmounted(() => {
  window.removeEventListener('scroll', handleScroll);
});



const isMobileScreen = (): boolean => {
  return window.innerWidth <= 775
}

const onTriggerClick = () => {
  if (isMobileScreen()) {
    show.value = !show.value
  }
}

const onClickOutside = () => {
  show.value = false
}

</script>
<style
  lang="scss"
  scoped
>
.v-tooltip {
  color: #fff !important;
}
</style>