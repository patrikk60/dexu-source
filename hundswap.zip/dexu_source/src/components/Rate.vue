<template>
  <div class="rate-container text-center d-flex flex-row">
    <p class="exchange-rate" :style="{visibility: rate ? 'visible' : 'hidden', display:'flex'}">
      1 {{ sendCoin.code }} =
      {{ rate ? (Number(rate) > 1 ? formatAmount(Number(rate)) : rate) : "?" }}
      {{ receiveCoin.code }}
      <div v-if="tooltipText" class="icon-container" :style="{visibility: rate ? 'visible' : 'hidden', marginLeft:'8px'}">
        <tooltip :text="tooltipText">
          <v-icon icon="fa fa-question"></v-icon>
        </tooltip>
      </div>
    </p>
    <slot></slot>
  </div>
</template>
<script setup lang="ts">
import { Coin } from "@/interfaces";
import Tooltip from "@/components/Tooltip.vue";
import { formatAmount } from "@/utils";

interface Props {
  rate?: number | string;
  sendCoin: Coin;
  receiveCoin: Coin;
  tooltipText?: string;
}
defineProps<Props>();
</script>
<style lang="scss" scoped>
.rate-container {
  padding: 10px 0;
  gap: 7px;
  width: 100%;
  position: relative;
  .exchange-rate {
    margin-left: auto;
    margin-right: auto;
  }
  .v-icon {
    font-weight: 300;
    font-size: 9px;
    border: 1px solid rgb(var(--v-theme-lightTextColor));
    width: 20px;
    height: 20px;
    border-radius: 100%;
    padding: 3px;
    margin-top: -5px;
    cursor: pointer;
  }
}
</style>
