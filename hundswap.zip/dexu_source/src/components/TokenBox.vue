<template>
  <div class="swap-item heavy-border border-white">
    <div
      class="selector-container d-flex align-center"
      @click.stop="openDialog"
    >
      <div class="coin-logo">
        <v-progress-circular
          indeterminate
          :size="80"
          :width="1"
          v-if="isFetchingCoins"
        />
        <img :src="coin.iconURL" @error="handleCoinSourceError" v-else />
      </div>
      <div class="coin-info">
        <p class="swap-action-text">You {{ getSwapTypeText() }}</p>
        <h1 class="swap-coin">{{ coin.code }}</h1>
        <span class="swap-network sn-bordered">{{
          coin.network != "SOL"
            ? coin.network
            : coin.networkCode.toUpperCase().startsWith("SO111111111111")
            ? truncateMiddle(coin.networkCode, 24)
            : truncateMiddle(coin.networkCode, 10)
        }}</span>
        <div class="amount-modifier-container swap-network">
          <span
            v-if="coin.network == 'SOL' && !!onHalf"
            class="sn-bordered amount-modifier"
            @click.stop="onHalf"
            >HALF</span
          >
          <span
            v-if="coin.network == 'SOL' && !!onMax"
            class="sn-bordered amount-modifier"
            @click.stop="onMax"
            >MAX</span
          >
        </div>
      </div>
    </div>
    <div class="input-container d-flex">
      <label>{{ coin.code }}</label>
      <div class="d-flex flex-row align-center">
        <v-progress-circular
          indeterminate
          :size="20"
          :width="1"
          v-if="isFetchingRate"
        />
      </div>
      <input
        v-if="disabled"
        placeholder="0"
        :value="
          amountVal
            ? amountVal > 1
              ? formatAmount(amountVal)
              : amountVal
            : undefined
        "
        disabled
        class="disabled"
      />
      <input
        v-else
        type="number"
        placeholder="0"
        v-model="amountVal"
        @input="onAmountChange"
      />
      <span class="min-amount right-amount amount-limit" v-if="minAmount > 0"
        >Min: {{ minAmount }}</span
      >
      <span class="max-amount right-amount amount-limit" v-if="maxAmount > 0"
        >Max: {{ maxAmount }}</span
      >
      <v-progress-circular
        indeterminate
        :size="10"
        :width="1.5"
        color="#A9A9A9"
        class="right-amount progress"
        v-if="isFetchingDollarAmount"
      />
      <span
        class="right-amount disabled"
        v-if="Number(dollarAmount) > 0 && !isFetchingDollarAmount"
      >
        <v-icon icon="fa fa-dollar" size="xs" style="margin-bottom: 2px" />{{
          formatAmount(dollarAmount || 0)
        }}
      </span>
      <!-- <v-progress-circular
        indeterminate
        :size="10"
        :width="1.5"
        class="left-amount progress current-amount"
        v-if="isFetchingCurrAmount"
      /> -->
      <span
        class="left-amount current-amount"
        v-if="currentAmount || currentAmount == 0"
        ><v-icon icon="fa fa-wallet" size="xs" />{{ currentAmount }}</span
      >
    </div>
  </div>
</template>
<script setup lang="ts">
import { Coin, SwapType } from "@/interfaces";
import { ref, watch } from "vue";
import { truncateMiddle } from "@/utils";
import { formatAmount } from "../utils";

interface Props {
  SwapType: SwapType;
  coin: Coin;
  amount?: number | null;
  minAmount: number;
  maxAmount: number;
  isFetchingRate: boolean;
  isFetchingCoins: boolean;
  isFetchingDollarAmount?: boolean;
  isFetchingCurrAmount?: boolean;
  onInput: () => void;
  openDialog: () => void;
  disabled?: boolean;
  currentAmount?: number;
  dollarAmount?: number;
  onHalf?: () => void;
  onMax?: () => void;
}

const props = defineProps<Props>();
const emit = defineEmits();
const amountVal = ref(props.amount);
const getSwapTypeText = (): string =>
  props.SwapType === SwapType.Send ? "Send" : "Receive";
const handleCoinSourceError = () => {
  props.coin.iconURL = "/public/images/coins/unknownCoin.svg";
};
const onAmountChange = () => {
  emit("update:amount", amountVal.value);
  props.onInput();
};
watch(
  () => props.amount,
  (newAmount) => {
    amountVal.value = newAmount;
  }
);
// @media screen and (min-width: 990px) and (max-width: 1420px) {
//   .selector-container {
//     padding: 30px 0;
//     padding-top: 20px;
//     flex-direction: column;
//     height: 260px !important;
//   }
//   .swap-coin {
//     text-align: center;
//   }
//   .input-container {
//     flex-direction: column;
//     height: 85px;
//   }
//   .input-container input {
//     margin-top: -40px;
//     text-align: left;
//     margin-left: 10px;
//   }
//   .right-amount {
//     right: unset;
//     left: 0.5rem;
//     bottom: 20px;
//   }
//   .left-amount {
//     left: 10px;
//   }
// }
</script>

<style>
  .sn-bordered {
    border: 1px solid rgb(var(--v-theme-primary));
    border-radius: 0.2rem;
    padding: 0 0.5rem;
    cursor: pointer;
  }
</style>
<style lang="scss" scoped>
.disabled {
  color: darkgray;
}
.swap-item {
}
.right-amount {
  position: absolute;
  bottom: 3px;
  right: 1rem;
  font-size: 13px;
}
.progress {
  margin-bottom: 4px;
}
.left-amount {
  position: absolute;
  bottom: 3px;
  left: 1rem;
  font-size: 13px;
}
.amount-limit {
  color: rgba(252, 70, 85, 0.8);
}
.current-amount {
  display: flex;
  align-items: center;
}
.fa-wallet {
  margin-right: 0.3rem;
  margin-top: 2px;
}
.selector-container {
  padding: 20px 0;
  padding-left: 20px;
  gap: 1rem;
  height: 150px;
  cursor: pointer;
  flex-direction: row;
}

.input-container {
  border-top: 2px solid white;
  height: 65px;
  position: relative;
  padding-right: 1rem;
  flex-direction: row;

  .v-progress-circular {
    margin-left: 5px;
    color: #fff;
  }

  input {
    height: 100%;
    flex-grow: 1;
    text-overflow: ellipsis;
    text-align: right;

    &:focus {
      border: none;
      outline: none;
    }

    &::-webkit-outer-spin-button,
    &::-webkit-inner-spin-button {
      -webkit-appearance: none;
      margin: 0;
    }

    -moz-appearance: textfield;
  }

  label {
    display: flex;
    align-items: center;
    margin-left: 10px;
  }
}

.coin-info {
  // width: 100%;
  text-transform: uppercase;

  .swap-action-text {
    font-size: 0.8rem;
    color: rgb(var(--v-theme-lightTextColor));
  }

  .swap-coin {
    margin-top: 10px;
    font-size: 25px;
  }



  .amount-modifier-container {
    margin-top: 4px;
    gap: 6px;
  }
  .amount-modifier {
    // margin-top:4px;
    width: 100%;
    cursor: pointer;
    z-index: 20;
  }

  .swap-network {
    text-align: center;
    max-width: 160px;
    display: flex;
    justify-content: center;
  }

  @media screen and (max-width: 768px) {
    .swap-network {
      margin-left: auto;
    }
  }
}
.coin-logo {
  img {
    width: 80px;
    height: 80px;
    border-radius: 100%;
  }
}
</style>
