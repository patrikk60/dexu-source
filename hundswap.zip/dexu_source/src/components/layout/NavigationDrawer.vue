<template>
  <v-navigation-drawer
    v-model="store.openNavigationDrawer"
    touchless
    style="padding-bottom: 20px;"
  >
    <v-list>
      <v-list-item ><a href="https://hundonsol.com" style="color:inherit;">Token</a></v-list-item>
      <v-list-item to="/help">Faq</v-list-item>
      <!-- <v-list-item to="/shop">Shop</v-list-item>
      <v-list-item to="/nft">Nft</v-list-item> -->
    </v-list>
    <template v-slot:append>
      <div class="pa-2 social-menu">
        <a href="https://twitter.com/HundOnSol">
          <v-icon icon="fa-brands fa-x-twitter fa-xl"></v-icon>
        </a>
        <a href="https://t.me/HundCoin">
          <v-icon icon="fa-brands fa-telegram fa-xl"></v-icon>
        </a>
        <a href="https://discord.gg/HundOnSol">
          <v-icon icon="fa-brands fa-discord fa-xl"></v-icon>
        </a>
      </div>
    </template>
  </v-navigation-drawer>
</template>
<script
  setup
  lang="ts"
>
import useStore from '@/store';
const store = useStore();
</script>
<style
  lang="scss"
  scoped
>
.social-menu {
  color: #fff;
  margin-bottom: 10px;
  text-align: center;

  a {
    margin-right: 10px;
    color: #fff;
    font-size: 30px;
  }
}

.v-list-item {
  font-size: 25px;
  padding: 18px 28px;
  text-decoration: none;
  color: #fff;
  text-transform: uppercase;
}
</style>
