<template>
  <footer style="margin-top: auto;">
    <!-- <container> -->
      <section
        id="explore-section"
        class="d-flex flex-column justify-center align-center"
      >
        <h1 class="text-center" v-if="showExplore()">Explore The Ecosystem</h1>
        <!-- <btn href="https://discord.gg/HundOnSol">Discord</btn> -->
        <btn href="https://t.me/HundCoin">Telegram</btn>
        <!-- <btn href="https://twitter.com/HundOnSol">X.com</btn>  -->
        <btn type="bland" @click="router.push('/help')">Faq</btn>
        <btn type="bland" href="https://docs.hundonsol.com">Docs</btn>
      </section>
      <section id="links-section">
        <v-container class="d-flex flex-row justify-space-between" style="margin-left: auto;margin-right: auto;">
          <div class="left-wrapper">
            <div class="logo-wrapper">
              <Logo :size="Size.Small" />
            </div>
            <div class="social-links-wrapper">
              <a href="https://twitter.com/HundOnSol">
                <v-icon icon="fa-brands fa-x-twitter "></v-icon>
              </a>
              <a href="https://t.me/HundCoin">
                <v-icon icon="fa-brands fa-telegram "></v-icon>
              </a>
              <a href="https://discord.gg/HundOnSol">
                <v-icon icon="fa-brands fa-discord "></v-icon>
              </a>
            </div>
          </div>
          <div class="right-wrapper d-flex flex-row">
            <ul>
              <li>
                <a href="https://HundOnSol.com">Token</a>
              </li>
              <li>
                <router-link to="/help">Faq</router-link>
              </li>
            </ul>
            <ul>
              <li>
                <router-link to="/">Swap</router-link>
              </li>
              <li>
                <a href="https://docs.hundonsol.com">Docs</a>
              </li>
              <!-- <li>
                <router-link to="/shop">Shop</router-link>
              </li>
              <li>
                <router-link to="/nft">Nft</router-link>
              </li> -->
            </ul>
          </div>
        </v-container>
      </section>
    <!-- </container> -->
  </footer>
</template>
<script setup lang="ts">
import Btn from "@/components/Btn.vue";
import Logo from "@/components/Logo.vue";

import { Size } from "@/interfaces";
import { computed } from "vue";
import { useRoute, useRouter } from "vue-router";

const route = useRoute();
const router = useRouter()
// Compute the current route path
const path = computed(() => route.path);
const showExplore = () => {
  return path.value !== "/shop" && path.value !== "/nft";
};
</script>
<style lang="scss">
footer {
  text-transform: uppercase;
}

#explore-section {
  gap: 2rem;
}
#explore-section .v-btn {
  width: 180px;
}
#links-section {
  margin-top: 2rem;
  border-top: 1px solid rgb(var(--v-theme-lightTextColor));
  padding: 1rem;

  .v-container {
    margin: 2rem 0;
  }

  .social-links-wrapper {
    display: flex;
    gap: 2rem;
    padding-top: 1rem;

    a {
      color: white;

      i {
        font-size: 1.8rem;
      }
    }
  }

  .right-wrapper {
    gap: 2rem;

    ul {
      padding-inline-start: 32px;
    }

    li {
      padding: 5px 0;
      color: rgb(var(--v-theme-lightTextColor));

      a {
        color: rgb(var(--v-theme-lightTextColor));
      }
    }
  }
}
</style>
