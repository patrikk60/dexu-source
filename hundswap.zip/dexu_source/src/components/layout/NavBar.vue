<template>
  <v-main>

    <nav class="navbar">
      <v-container>
        <div class="d-flex flex-row justify-space-between">
          <router-link to="/">
            <Logo />
          </router-link>
          <div class="main-nav">
            <a href="https://hundonsol.com">Token</a>
            <router-link to="/help">Faq</router-link>
            <!-- <router-link to="/shop">Shop</router-link>
              <router-link to="/nft">Nft</router-link> -->
            </div>
            <div class="mobile-nav">
              <v-app-bar-nav-icon
              variant="text"
              @click="toggleNavDrawer"
              ></v-app-bar-nav-icon>
            </div>
          </div>
        </v-container>
      </nav>
    </v-main>
</template>
<script
  setup
  lang="ts"
>
import Logo from '@/components/Logo.vue';
import useStore from '@/store';

const store = useStore()
const toggleNavDrawer = () => {
  store.openNavigationDrawer = !store.openNavigationDrawer
}
</script>
<style
  lang="scss"
  scoped
>
.main-nav {
  display: flex;

  a {
    display: block;
    padding-left: 0.5rem;
    padding-right: 0.5rem;
    font-size: 25px;
    padding: 8px 28px;
  }
}

.navbar a {
  text-decoration: none;
  color: #fff;
  text-transform: uppercase;
}
</style>
