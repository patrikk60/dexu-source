import axios, { AxiosError } from "axios";
import { ExchangeType, IStoreState } from "./types";
import {
  APIResponse,
  FetchCoinsResponse,
  FetchRateRequest,
  FetchRateResponse,
  OrderStatusResponse,
  PlaceCEXOrderRequest,
  PlaceCEXOrderResponse,
  ToastMessage,
  ToastMessageKind,
  ValidateAddressRequest,
} from "@/interfaces";
import usePrepareCoinsList from "@/hooks/usePrepareCoinsList";
import { inject } from "vue";
import { useWebWorkerFn } from "@vueuse/core";

import { SOLDexService, SOLDexServiceName } from "@/plugins/dex";
import {
  SwapMode,
  Owner,
  executeTransaction,
  JUPITER_V6_ERRORS,
  MARKETS_URL,
  TOKEN_LIST_URL,
  JUPITER_FEE_OWNER,
  LAMPORTS_PER_SIGNATURE,
  calculateTransactionDepositAndFeeV2,
  getTransactionBlockhash,
  getReferralTokenAccount,
} from "@jup-ag/common";
import { TokenInfo } from "@solana/spl-token-registry";
import usePrepareDEXCoinsList from "@/hooks/usePrepareDEXCoinsList";
import {
  DefaultApi,
  QuoteGetRequest,
  QuoteResponse,
  SwapResponse,
} from "@jup-ag/api";
import { getQuote, getSwapResult } from "@/plugins/dex/fns";
import { PublicKey } from "@solana/web3.js";
import { PriceTick } from "../interfaces/index";

type IActions = Partial<IStoreState> & {
  setToastMessage(message: string, kind: ToastMessageKind): void;
  validateAddress(req: ValidateAddressRequest): Promise<number>;
  setExchangeType(exchangeType: ExchangeType): void;
  fetchDEXCoins(): Promise<void>;
  fetchDEXCoinHistory(
    mint: string,
    interval?: string,
    days?: number
  ): Promise<PriceTick[]>;
  fetchDEXExchangeAmount(req: QuoteGetRequest): Promise<QuoteResponse>;
  fetchCEXCoins(): Promise<void>;
  fetchCEXExchangeAmount(req: FetchRateRequest): Promise<FetchRateResponse>;
  placeCEXOrder(req: PlaceCEXOrderRequest): Promise<PlaceCEXOrderResponse>;
  getDEXInstructions(
    pkey: PublicKey,
    req: QuoteResponse
  ): Promise<SwapResponse>;
  checkCEXOrderStatus(orderId: string): Promise<OrderStatusResponse>;
  setPermanentToastMessage(message: string, kind: ToastMessageKind): void;
};

const actions: IActions = {
  setExchangeType(exchangeType: ExchangeType) {
    this.selectedExchangeType = exchangeType;
  },
  async fetchDEXCoins(): Promise<void> {
    return new Promise((resolve, reject) => {
      axios
        .get(TOKEN_LIST_URL["mainnet-beta" as keyof typeof TOKEN_LIST_URL])
        .then((res) => {
          // console.log({ res, TOKEN_LIST_URL });
          const tknInfo = res.data as TokenInfo[];
          // console.log({ tknInfo });
          if (!tknInfo?.length) {
            reject("A server error occurred. Please try again later");
            return;
          }

          this.coins = usePrepareDEXCoinsList(tknInfo);
          resolve();
        })
        .catch((err: AxiosError) => {
          reject("A server error occurred. Please try again");
        });
    });
  },
  async fetchDEXCoinHistory(
    mint: string,
    interval = "5m",
    days = 1
  ): Promise<PriceTick[]> {
    const to = Date.now();
    const from = to - days * 24 * 60 * 60 * 1000;
    const params = {
      address: mint,
      address_type: "token",
      type: interval,
      time_from: Math.floor(from / 1000).toString(),
      time_to: Math.floor(to / 1000).toString(),
    };
    const queryParams = new URLSearchParams(params).toString();
    const url = `${
      import.meta.env.VITE_BIRDEYE_API_BASE_URL
    }defi/history_price?${queryParams}`;
    const headers = {
      // "x-chain": "solana",
      "X-API-KEY": import.meta.env.VITE_BIRDEYE_API_KEY,
    };
    return await axios
      .get(url, { headers })
      .then((res) => {
        const data = res.data;
        const items = data?.data?.items;
        if (!data.success) {
          throw new Error("A server error occurred. Please try again later");
        }
        if (items.length) {
          // console.log({ items });
          return items;
        } else {
          throw new Error("No items found");
        }
      })
      .catch((err: AxiosError) => {
        console.error(err);
        throw new Error("A server error occurred. Please try again");
      });
  },
  async fetchCEXCoins(): Promise<void> {
    return new Promise((resolve, reject) => {
      axios
        .get("")
        .then((res) => {
          const apiResponse = res.data as FetchCoinsResponse;
          if (!apiResponse.success) {
            reject("A server error occurred. Please try again later");
            return;
          }

          this.coins = usePrepareCoinsList(apiResponse.data);
          resolve();
        })
        .catch((err: AxiosError) => {
          reject("A server error occurred. Please try again");
        });
    });
  },

  async placeCEXOrder(
    req: PlaceCEXOrderRequest
  ): Promise<PlaceCEXOrderResponse> {
    return new Promise((resolve, reject) => {
      axios
        .post("/placeOrder", req)
        .then((res) => {
          const apiResponse = res.data as APIResponse;
          if (!apiResponse.success) {
            reject(
              "An error occurred while placing the order, please try again later."
            );
            return;
          }

          const order = apiResponse.data as PlaceCEXOrderResponse;
          this.order = order;
          resolve(order);
        })
        .catch((err) => {
          reject(
            "An error occurred while placing the order, please try again later."
          );
        });
    });
  },

  async validateAddress(req: ValidateAddressRequest): Promise<number> {
    // -1 = network error, 0 = invalid, 1 = valid
    let isValid = -1;
    try {
      let result = await axios.get("/validateAddress", { params: req });
      const res = result.data as APIResponse;
      isValid = res.success === 1 ? 1 : 0;
    } catch (err) {}

    return isValid;
  },

  async fetchCEXExchangeAmount(
    req: FetchRateRequest
  ): Promise<FetchRateResponse> {
    return new Promise((resolve, reject) => {
      axios
        .get("/rate", { params: req })
        .then((resp) => {
          const apiResponse = resp.data as APIResponse;
          if (apiResponse.data) {
            resolve(apiResponse.data as FetchRateResponse);
          } else {
            reject("A server error occurred");
          }
        })
        .catch((err) => {
          reject(err);
        });
    });
  },
  async fetchDEXExchangeAmount(req: QuoteGetRequest): Promise<QuoteResponse> {
    const solDexService = this.solDexService;
    if (!solDexService || !solDexService.jupClient) {
      // console.log(solDexService);
      throw new Error("DEX service not initialized");
    }
    const swapQuote = await getQuote(solDexService?.jupClient)(req);
    // console.log({ swapQuote });
    if (!swapQuote) {
      throw new Error("No quote found");
    } else return swapQuote;
  },

  async getDEXInstructions(pkey: PublicKey, req: QuoteResponse) {
    const solDexService = this.solDexService;
    if (!solDexService || !solDexService.jupClient) {
      // console.log(solDexService);
      throw new Error("DEX service not initialized");
    }
    const swapTxn = await getSwapResult(solDexService?.jupClient)(pkey, req);
    // console.log({ swapTxn });
    if (!swapTxn) {
      throw new Error("No swap transaction found");
    } else return swapTxn;
  },

  setPermanentToastMessage(message: string, kind: ToastMessageKind) {
    const toastMessage: ToastMessage = {
      message: message,
      kind: kind,
    };
    this.toastMessage = toastMessage;
  },

  setToastMessage(message: string, kind: ToastMessageKind) {
    let timeOut;
    switch (kind) {
      case ToastMessageKind.Error:
        timeOut = 7000;
        break;
      case ToastMessageKind.Wait:
        timeOut = 7000;
        break;
      case ToastMessageKind.Positive:
        timeOut = 3500;
        break;
      default:
        timeOut = 0;
    }

    const toastMessage: ToastMessage = {
      message: message,
      kind: kind,
    };

    this.toastMessage = toastMessage;
    setTimeout(() => {
      this.toastMessage = null;
    }, timeOut);
  },

  checkCEXOrderStatus(orderId: string): Promise<OrderStatusResponse> {
    return new Promise((resolve, reject) => {
      axios
        .get("/getOrderStatus", {
          params: {
            id: orderId,
          },
        })
        .then((resp) => {
          const apiResponse = resp.data as APIResponse;
          if (apiResponse.success) {
            resolve(apiResponse.data as OrderStatusResponse);
          }
        })
        .catch((err) => {
          reject("Error fetching order status");
        });
    });
  },
};

export default actions;
