import { Coin, PlaceCEXOrderResponse, ToastMessage } from "@/interfaces";
import { IStoreState } from "./types";

const getters = {
  getCoins: (state: IStoreState): Coin[] => state.coins,
  getSelectedExchangeType: (state: IStoreState) => state.selectedExchangeType,
  getToastMessage: (state: IStoreState): ToastMessage | null =>
    state.toastMessage,
  getOrder: (state: IStoreState): PlaceCEXOrderResponse | null => state.order,
  getShowLoading: (state: IStoreState): boolean => state.showLoading,
  /**getCoinsWithSearch: (state: IStoreState): Coin[] => {
    if (!state.coinSearchTerm || state.coinSearchTerm === "") {
      return state.coins
    }

    const coins: Coin[] = state.coins.filter(item => {
      const code = item.code.toLowerCase()
      const network = item.network.toLowerCase()
      const name = item.name.toLowerCase()
      const networkCode = item.networkCode.toLowerCase()

      const term = state.coinSearchTerm.toLowerCase()
      if (code.includes(term) || network.includes(term) || name.includes(term) || networkCode.includes(term)) {
        return true
      }
      return false;
    });

    return coins
  }**/
};

export default getters;
