import { defineStore } from "pinia";
import { IStoreState } from "./types";
import getters from "./getters";
import actions from "./actions";
import state from "./state";

//@ts-ignore
const useStore = defineStore("store", {
  state: (): IStoreState => state,
  getters: getters,
  actions: actions,
});

export default useStore;
