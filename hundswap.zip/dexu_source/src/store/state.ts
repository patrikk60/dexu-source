import { IStoreState } from "./types";
import { Coin } from "@/interfaces";
import { SOLDexService } from "../plugins/dex/index";

/**
const coins: Coin[] = [{
  key: "bitcoin-btc",
  name: "Bitcoin",
  code: "BTC",
  network: "BTC",
  networkCode: "BTC",
  isTrending: true,
  isSuspended: false,
  receiveDecimals: 10,
  iconURL: "/images/coins/btc.svg"
}, {
  key: "ethereum-erc20",
  name: "Ethereum",
  code: "ETH",
  network: "ETH",
  networkCode: "ERC20",
  isTrending: true,
  isSuspended: false,
  receiveDecimals: 10,
  iconURL: "/images/coins/btc.svg"
}, {
  key: "barn-bridge-erc20",
  name: "BarnBridge",
  code: "BOND",
  network: "ETH",
  networkCode: "ERC20",
  isTrending: false,
  isSuspended: true,
  receiveDecimals: 10,
  iconURL: "/images/coins/btc.svg"
}, {
  key: "cellar-network-bep20",
  name: "Cellar Network",
  code: "Cellar",
  network: "BSC",
  networkCode: "BEP20",
  isTrending: true,
  isSuspended: true,
  receiveDecimals: 10,
  iconURL: "/images/coins/btc.svg"
}]**/

const defaultCexPair: Coin[] = [
  {
    key: "bitcoin-btc",
    name: "Bitcoin",
    code: "BTC",
    network: "BTC",
    networkCode: "BTC",
    isTrending: true,
    sendStatus: true,
    receiveStatus: true,
    receiveDecimals: 10,
    iconURL: "/images/coins/btc.svg",
  },
  {
    key: "ethereum-erc20",
    name: "Ethereum",
    code: "ETH",
    network: "ETH",
    networkCode: "ERC20",
    isTrending: true,
    sendStatus: true,
    receiveStatus: true,
    receiveDecimals: 10,
    iconURL: "/images/coins/btc.svg",
  },
];

const state: IStoreState = {
  selectedExchangeType: "DEX",
  coins: defaultCexPair,
  openSelectCoinDialog: false,
  toastMessage: null,
  order: null,
  openNavigationDrawer: false,
  showLoading: true,
  solDexService: {} as SOLDexService,
};

export default state;
