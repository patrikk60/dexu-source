import { Coin, PlaceCEXOrderResponse, ToastMessage } from "@/interfaces";
import { SOLDexService } from "@/plugins/dex";
export type ExchangeType = "CEX" | "DEX";
export interface IStoreState {
  selectedExchangeType: ExchangeType;
  coins: Coin[];
  openSelectCoinDialog: boolean;
  toastMessage: ToastMessage | null;
  order: PlaceCEXOrderResponse | null;
  openNavigationDrawer: boolean;
  showLoading: boolean;
  solDexService: SOLDexService;
}
