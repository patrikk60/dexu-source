// mixins/preventZoomMixin.js

export default {
  mounted() {
    const preventZoom = (event: Event) => {
      const touchEvent = event as TouchEvent;
      if (touchEvent.touches.length > 1) {
        event.preventDefault();
      }
    };

    document.addEventListener('touchstart', preventZoom, { passive: false });
  },
};