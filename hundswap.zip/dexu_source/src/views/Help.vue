<template>
  <container
    class="page"
    id="help-page"
  >
    <page-content>
      <div class="topbar">
        <p
          style="text-align: center;"
          class="header"
        >HELP & FAQ</p>
        <!-- Question 1 -->
        <p style="color: white;"><strong>1. Do I need to create an account to use HundSwap Platform?</strong></p>
        <p class="answer">No account is needed. Users can instantly swap with just their crypto address.</p>

        <!-- Question 2 -->
        <p><strong>2. How does the transaction process work on HundSwap Platform?</strong></p>
        <p class="answer">Once users send their coins, and the transaction is confirmed, our platform instantly sends
          out the swapped coins to the address provided by the user.</p>

        <!-- Question 3 -->
        <p><strong>3. Can I modify my swap after sending the coins?</strong></p>
        <p class="answer">Users can create a new swap if they wish to modify their current one. If coins have already
          been
          sent and modification is needed, please reach out to our support at <a
            href="mailto:contact@hundswap.com"><strong>contact@hundswap.com</strong></a>.</p>

        <!-- Question 4 -->
        <p><strong>4. How long does it take for a transaction to complete?</strong></p>
        <p class="answer">Transactions are usually processed instantly, but the total swap completion time depends on
          the
          time it takes to confirm the deposit and withdrawal transactions on the network.</p>

        <!-- Question 5 -->
        <p><strong>5. Which cryptocurrencies are supported on HundSwap Platform?</strong></p>
        <p class="answer">Dexu supports a wide variety of cryptocurrencies on all the most popular crypto networks.
          Users
          can check all supported coins on <a
            href="https://hundswap.com"
            target="_blank"
          ><strong>hundswap.com</strong></a>.</p>

        <!-- Question 6 -->
        <p><strong>6. Does HundSwap Platform have access to my wallets or private keys?</strong></p>
        <p class="answer">No, we do not custody any cryptocurrencies, as swaps take place in real time. We do not
          require
          access to any wallets or private keys.</p>

        <!-- Question 7 -->
        <p><strong>7. What are the fees for using HundSwap Platform?</strong></p>
        <p class="answer">Our swap fees are the lowest in the market at 0.15% for cross-chain swaps and 0% for Solana swaps. Network fees also apply, depending on the coins and network.</p>

        <!-- Question 8 -->
        <p><strong>8. Can I reverse a completed swap?</strong></p>
        <p class="answer">No, once the swap has been completed, there are no reversals.</p>

        <!-- Question 9 -->
        <p><strong>9. How can I contact HundSwap support?</strong></p>
        <p class="answer">Support is available via <a
            href="mailto:contact@hundswap.com"><strong>contact@hundswap.com</strong></a>.</p>

        <!-- Question 10 -->
        <p><strong>10. How can I stay updated on HundSwap?</strong></p>
        <p class="answer">All updates are shared via our social media channels, specifically on <a
            href="https://twitter.com/HundOnSol"
            target="_blank"
          ><strong>X</strong></a> and <a
            href="https://t.me/HundCoin"
            target="_blank"
          ><strong>Telegram</strong></a>.</p>
      </div>
    </page-content>
  </container>
</template>
<script
  setup
  lang="ts"
>
import Container from '@/components/Container.vue'
import PageContent from '@/components/PageContent.vue'
</script>
<style
  lang="scss"
  scoped
>
p.answer {
  color: rgb(var(--v-theme-lightTextColor));
  margin-top: 10px;
  margin-bottom: 10px;
}

.topbar {
  padding: 0 25px;
}
a {
  color: rgb(var(--v-theme-primary));
}

.header {
  text-transform: uppercase;
  margin-bottom: 13px;
  font-size: 2rem;
}
</style>
