<template>
  <container
    class="page"
    id="home-page"
  >
  <loading />
  <page-content>
    <site-info />
    <CEX v-if="store.getSelectedExchangeType=='CEX'"/>
    <DEX v-else/>
    </page-content>
  </container>
</template>
<style>
  .swap-box{
    max-width: 800px;
  }
  @media screen and (min-width:1280px) {
    .swap-box{
      min-width: 800px;
    }
  }
  @media screen and (max-width:775px) {
    .swap-box{
      width: 100%;
    }
  }
</style>

<script setup lang="ts">
import useStore from '@/store';
import CEX from '@/components/swap-forms/CEX.vue';
import DEX from '@/components/swap-forms/DEX.vue';
import SiteInfo from '@/components/SiteInfo.vue';
import Loading from '@/components/Loading.vue';
import PageContent from '@/components/PageContent.vue';
import Container from '@/components/Container.vue';
const store = useStore();
</script>
