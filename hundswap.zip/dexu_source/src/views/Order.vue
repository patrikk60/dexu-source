<template>
  <container
    class="page"
    id="order-page"
  >
    <page-content>
      <box class="padded">
        <status :status="orderStatus.status" />
        <div class="details">
          <awaiting-deposit
            class="order-status"
            v-if="orderStatus.status === OrderStatusKind.AwaitingDeposit"
            :order="order"
          />
          <confirming-deposit
            class="order-status"
            v-if="orderStatus.status === OrderStatusKind.ConfirmingDeposit"
            :orderStatus="orderStatus"
            :order="order"
          />
          <confirming-deposit
            class="order-status"
            v-if="orderStatus.status === OrderStatusKind.Sending || orderStatus.status === OrderStatusKind.Exchanging"
            :orderStatus="orderStatus"
            :order="order"
          />
          <complete
            class="order-status"
            v-if="orderStatus.status === OrderStatusKind.Complete"
            :orderStatus="orderStatus"
            :order="order"
          />
        </div>
      </box>
    </page-content>
  </container>
</template>
<script
  setup
  lang="ts"
>
import Container from '@/components/Container.vue'
import Box from '@/components/Box.vue'
import Status from '@/components/order/components/Status.vue'
import AwaitingDeposit from '@/components/order/AwaitingDeposit.vue'
import ConfirmingDeposit from '@/components/order/ConfirmingDeposit.vue'
import Complete from '@/components/order/Complete.vue'
import PageContent from '@/components/PageContent.vue'

import useStore from '@/store';
import { ref } from 'vue';
import {
  PlaceCEXOrderResponse,
  OrderStatusKind,
  OrderStatusResponse,
  ToastMessageKind
} from '@/interfaces';


const store = useStore()

const order = store.getOrder as PlaceCEXOrderResponse
const orderStatus = ref<OrderStatusResponse>({
  id: order.id,
  status: OrderStatusKind.AwaitingDeposit,
  receiveAmount: order.receiveAmount,
  createdAt: order.createdAt
})

const checkStatusInterval = setInterval(() => {
  store.checkCEXOrderStatus(order.id)
    .then((resp) => {
      orderStatus.value = resp
      if (resp.status === OrderStatusKind.Complete) {
        clearInterval(checkStatusInterval)
      }

      if (resp.status == OrderStatusKind.ActionRequest) {
        clearInterval(checkStatusInterval)
        store.setPermanentToastMessage("There's an Action Request on this transaction, please get in contact with us to give you assistance.", ToastMessageKind.Error)
        clearInterval(checkStatusInterval)
      } else if (resp.status == OrderStatusKind.RequestOverdue) {
        store.setPermanentToastMessage("You failed to send funds, please don't send them now, go back home and try again.", ToastMessageKind.Error)
        clearInterval(checkStatusInterval)
      } else if (resp.status == OrderStatusKind.Failed) {
        store.setPermanentToastMessage("The transaction failed, please get in contact with us to give you assistance.", ToastMessageKind.Error)
        clearInterval(checkStatusInterval)
      }


    }).catch((err) => {

    })
}, 10000)
</script>
<style
  lang="scss"
  scoped
>
.details {
  margin-top: 1rem;
}
</style>
<style lang="scss">
.order-status .extras {
  margin: 40px auto;
}
</style>
