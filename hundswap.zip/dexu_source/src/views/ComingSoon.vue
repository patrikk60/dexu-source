<template>
  <container
    class="page"
    id="coming-soon-page"
  >
    <h1>Coming Soon</h1>
  </container>
</template>
<script
  setup
  lang="ts"
>
import Container from '@/components/Container.vue'
</script>
<style scoped>
h1 {
  font-weight: 500;
  text-transform: uppercase;
  text-align: center;
  font-size: calc(1.375rem + 1.5vw);
  line-height: 1.2;
}
</style>