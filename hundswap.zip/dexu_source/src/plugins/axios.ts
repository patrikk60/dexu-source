import axios from "axios";

export const configureAxios = () => {
  axios.defaults.baseURL = import.meta.env.VITE_API_BASE_URL;

  axios.interceptors.request.use((config) => {
    config.headers['Content-Type'] = 'application/json'
    return config;
  }, (error) => {
    return Promise.reject(error)
  })

  axios.interceptors.response.use((config) => {
    return config;
  }, (error) => {
    return Promise.reject(error);
  })
}