/**
 * plugins/index.ts
 *
 * Automatically included in `./src/main.ts`
 */

// Plugins
import vuetify from "./vuetify";
import router from "../router";
import { createPinia } from "pinia";
import { configureAxios } from "./axios";
import { v4 as uuidv4 } from "uuid";
import SolanaWallets from "solana-wallets-vue";

// Types
import type { App } from "vue";
import { createSolDexService, SOLDexService, SOLDexServiceName } from "./dex";
import { walletOptions } from "./dex/walletOptions";

declare module "pinia" {
  export interface PiniaCustomProperties {
    solDexService: SOLDexService;
  }
}
export function registerPlugins(app: App) {
  const storedDeviceID = localStorage.getItem("deviceID");
  if (!storedDeviceID) {
    localStorage.setItem("deviceID", uuidv4());
  }

  app
    .use(vuetify)
    .use(router)
    .use(SolanaWallets, walletOptions)
    .use(
      createPinia().use(({ store }) => ({
        solDexService: createSolDexService(),
      }))
    );

  configureAxios();
}
