import { createJupiterApiClient, DefaultApi as JupApi } from "@jup-ag/api";
import { Connection } from "@solana/web3.js";

import { SOLANA_RPC } from "@/constants";
export const SOLDexServiceName = "SOLDexService";
export const DEXNetwork = "SOL";

export interface SOLDexService {
  jupClient: JupApi;
  connection: Connection;
}
export { JupApi };
export const createSolDexService = (): SOLDexService => {
  return {
    jupClient: createJupiterApiClient(),
    connection: new Connection(SOLANA_RPC, "confirmed"),
  };
};
