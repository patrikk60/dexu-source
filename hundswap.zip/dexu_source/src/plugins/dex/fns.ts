import { Connection, PublicKey, VersionedTransaction } from "@solana/web3.js";
import { JupApi } from ".";
import { QuoteResponse, QuoteGetRequest } from "@jup-ag/api";
import { Wallet } from "@coral-xyz/anchor";
export const getQuote =
  (jupiterQuoteApi: JupApi) =>
  async (
    req: QuoteGetRequest,
    reqExtra: Partial<QuoteGetRequest> = {
      onlyDirectRoutes: false,
      asLegacyTransaction: false,
    }
  ) => {
    try {
      // const tkns = await jupiterQuoteApi.tokensGet();
      // console.log({ tkns, req });
      const quote = await jupiterQuoteApi.quoteGet({
        ...req,
        ...reqExtra,
      });
      return quote;
    } catch (err) {
      //@ts-ignore
      console.log("juperr: ", err, err.name, err.response);
    }
  };
export const getSwapResult =
  (jupiterQuoteApi: JupApi) =>
  async (userPublicKey: PublicKey, quote: QuoteResponse) => {
    try {
      const swapResult = await jupiterQuoteApi.swapPost({
        swapRequest: {
          userPublicKey: userPublicKey.toBase58(),
          quoteResponse: quote,
          // dynamicComputeUnitLimit: true,
          //prioritizationFeeLamports: "auto",
          prioritizationFeeLamports: {
            autoMultiplier: 3,
          },
          useSharedAccounts: true,
          wrapAndUnwrapSol: true,
        },
      });
      return swapResult;
    } catch (err) {
      console.log(err);
    }
  };

// export const getQuoteAndSwap = async (
//   connection: Connection,
//   jupiterQuoteApi: JupApi,
//   tokenIn: string,
//   tokenOut: string,
//   amount: number,
//   wallet: Wallet
// ) => {
//   console.log("getQuoteAndSwap", {
//     tokenIn,
//     tokenOut,
//     amount,
//     wallet: wallet.publicKey,
//   });
//   const quote = await getQuote(jupiterQuoteApi)(tokenIn, tokenOut, amount);
//   if (!quote) {
//     throw new Error("No quote found");
//   }
//   const currentQuotePrice =
//     Number(quote?.outAmount) || 0 / Number(quote?.inAmount) || 1;
//   if (!currentQuotePrice) {
//     throw new Error("QuotePrice error, quote: " + JSON.stringify(quote));
//   }
//   if (quote) {
//     const swapResult = await getSwapResult(jupiterQuoteApi)(
//       wallet.publicKey,
//       quote
//     );
//     if (swapResult) {
//       const swapTransactionBuf = Buffer.from(
//         swapResult.swapTransaction,
//         "base64"
//       );
//       const transaction = VersionedTransaction.deserialize(swapTransactionBuf);
//       transaction.sign([wallet.payer]);
//       const rawTransaction = transaction.serialize();
//       // const txid = await nospam_sendAndCheckTxn(connection, rawTransaction);
//       const txid = await connection.sendRawTransaction(rawTransaction, {
//         skipPreflight: true,
//         maxRetries: 20,
//       });

//       await connection.confirmTransaction(txid);
//       console.log(`Swap success: https://solscan.io/tx/${txid}`);
//       return {
//         quote,
//         txid,
//       };
//     }
//   }
// };
