import {
  Coin98WalletAdapter,
  CoinbaseWalletAdapter,
  PhantomWalletAdapter,
  WalletConnectWalletAdapter,
} from "@solana/wallet-adapter-wallets";
import { SOLANA_RPC } from "@/constants";
import { WalletAdapterNetwork } from "@solana/wallet-adapter-base";

const projectId = process.env?.VITE_WALLET_CONNECT_PROJECT_ID || undefined;
export const walletOptions = {
  wallets: [
    // new PhantomWalletAdapter({}),
    // new CoinbaseWalletAdapter(),
    // new Coin98WalletAdapter(),
    new WalletConnectWalletAdapter({
      network: SOLANA_RPC.includes("devnet")
        ? WalletAdapterNetwork.Devnet
        : WalletAdapterNetwork.Mainnet,
      options: {
        name: process.env?.VITE_WALLET_CONNECT_PROJECT_NAME || undefined,
        projectId,
      },
    }),
  ],
  autoConnect: true,
};
